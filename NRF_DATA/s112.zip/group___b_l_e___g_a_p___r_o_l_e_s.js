var group___b_l_e___g_a_p___r_o_l_e_s =
[
    [ "BLE_GAP_ROLE_INVALID", "group___b_l_e___g_a_p___r_o_l_e_s.html#ga8164b32f4fd65997d0523cd7c5735166", null ],
    [ "BLE_GAP_ROLE_PERIPH", "group___b_l_e___g_a_p___r_o_l_e_s.html#ga12e431897d73a3ce88fab8a4dbd90497", null ]
];