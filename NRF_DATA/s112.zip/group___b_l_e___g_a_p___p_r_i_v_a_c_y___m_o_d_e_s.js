var group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_o_d_e_s =
[
    [ "BLE_GAP_PRIVACY_MODE_DEVICE_PRIVACY", "group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_o_d_e_s.html#ga355a8bc3652cd1189d5d71891228149e", null ],
    [ "BLE_GAP_PRIVACY_MODE_NETWORK_PRIVACY", "group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_o_d_e_s.html#gaf9c90aba842551a61c74d4b169cddb1e", null ],
    [ "BLE_GAP_PRIVACY_MODE_OFF", "group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_o_d_e_s.html#ga27b59bba4d9df51dba771a96b0972778", null ]
];