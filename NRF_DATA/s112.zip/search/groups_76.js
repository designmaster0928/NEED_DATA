var searchData=
[
  ['vendor_20specific_20base_20uuid_20counts',['Vendor Specific base UUID counts',['../group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s.html',1,'']]],
  ['variables',['Variables',['../group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html',1,'']]]
];
