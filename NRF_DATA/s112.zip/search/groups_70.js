var searchData=
[
  ['peripheral_20connection_20establishment_20and_20termination',['Peripheral Connection Establishment and Termination',['../group___b_l_e___g_a_p___c_o_n_n___m_s_c.html',1,'']]],
  ['peripheral_20connection_20parameter_20update',['Peripheral Connection Parameter Update',['../group___b_l_e___g_a_p___c_p_u___m_s_c.html',1,'']]],
  ['phy_20update_20procedure',['PHY Update Procedure',['../group___b_l_e___g_a_p___e_v_t___p_h_y___m_s_c.html',1,'']]],
  ['peripheral_20connection_20establishment_20with_20private_20peer',['Peripheral Connection Establishment with Private Peer',['../group___b_l_e___g_a_p___p_e_r_i_p_h___c_o_n_n___p_r_i_v___m_s_c.html',1,'']]],
  ['peripheral_20encryption_20establishment_20using_20stored_20keys',['Peripheral Encryption Establishment using stored keys',['../group___b_l_e___g_a_p___p_e_r_i_p_h___e_n_c___m_s_c.html',1,'']]],
  ['peripheral_20legacy_20pairing',['Peripheral Legacy Pairing',['../group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_g_a_c_y___m_s_c.html',1,'']]],
  ['peripheral_20lesc_20pairing',['Peripheral LESC Pairing',['../group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_s_c___m_s_c.html',1,'']]],
  ['pairing_3a_20just_20works',['Pairing: Just Works',['../group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_s_c___p_a_i_r_i_n_g___j_w___m_s_c.html',1,'']]],
  ['pairing_20failure_3a_20pairing_20aborted_20by_20the_20application',['Pairing failure: Pairing aborted by the application',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___a_p_p___e_r_r_o_r___m_s_c.html',1,'']]],
  ['pairing_20failure_3a_20confirm_20failed',['Pairing failure: Confirm failed',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___c_o_n_f_i_r_m___f_a_i_l___m_s_c.html',1,'']]],
  ['pairing_3a_20just_20works',['Pairing: Just Works',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___j_w___m_s_c.html',1,'']]],
  ['pairing_20failure_3a_20keysize_20out_20of_20supported_20range',['Pairing failure: Keysize out of supported range',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___k_s___o_u_t___o_f___r_a_n_g_e___m_s_c.html',1,'']]],
  ['pairing_20failure_3a_20pairing_20failed_20from_20central',['Pairing failure: Pairing failed from central',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___r_e_m_o_t_e___p_a_i_r_i_n_g___f_a_i_l___m_s_c.html',1,'']]],
  ['pairing_20failure_3a_20timeout',['Pairing failure: Timeout',['../group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___t_i_m_e_o_u_t___m_s_c.html',1,'']]],
  ['peripheral_20security_20procedures',['Peripheral Security Procedures',['../group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___m_s_c.html',1,'']]],
  ['peripheral_20security_20request',['Peripheral Security Request',['../group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___r_e_q___m_s_c.html',1,'']]],
  ['peripheral_20phy_20update',['Peripheral PHY Update',['../group___b_l_e___g_a_p___p_e_r_i_p_h_e_r_a_l___p_h_y___u_p_d_a_t_e.html',1,'']]],
  ['private_20advertising',['Private Advertising',['../group___b_l_e___g_a_p___p_r_i_v_a_c_y___a_d_v___m_s_c.html',1,'']]],
  ['privacy_20modes',['Privacy modes',['../group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_o_d_e_s.html',1,'']]],
  ['privacy',['Privacy',['../group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_s_c.html',1,'']]],
  ['possible_20lfclk_20oscillator_20sources',['Possible LFCLK oscillator sources',['../group___n_r_f___c_l_o_c_k___l_f___s_r_c.html',1,'']]]
];
