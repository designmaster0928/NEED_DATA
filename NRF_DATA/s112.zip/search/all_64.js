var searchData=
[
  ['defines',['Defines',['../group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___b_l_e___g_a_p___d_e_f_i_n_e_s.html',1,'']]],
  ['directed_20advertising',['Directed Advertising',['../group___b_l_e___g_a_p___p_r_i_v_a_c_y___a_d_v___d_i_r___p_r_i_v___m_s_c.html',1,'']]],
  ['defines',['Defines',['../group___b_l_e___g_a_t_t___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___b_l_e___g_a_t_t_c___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___b_l_e___g_a_t_t_s___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html',1,'']]],
  ['data',['data',['../structble__gattc__evt__read__rsp__t.html#adaf3ed862b2c96947da60d9b576b31c9',1,'ble_gattc_evt_read_rsp_t::data()'],['../structble__gattc__evt__write__rsp__t.html#a1691be986d4b730bbe2ccc3d40c5a088',1,'ble_gattc_evt_write_rsp_t::data()'],['../structble__gattc__evt__hvx__t.html#af239b9ba3cff6d1fc678f3f71711a2f3',1,'ble_gattc_evt_hvx_t::data()'],['../structble__gatts__evt__write__t.html#abe4bd839db7c40829ccdbff3d1f79a57',1,'ble_gatts_evt_write_t::data()']]],
  ['desc',['desc',['../structble__gatts__char__pf__t.html#a9133fc1220787c07ac21291dab7b8b22',1,'ble_gatts_char_pf_t']]],
  ['desc_5fdisc_5frsp',['desc_disc_rsp',['../structble__gattc__evt__t.html#a23df4ef5d71063a9921c787dbf2dfa85',1,'ble_gattc_evt_t']]],
  ['descs',['descs',['../structble__gattc__evt__desc__disc__rsp__t.html#a3d41c7255fa19fa2b55acd6962be26ee',1,'ble_gattc_evt_desc_disc_rsp_t']]],
  ['device_5fname_5fcfg',['device_name_cfg',['../unionble__gap__cfg__t.html#a595fa3ae67383df1959a77e90a819e96',1,'ble_gap_cfg_t']]],
  ['disable',['disable',['../structble__gap__opt__slave__latency__disable__t.html#a158bfaa2349dbb52914696c61288e217',1,'ble_gap_opt_slave_latency_disable_t']]],
  ['disconnected',['disconnected',['../structble__gap__evt__t.html#a2649b3d6849778ddb1abd5addb7d2322',1,'ble_gap_evt_t']]],
  ['distance_5fus',['distance_us',['../structnrf__radio__request__normal__t.html#a34cb59c0e80b3698a3df265ab88b34b5',1,'nrf_radio_request_normal_t']]],
  ['dst',['dst',['../structsd__mbr__command__copy__sd__t.html#ae8afbb5ddb539bf7d5aa63102313210a',1,'sd_mbr_command_copy_sd_t']]],
  ['duration',['duration',['../structble__gap__adv__params__t.html#a5a6e038d3c55004da3ac23e353f42517',1,'ble_gap_adv_params_t']]],
  ['defines',['Defines',['../group___n_r_f___m_b_r___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___n_v_i_c___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___s_d_m___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___s_o_c___d_e_f_i_n_e_s.html',1,'']]]
];
