var searchData=
[
  ['thread_20mode_20event_20retrieval',['Thread Mode Event Retrieval',['../group___b_l_e___c_o_m_m_o_n___t_h_r_e_a_d___e_v_t___m_s_c.html',1,'']]],
  ['types_20of_20uuid',['Types of UUID',['../group___b_l_e___u_u_i_d___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___m_b_r___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___s_d_m___t_y_p_e_s.html',1,'']]]
];
