var searchData=
[
  ['s112_20softdevice_20v7_2e2_2e0_20api',['S112 SoftDevice v7.2.0 API',['../index.html',1,'']]]
];
