var searchData=
[
  ['offset',['offset',['../structble__gattc__write__params__t.html#a85d01254a43068218061ab21acabe980',1,'ble_gattc_write_params_t::offset()'],['../structble__gattc__evt__read__rsp__t.html#a1ed66c83e153fd6471056d19b10fac67',1,'ble_gattc_evt_read_rsp_t::offset()'],['../structble__gattc__evt__write__rsp__t.html#a09d38782fd5d200a45146ae303614733',1,'ble_gattc_evt_write_rsp_t::offset()'],['../structble__gatts__value__t.html#a797c5008eafbee3716c25b8c48ec88c9',1,'ble_gatts_value_t::offset()'],['../structble__gatts__hvx__params__t.html#a07033f6e0e63974b67627ae84bc12fc9',1,'ble_gatts_hvx_params_t::offset()'],['../structble__gatts__authorize__params__t.html#ac6b4a578d5c850d4c5efb59e955ec557',1,'ble_gatts_authorize_params_t::offset()'],['../structble__gatts__evt__write__t.html#afc84657816fd23a1e7c5f4b0e848e69d',1,'ble_gatts_evt_write_t::offset()'],['../structble__gatts__evt__read__t.html#ac3c5c0c840625a5f28e90e9021eb2403',1,'ble_gatts_evt_read_t::offset()']]],
  ['oob',['oob',['../structble__gap__sec__params__t.html#a72cc5af2f69e1b15a7c0b281acd1059e',1,'ble_gap_sec_params_t']]],
  ['oobd_5freq',['oobd_req',['../structble__gap__evt__lesc__dhkey__request__t.html#a7d294c9683dd8500ec8c72a99c30bb82',1,'ble_gap_evt_lesc_dhkey_request_t']]],
  ['op',['op',['../structble__gatts__evt__write__t.html#a4e27117bb9e805b03a2c198b0684c621',1,'ble_gatts_evt_write_t']]]
];
