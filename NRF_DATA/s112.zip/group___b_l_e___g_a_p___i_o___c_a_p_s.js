var group___b_l_e___g_a_p___i_o___c_a_p_s =
[
    [ "BLE_GAP_IO_CAPS_DISPLAY_ONLY", "group___b_l_e___g_a_p___i_o___c_a_p_s.html#ga4e2f9010ba35ab6488ec181f75786435", null ],
    [ "BLE_GAP_IO_CAPS_DISPLAY_YESNO", "group___b_l_e___g_a_p___i_o___c_a_p_s.html#ga88681e29c52a54de028e2ee164d2403b", null ],
    [ "BLE_GAP_IO_CAPS_KEYBOARD_DISPLAY", "group___b_l_e___g_a_p___i_o___c_a_p_s.html#gaacd3ccc6340303a1edcc7c718f3c1e6f", null ],
    [ "BLE_GAP_IO_CAPS_KEYBOARD_ONLY", "group___b_l_e___g_a_p___i_o___c_a_p_s.html#ga65df849ce31a65393bd89ef65a7575b4", null ],
    [ "BLE_GAP_IO_CAPS_NONE", "group___b_l_e___g_a_p___i_o___c_a_p_s.html#gad11df80d3ac9d375b320363694ec0a03", null ]
];