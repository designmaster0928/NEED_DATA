var group___b_l_e___g_a_p___e_v_e_n_t___l_e_n_g_t_h =
[
    [ "BLE_GAP_EVENT_LENGTH_DEFAULT", "group___b_l_e___g_a_p___e_v_e_n_t___l_e_n_g_t_h.html#gaf8c2a8b62ad6861c960a0666a027178f", null ],
    [ "BLE_GAP_EVENT_LENGTH_MIN", "group___b_l_e___g_a_p___e_v_e_n_t___l_e_n_g_t_h.html#ga4ae4f987d8831d5bd692453773214ae1", null ]
];