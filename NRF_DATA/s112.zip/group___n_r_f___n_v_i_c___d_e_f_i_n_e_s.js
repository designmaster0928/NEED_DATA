var group___n_r_f___n_v_i_c___d_e_f_i_n_e_s =
[
    [ "SoftDevice NVIC internal definitions", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s" ]
];