var group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r___f_l_a_g_s =
[
    [ "BLE_GATTS_SYS_ATTR_FLAG_SYS_SRVCS", "group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r___f_l_a_g_s.html#ga62a3396d4af600e7f397c6b5159d44d1", null ],
    [ "BLE_GATTS_SYS_ATTR_FLAG_USR_SRVCS", "group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r___f_l_a_g_s.html#gadc1332e4e412b3e59a7d0a9038d5ac09", null ]
];