var group___b_l_e___e_r_r_o_r_s___g_a_t_t_c =
[
    [ "BLE_ERROR_GATTC_PROC_NOT_PERMITTED", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_c.html#gaec4c26bdcc1235411c5feec6d38b3465", null ]
];