var group___b_l_e___g_a_t_t_c___m_s_c =
[
    [ "GATTC ATT_MTU Exchange", "group___b_l_e___g_a_t_t_c___m_t_u___e_x_c_h_a_n_g_e.html", null ],
    [ "GATTC Characteristic Discovery", "group___b_l_e___g_a_t_t_c___c_h_a_r___d_i_s_c___m_s_c.html", null ],
    [ "GATTC Characteristic Value Write Without Response", "group___b_l_e___g_a_t_t_c___v_a_l_u_e___w_r_i_t_e___w_i_t_h_o_u_t___r_e_s_p___m_s_c.html", null ],
    [ "GATTC Characteristic or Descriptor Value Long Write", "group___b_l_e___g_a_t_t_c___v_a_l_u_e___l_o_n_g___w_r_i_t_e___m_s_c.html", null ],
    [ "GATTC Characteristic or Descriptor Value Read", "group___b_l_e___g_a_t_t_c___v_a_l_u_e___r_e_a_d___m_s_c.html", null ],
    [ "GATTC Characteristic or Descriptor Value Reliable Write", "group___b_l_e___g_a_t_t_c___v_a_l_u_e___r_e_l_i_a_b_l_e___w_r_i_t_e___m_s_c.html", null ],
    [ "GATTC Characteristic or Descriptor Value Write", "group___b_l_e___g_a_t_t_c___v_a_l_u_e___w_r_i_t_e___m_s_c.html", null ],
    [ "GATTC Descriptor Discovery", "group___b_l_e___g_a_t_t_c___d_e_s_c___d_i_s_c___m_s_c.html", null ],
    [ "GATTC Handle Value Indication", "group___b_l_e___g_a_t_t_c___h_v_i___m_s_c.html", null ],
    [ "GATTC Handle Value Notification", "group___b_l_e___g_a_t_t_c___h_v_n___m_s_c.html", null ],
    [ "GATTC Primary Service Discovery", "group___b_l_e___g_a_t_t_c___p_r_i_m___s_r_v_c___d_i_s_c___m_s_c.html", null ],
    [ "GATTC Read Characteristic Value by UUID", "group___b_l_e___g_a_t_t_c___r_e_a_d___u_u_i_d___m_s_c.html", null ],
    [ "GATTC Read Multiple Characteristic Values", "group___b_l_e___g_a_t_t_c___r_e_a_d___m_u_l_t___m_s_c.html", null ],
    [ "GATTC Relationship Discovery", "group___b_l_e___g_a_t_t_c___r_e_l___d_i_s_c___m_s_c.html", null ],
    [ "GATTC Timeout", "group___b_l_e___g_a_t_t_c___t_i_m_e_o_u_t___m_s_c.html", null ]
];