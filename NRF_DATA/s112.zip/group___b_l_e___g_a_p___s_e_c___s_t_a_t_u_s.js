var group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s =
[
    [ "BLE_GAP_SEC_STATUS_AUTH_REQ", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gadf389ac11506ee7d7a0c6823d7c7cb5c", null ],
    [ "BLE_GAP_SEC_STATUS_BR_EDR_IN_PROG", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga5867ed6dd4420d1bce1ddfba79ada098", null ],
    [ "BLE_GAP_SEC_STATUS_CONFIRM_VALUE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga9d1c29d319e7b1b77d8bbae74760cfe5", null ],
    [ "BLE_GAP_SEC_STATUS_DHKEY_FAILURE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga606f38c4e93c3bf93fd404fa784aedbe", null ],
    [ "BLE_GAP_SEC_STATUS_ENC_KEY_SIZE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga3e8868907178ada2854635f2d7ca8ab0", null ],
    [ "BLE_GAP_SEC_STATUS_INVALID_PARAMS", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga609204cf12de8edbeaf29077a1c17ba7", null ],
    [ "BLE_GAP_SEC_STATUS_NUM_COMP_FAILURE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga1def532a9f51419f53fbcd59d8ffc58d", null ],
    [ "BLE_GAP_SEC_STATUS_OOB_NOT_AVAILABLE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gac29bfa067dbceb9b98e23aefcf0cc155", null ],
    [ "BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga87ed8db7604006675930bdf5fa79ae70", null ],
    [ "BLE_GAP_SEC_STATUS_PASSKEY_ENTRY_FAILED", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gab86b31f7e0c4a669cdffa4eb71bb0e89", null ],
    [ "BLE_GAP_SEC_STATUS_PDU_INVALID", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga6ba7df46db25ac8f2f2b1170106dda25", null ],
    [ "BLE_GAP_SEC_STATUS_REPEATED_ATTEMPTS", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga523c9c966eb5fa019fb265a9010775b0", null ],
    [ "BLE_GAP_SEC_STATUS_RFU_RANGE1_BEGIN", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gacb2c488250214a279dc71feb552f9a58", null ],
    [ "BLE_GAP_SEC_STATUS_RFU_RANGE1_END", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gaf5eb719ceb4bba8ae13cc9c4e39c0440", null ],
    [ "BLE_GAP_SEC_STATUS_RFU_RANGE2_BEGIN", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga18b6cd1a0a4f60acb6f90e07a18a500e", null ],
    [ "BLE_GAP_SEC_STATUS_RFU_RANGE2_END", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga45f923b09ac7cd4400114ebff42e9aa9", null ],
    [ "BLE_GAP_SEC_STATUS_SMP_CMD_UNSUPPORTED", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga7eb7986157fca57470acee71e5940d77", null ],
    [ "BLE_GAP_SEC_STATUS_SUCCESS", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#gaa0334dea24e449e5c28c88bbe8a1d00f", null ],
    [ "BLE_GAP_SEC_STATUS_TIMEOUT", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga4bdb61f7294a378778fe478597b17e07", null ],
    [ "BLE_GAP_SEC_STATUS_UNSPECIFIED", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga7e767feadf3f8ccef76faff23e12e4c9", null ],
    [ "BLE_GAP_SEC_STATUS_X_TRANS_KEY_DISALLOWED", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s.html#ga4d17554671db59d93242ee5b93867fa6", null ]
];