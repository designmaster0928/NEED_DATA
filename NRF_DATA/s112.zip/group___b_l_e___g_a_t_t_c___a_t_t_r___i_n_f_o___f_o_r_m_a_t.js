var group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t =
[
    [ "BLE_GATTC_ATTR_INFO_FORMAT_128BIT", "group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t.html#ga5f7dd0e9677bac47c656610407b2ba44", null ],
    [ "BLE_GATTC_ATTR_INFO_FORMAT_16BIT", "group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t.html#ga46f28b888b96db3e1fcc6217808f7bb3", null ]
];