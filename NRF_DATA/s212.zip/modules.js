var modules =
[
    [ "ANT STACK", "group__stack__ant__module.html", "group__stack__ant__module" ],
    [ "Master Boot Record API", "group__nrf__mbr__api.html", "group__nrf__mbr__api" ],
    [ "SoC Library API", "group__nrf__soc__api.html", "group__nrf__soc__api" ],
    [ "SoftDevice Global Error Codes", "group__nrf__error.html", "group__nrf__error" ],
    [ "SoftDevice Manager API", "group__nrf__sdm__api.html", "group__nrf__sdm__api" ],
    [ "SoftDevice NVIC API", "group__nrf__nvic__api.html", "group__nrf__nvic__api" ]
];