var searchData=
[
  ['master_20boot_20record_20api',['Master Boot Record API',['../group__nrf__mbr__api.html',1,'']]]
];
