var searchData=
[
  ['time_20base_20defines',['Time Base Defines',['../group___a_n_t___t_i_m_e___b_a_s_e.html',1,'']]],
  ['types',['Types',['../group___n_r_f___m_b_r___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___s_d_m___t_y_p_e_s.html',1,'']]],
  ['timeout_5fus',['timeout_us',['../structnrf__radio__request__earliest__t.html#af56601d1b7ef92d49dbd1567bd1d39e0',1,'nrf_radio_request_earliest_t']]],
  ['transfer_5fbusy',['TRANSFER_BUSY',['../group__ant__parameters.html#gaf7422213118cdccf3e2391dc834e6ee6',1,'ant_parameters.h']]],
  ['transfer_5fin_5ferror',['TRANSFER_IN_ERROR',['../group__ant__parameters.html#gabb130dbf5380067214dfb9652c229b66',1,'ant_parameters.h']]],
  ['transfer_5fin_5fprogress',['TRANSFER_IN_PROGRESS',['../group__ant__parameters.html#gae295711c3c6f5a87788c7dad6ef83da1',1,'ant_parameters.h']]],
  ['transfer_5fsequence_5fnumber_5ferror',['TRANSFER_SEQUENCE_NUMBER_ERROR',['../group__ant__parameters.html#gae578b7c324f2d9addad818e1b6df7d7e',1,'ant_parameters.h']]]
];
