var searchData=
[
  ['earliest',['earliest',['../structnrf__radio__request__t.html#a7ed176c3d465f35d68d00b70282bbb13',1,'nrf_radio_request_t']]],
  ['extend',['extend',['../structnrf__radio__signal__callback__return__param__t.html#ad4eeb817174355f7bec910d96f26a12d',1,'nrf_radio_signal_callback_return_param_t']]]
];
