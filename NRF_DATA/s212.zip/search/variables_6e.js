var searchData=
[
  ['normal',['normal',['../structnrf__radio__request__t.html#a140d30391ab57e9fbd4e98536d687e09',1,'nrf_radio_request_t']]],
  ['nrf_5fnvic_5fstate',['nrf_nvic_state',['../group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html#gae5ad2c570afdfbdd77336aec4e6097a7',1,'nrf_nvic.h']]]
];
