var searchData=
[
  ['dc_5fto_5fdc_5foff',['DC_TO_DC_OFF',['../group__ant__parameters.html#gadf6a9a06fd47808250d798ea4d589307',1,'ant_parameters.h']]],
  ['dc_5fto_5fdc_5fon',['DC_TO_DC_ON',['../group__ant__parameters.html#ga1a2b0f31cd1ae2548ba2d7182713b9c4',1,'ant_parameters.h']]],
  ['distance_5fus',['distance_us',['../structnrf__radio__request__normal__t.html#a34cb59c0e80b3698a3df265ab88b34b5',1,'nrf_radio_request_normal_t']]],
  ['dst',['dst',['../structsd__mbr__command__copy__sd__t.html#ae8afbb5ddb539bf7d5aa63102313210a',1,'sd_mbr_command_copy_sd_t']]],
  ['defines',['Defines',['../group___n_r_f___m_b_r___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___n_v_i_c___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___s_d_m___d_e_f_i_n_e_s.html',1,'']]],
  ['defines',['Defines',['../group___n_r_f___s_o_c___d_e_f_i_n_e_s.html',1,'']]]
];
