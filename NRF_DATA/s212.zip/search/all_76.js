var searchData=
[
  ['variables',['Variables',['../group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html',1,'']]]
];
