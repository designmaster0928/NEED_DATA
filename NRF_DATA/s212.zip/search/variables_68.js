var searchData=
[
  ['hfclk',['hfclk',['../structnrf__radio__request__earliest__t.html#a5d6e28106247179b7cde2e289f0f9c39',1,'nrf_radio_request_earliest_t::hfclk()'],['../structnrf__radio__request__normal__t.html#a23b414675dc9b11671f55601075f541d',1,'nrf_radio_request_normal_t::hfclk()']]]
];
