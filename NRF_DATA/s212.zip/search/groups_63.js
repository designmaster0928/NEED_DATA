var searchData=
[
  ['crc_20mode_20defines',['CRC Mode Defines',['../group___c_r_c___m_o_d_e.html',1,'']]],
  ['clock_20accuracy',['Clock accuracy',['../group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html',1,'']]]
];
