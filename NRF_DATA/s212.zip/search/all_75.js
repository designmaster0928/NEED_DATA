var searchData=
[
  ['ucgpio',['ucGPIO',['../struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#aa8b13d0c9f6a019d3c123a2cbf7d7450',1,'ANT_PA_LNA_CONFIG']]],
  ['ucgpiotech',['ucGPIOTECh',['../struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a1d4077de1de03753c4095838ce9c6d28',1,'ANT_PA_LNA_CONFIG']]],
  ['ucinvalidationbyte',['ucInvalidationByte',['../struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html#a8f530d966373e237d2dd874660dd3fd4',1,'ANT_TIME_SYNC_CONFIG']]],
  ['ucppichdisable',['ucPPIChDisable',['../struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a10f4c24f15fc1e19132fa3ea3676ceb5',1,'ANT_PA_LNA_CONFIG']]],
  ['ucppichenable',['ucPPIChEnable',['../struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a869ebfe780bef4d5a3aea8a660ee99b9',1,'ANT_PA_LNA_CONFIG']]],
  ['ucsearchsuppressionwindows',['ucSearchSuppressionWindows',['../struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html#adab18d66ab35432906448f66753a8aa2',1,'ANT_HIGH_DUTY_SEARCH_CONFIG']]],
  ['uctimebase',['ucTimeBase',['../struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g.html#a414671400ef1c8f8b203226b534d0948',1,'ANT_TIME_STAMP_CONFIG::ucTimeBase()'],['../struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html#a04def2c6a12c359e8c3e129ab578bf6c',1,'ANT_TIME_SYNC_CONFIG::ucTimeBase()']]],
  ['usrestartinterval',['usRestartInterval',['../struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html#a7b57271df43d97bdf7f455cd9fee5deb',1,'ANT_HIGH_DUTY_SEARCH_CONFIG']]]
];
