var searchData=
[
  ['soc_5fecb_5fciphertext_5ft',['soc_ecb_ciphertext_t',['../group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html#ga0794007164d3d953afd7c4c89634f5b1',1,'nrf_soc.h']]],
  ['soc_5fecb_5fcleartext_5ft',['soc_ecb_cleartext_t',['../group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html#gad77c8c82095644be12ed5a41433c731f',1,'nrf_soc.h']]],
  ['soc_5fecb_5fkey_5ft',['soc_ecb_key_t',['../group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html#gaee4c3512b3ebb503d3a5495938267644',1,'nrf_soc.h']]]
];
