var searchData=
[
  ['nrf_5ffault_5fhandler_5ft',['nrf_fault_handler_t',['../group___n_r_f___s_d_m___t_y_p_e_s.html#gadf2985918ea04b8d056c797125d0fa33',1,'nrf_sdm.h']]],
  ['nrf_5fmutex_5ft',['nrf_mutex_t',['../group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html#gaa1ec46ac9de000227852834ec1ff86ea',1,'nrf_soc.h']]],
  ['nrf_5fradio_5fsignal_5fcallback_5ft',['nrf_radio_signal_callback_t',['../group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html#gaf5319fc8ecbc011eca84a187f0a4da54',1,'nrf_soc.h']]]
];
