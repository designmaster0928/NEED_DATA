var searchData=
[
  ['rc_5fctiv',['rc_ctiv',['../structnrf__clock__lf__cfg__t.html#a68174ef9ad43f1f8ce7baceb90bf81cd',1,'nrf_clock_lf_cfg_t']]],
  ['rc_5ftemp_5fctiv',['rc_temp_ctiv',['../structnrf__clock__lf__cfg__t.html#addcf6cd221b58ea20dea003cdf6951a0',1,'nrf_clock_lf_cfg_t']]],
  ['request',['request',['../structnrf__radio__signal__callback__return__param__t.html#a4cdd9839bf8a2917fd0798ea419e1f57',1,'nrf_radio_signal_callback_return_param_t']]],
  ['request_5ftype',['request_type',['../structnrf__radio__request__t.html#af6c3fb2f810242bef92760745327f718',1,'nrf_radio_request_t']]]
];
