var structnrf__nvic__state__t =
[
    [ "__cr_flag", "structnrf__nvic__state__t.html#ab98e73a38a7559b6b1b6ed52604603d4", null ],
    [ "__irq_masks", "structnrf__nvic__state__t.html#a83f0c50a94c6687bea375ffb98d76f89", null ]
];