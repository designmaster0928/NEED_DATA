var structsd__mbr__command__copy__bl__t =
[
    [ "bl_len", "structsd__mbr__command__copy__bl__t.html#a197755f22bcc92adc7c8288f48bd9ef8", null ],
    [ "bl_src", "structsd__mbr__command__copy__bl__t.html#a504481143eb43e52488288d7de70a6f1", null ]
];