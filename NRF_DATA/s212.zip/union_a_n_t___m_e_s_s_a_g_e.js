var union_a_n_t___m_e_s_s_a_g_e =
[
    [ "aucExtData", "union_a_n_t___m_e_s_s_a_g_e.html#a1322209a67f638d3381fdd63fe8bde46", null ],
    [ "aucFramedData", "union_a_n_t___m_e_s_s_a_g_e.html#a1b80aea7ddb647e3b709f6859090aa35", null ],
    [ "aucMesgData", "union_a_n_t___m_e_s_s_a_g_e.html#ad66a10082b066aa8bdbc91a65319c339", null ],
    [ "aucMessage", "union_a_n_t___m_e_s_s_a_g_e.html#abdaebe6b4e083fbad9bc88f628f077bb", null ],
    [ "aucPayload", "union_a_n_t___m_e_s_s_a_g_e.html#a5637fd09197781428b048e31104ae437", null ],
    [ "sExtMesgBF", "union_a_n_t___m_e_s_s_a_g_e.html#a327d90a8fdf2ed266f6c56128742d425", null ],
    [ "stFramedData", "union_a_n_t___m_e_s_s_a_g_e.html#a595dbcb9b5832302a6521315d41522b9", null ],
    [ "stMesgData", "union_a_n_t___m_e_s_s_a_g_e.html#ac7d1342cfa7acc5a4e489266c90d2975", null ],
    [ "stMessage", "union_a_n_t___m_e_s_s_a_g_e.html#aefa76ba67aaf85fd04cf5149ce9a1e18", null ],
    [ "ucChannel", "union_a_n_t___m_e_s_s_a_g_e.html#a36f6215450920746f6e0ee319c810259", null ],
    [ "ucCheckSum", "union_a_n_t___m_e_s_s_a_g_e.html#acb404a2c6960014307f8c7428684f233", null ],
    [ "ucMesgID", "union_a_n_t___m_e_s_s_a_g_e.html#a756f9e6482c170f110beced3f96c327f", null ],
    [ "ucSize", "union_a_n_t___m_e_s_s_a_g_e.html#aefe47590f5100483e7eba301aeffbd48", null ],
    [ "ucSubID", "union_a_n_t___m_e_s_s_a_g_e.html#a7714dd582fb8c245f23b6b0aeeecf4dd", null ],
    [ "uData0", "union_a_n_t___m_e_s_s_a_g_e.html#ab9c461b1acb5cbd1678d5329ff148296", null ],
    [ "uFramedData", "union_a_n_t___m_e_s_s_a_g_e.html#a18f30497ace6a0911f7eebda61daa0b1", null ],
    [ "ulForceAlign", "union_a_n_t___m_e_s_s_a_g_e.html#a85bedf28555019f715138dbf597d2d65", null ],
    [ "uMesgData", "union_a_n_t___m_e_s_s_a_g_e.html#a89c6f01535a644aa5d8ef017ce6c5522", null ]
];