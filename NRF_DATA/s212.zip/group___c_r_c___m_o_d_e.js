var group___c_r_c___m_o_d_e =
[
    [ "CRC_MODE_3BYTE", "group___c_r_c___m_o_d_e.html#ga6187f8225e4af0d9148242521e7762ec", null ],
    [ "CRC_MODE_STANDARD_ANT", "group___c_r_c___m_o_d_e.html#gaaef2e346f39e4a7a7ee7a7ab9c075b77", null ]
];