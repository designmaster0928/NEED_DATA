var structnrf__radio__signal__callback__return__param__t =
[
    [ "callback_action", "structnrf__radio__signal__callback__return__param__t.html#ac938534ea4bdd342a3cb36c94071e073", null ],
    [ "extend", "structnrf__radio__signal__callback__return__param__t.html#ad4eeb817174355f7bec910d96f26a12d", null ],
    [ "length_us", "structnrf__radio__signal__callback__return__param__t.html#ae6f6fa462f50a24ee278512c394beb46", null ],
    [ "p_next", "structnrf__radio__signal__callback__return__param__t.html#a3f55c9628d7b2e8dbecb594a49eb4a34", null ],
    [ "params", "structnrf__radio__signal__callback__return__param__t.html#a4f40b5b63cc5d39882fe3075f9e7388b", null ],
    [ "request", "structnrf__radio__signal__callback__return__param__t.html#a4cdd9839bf8a2917fd0798ea419e1f57", null ]
];