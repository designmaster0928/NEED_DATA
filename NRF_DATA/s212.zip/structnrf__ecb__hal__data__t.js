var structnrf__ecb__hal__data__t =
[
    [ "ciphertext", "structnrf__ecb__hal__data__t.html#a48a624e3dbca725607625d26a01a85c8", null ],
    [ "cleartext", "structnrf__ecb__hal__data__t.html#aec3138ce902faf5073942181e004246b", null ],
    [ "key", "structnrf__ecb__hal__data__t.html#a7f908f0e165579fff30d8ca927dcd7aa", null ]
];