var struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g =
[
    [ "bEnable", "struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html#a6673003614f110531cfe936e5c09d811", null ],
    [ "ucSearchSuppressionWindows", "struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html#adab18d66ab35432906448f66753a8aa2", null ],
    [ "usRestartInterval", "struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html#a7b57271df43d97bdf7f455cd9fee5deb", null ]
];