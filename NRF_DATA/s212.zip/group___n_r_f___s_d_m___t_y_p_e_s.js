var group___n_r_f___s_d_m___t_y_p_e_s =
[
    [ "nrf_clock_lf_cfg_t", "structnrf__clock__lf__cfg__t.html", [
      [ "accuracy", "structnrf__clock__lf__cfg__t.html#aa5930ce90d5c54915eaee71fbcc5d4ca", null ],
      [ "rc_ctiv", "structnrf__clock__lf__cfg__t.html#a68174ef9ad43f1f8ce7baceb90bf81cd", null ],
      [ "rc_temp_ctiv", "structnrf__clock__lf__cfg__t.html#addcf6cd221b58ea20dea003cdf6951a0", null ],
      [ "source", "structnrf__clock__lf__cfg__t.html#af5d317705e2f53ed81c81bc8c1fcd4ec", null ]
    ] ],
    [ "nrf_fault_handler_t", "group___n_r_f___s_d_m___t_y_p_e_s.html#gadf2985918ea04b8d056c797125d0fa33", null ]
];