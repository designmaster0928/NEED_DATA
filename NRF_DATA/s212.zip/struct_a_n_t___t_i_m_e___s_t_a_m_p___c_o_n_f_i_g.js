var struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g =
[
    [ "bTimeStampEnabled", "struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g.html#a48f391e4d04e3d5bbb3e8ca72428a0a1", null ],
    [ "ucTimeBase", "struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g.html#a414671400ef1c8f8b203226b534d0948", null ]
];