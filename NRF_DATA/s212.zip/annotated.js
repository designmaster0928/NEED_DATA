var annotated =
[
    [ "ANT_BUFFER_PTR", "struct_a_n_t___b_u_f_f_e_r___p_t_r.html", "struct_a_n_t___b_u_f_f_e_r___p_t_r" ],
    [ "ANT_ENABLE", "struct_a_n_t___e_n_a_b_l_e.html", "struct_a_n_t___e_n_a_b_l_e" ],
    [ "ANT_HIGH_DUTY_SEARCH_CONFIG", "struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g.html", "struct_a_n_t___h_i_g_h___d_u_t_y___s_e_a_r_c_h___c_o_n_f_i_g" ],
    [ "ANT_MESSAGE", "union_a_n_t___m_e_s_s_a_g_e.html", "union_a_n_t___m_e_s_s_a_g_e" ],
    [ "ANT_PA_LNA_CONFIG", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g" ],
    [ "ANT_TIME_STAMP_CONFIG", "struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g.html", "struct_a_n_t___t_i_m_e___s_t_a_m_p___c_o_n_f_i_g" ],
    [ "ANT_TIME_SYNC_CONFIG", "struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html", "struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g" ],
    [ "nrf_clock_lf_cfg_t", "structnrf__clock__lf__cfg__t.html", "structnrf__clock__lf__cfg__t" ],
    [ "nrf_ecb_hal_data_block_t", "structnrf__ecb__hal__data__block__t.html", "structnrf__ecb__hal__data__block__t" ],
    [ "nrf_ecb_hal_data_t", "structnrf__ecb__hal__data__t.html", "structnrf__ecb__hal__data__t" ],
    [ "nrf_nvic_state_t", "structnrf__nvic__state__t.html", "structnrf__nvic__state__t" ],
    [ "nrf_radio_request_earliest_t", "structnrf__radio__request__earliest__t.html", "structnrf__radio__request__earliest__t" ],
    [ "nrf_radio_request_normal_t", "structnrf__radio__request__normal__t.html", "structnrf__radio__request__normal__t" ],
    [ "nrf_radio_request_t", "structnrf__radio__request__t.html", "structnrf__radio__request__t" ],
    [ "nrf_radio_signal_callback_return_param_t", "structnrf__radio__signal__callback__return__param__t.html", "structnrf__radio__signal__callback__return__param__t" ],
    [ "sd_mbr_command_compare_t", "structsd__mbr__command__compare__t.html", "structsd__mbr__command__compare__t" ],
    [ "sd_mbr_command_copy_bl_t", "structsd__mbr__command__copy__bl__t.html", "structsd__mbr__command__copy__bl__t" ],
    [ "sd_mbr_command_copy_sd_t", "structsd__mbr__command__copy__sd__t.html", "structsd__mbr__command__copy__sd__t" ],
    [ "sd_mbr_command_irq_forward_address_set_t", "structsd__mbr__command__irq__forward__address__set__t.html", "structsd__mbr__command__irq__forward__address__set__t" ],
    [ "sd_mbr_command_t", "structsd__mbr__command__t.html", "structsd__mbr__command__t" ],
    [ "sd_mbr_command_vector_table_base_set_t", "structsd__mbr__command__vector__table__base__set__t.html", "structsd__mbr__command__vector__table__base__set__t" ]
];