var struct_a_n_t___e_n_a_b_l_e =
[
    [ "pucMemoryBlockStartLocation", "struct_a_n_t___e_n_a_b_l_e.html#a4c5a4f89c53df5f359475b1e85aaba04", null ],
    [ "ucNumberOfEncryptedChannels", "struct_a_n_t___e_n_a_b_l_e.html#ae5bf69e1d2fd8d795cd6f0b16e1b42c6", null ],
    [ "ucTotalNumberOfChannels", "struct_a_n_t___e_n_a_b_l_e.html#a4949aad357a89f8c3df24c63ce59247d", null ],
    [ "usMemoryBlockByteSize", "struct_a_n_t___e_n_a_b_l_e.html#ab2bef95b701062d5d882b319f7518c25", null ],
    [ "usNumberOfEvents", "struct_a_n_t___e_n_a_b_l_e.html#aaad65db75a5620a140e0c672d212710d", null ]
];