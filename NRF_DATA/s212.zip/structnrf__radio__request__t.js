var structnrf__radio__request__t =
[
    [ "earliest", "structnrf__radio__request__t.html#a7ed176c3d465f35d68d00b70282bbb13", null ],
    [ "normal", "structnrf__radio__request__t.html#a140d30391ab57e9fbd4e98536d687e09", null ],
    [ "params", "structnrf__radio__request__t.html#af9595436d8725eabc800e67e8563a88a", null ],
    [ "request_type", "structnrf__radio__request__t.html#af6c3fb2f810242bef92760745327f718", null ]
];