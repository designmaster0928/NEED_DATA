var structnrf__ecb__hal__data__block__t =
[
    [ "p_ciphertext", "structnrf__ecb__hal__data__block__t.html#ad2a9509291fc81b16e6b12b6695f36c1", null ],
    [ "p_cleartext", "structnrf__ecb__hal__data__block__t.html#a629ca2c072a7d4f7023a46bbecae0997", null ],
    [ "p_key", "structnrf__ecb__hal__data__block__t.html#a54cfe9ba7411ea89fb232e12482832bc", null ]
];