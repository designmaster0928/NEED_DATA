var structnrf__radio__request__normal__t =
[
    [ "distance_us", "structnrf__radio__request__normal__t.html#a34cb59c0e80b3698a3df265ab88b34b5", null ],
    [ "hfclk", "structnrf__radio__request__normal__t.html#a23b414675dc9b11671f55601075f541d", null ],
    [ "length_us", "structnrf__radio__request__normal__t.html#adf9603de0e582965d4bb1c0a42d8e88c", null ],
    [ "priority", "structnrf__radio__request__normal__t.html#a18cc5dd5dc34877572e42ee8102fcb82", null ]
];