var struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g =
[
    [ "bActiveState", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a82058ad01e176f143856a171c3c87529", null ],
    [ "bEnabled", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a040297c8589422084aa9f2095726a58e", null ],
    [ "LNA_CONFIG", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#ac96c4e0c7ae5bd28df1ce9137b61877e", null ],
    [ "PA_CONFIG", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a31a9c47d7748404bf903a0463883f91c", null ],
    [ "ucGPIO", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#aa8b13d0c9f6a019d3c123a2cbf7d7450", null ],
    [ "ucGPIOTECh", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a1d4077de1de03753c4095838ce9c6d28", null ],
    [ "ucPPIChDisable", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a10f4c24f15fc1e19132fa3ea3676ceb5", null ],
    [ "ucPPIChEnable", "struct_a_n_t___p_a___l_n_a___c_o_n_f_i_g.html#a869ebfe780bef4d5a3aea8a660ee99b9", null ]
];