var structsd__mbr__command__copy__sd__t =
[
    [ "dst", "structsd__mbr__command__copy__sd__t.html#ae8afbb5ddb539bf7d5aa63102313210a", null ],
    [ "len", "structsd__mbr__command__copy__sd__t.html#a36ada23cb97fb5ec6873d262689cbfdb", null ],
    [ "src", "structsd__mbr__command__copy__sd__t.html#a7fab268f5a8db5b0ccc3a4b85d47c0b7", null ]
];