var structnrf__clock__lf__cfg__t =
[
    [ "accuracy", "structnrf__clock__lf__cfg__t.html#aa5930ce90d5c54915eaee71fbcc5d4ca", null ],
    [ "rc_ctiv", "structnrf__clock__lf__cfg__t.html#a68174ef9ad43f1f8ce7baceb90bf81cd", null ],
    [ "rc_temp_ctiv", "structnrf__clock__lf__cfg__t.html#addcf6cd221b58ea20dea003cdf6951a0", null ],
    [ "source", "structnrf__clock__lf__cfg__t.html#af5d317705e2f53ed81c81bc8c1fcd4ec", null ]
];