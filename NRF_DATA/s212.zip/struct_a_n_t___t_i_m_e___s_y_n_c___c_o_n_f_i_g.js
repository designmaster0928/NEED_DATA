var struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g =
[
    [ "bInvalidationEnabled", "struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html#a861ec78fe09708e0ff029cb9ca0719f9", null ],
    [ "ucInvalidationByte", "struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html#a8f530d966373e237d2dd874660dd3fd4", null ],
    [ "ucTimeBase", "struct_a_n_t___t_i_m_e___s_y_n_c___c_o_n_f_i_g.html#a04def2c6a12c359e8c3e129ab578bf6c", null ]
];