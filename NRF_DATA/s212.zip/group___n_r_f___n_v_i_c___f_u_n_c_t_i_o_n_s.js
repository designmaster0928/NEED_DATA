var group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s =
[
    [ "sd_nvic_ClearPendingIRQ", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gaaab82d624bd21852288a3a6ad178cec7", null ],
    [ "sd_nvic_critical_region_enter", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gac3d990530890d81f388de7d507e170b8", null ],
    [ "sd_nvic_critical_region_exit", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#ga7bcafdd2cd546560174d688fdbeda7dd", null ],
    [ "sd_nvic_DisableIRQ", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gae4a37ba1f3e17d21cb0c5360fbcbfdbf", null ],
    [ "sd_nvic_EnableIRQ", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#ga02345fceba00ae870acefa61a322f5a2", null ],
    [ "sd_nvic_GetPendingIRQ", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gaef5164aef25dcabe8d58e4d0e8753995", null ],
    [ "sd_nvic_GetPriority", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gacfb8b86fa10fca62b0a30fdc49c3c78a", null ],
    [ "sd_nvic_SetPendingIRQ", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#ga9b1ed18c3f856d229726c8eb1b8d676e", null ],
    [ "sd_nvic_SetPriority", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#ga1f6d15a8df153e1f40ab27ffe049efd6", null ],
    [ "sd_nvic_SystemReset", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html#gad767473c9cfb8cf11c66f048e0d9eb5c", null ]
];