var struct_a_n_t___b_u_f_f_e_r___p_t_r =
[
    [ "pucBuffer", "struct_a_n_t___b_u_f_f_e_r___p_t_r.html#a7af9170d5fa2781764d50e7969403f4a", null ],
    [ "ucBufferSize", "struct_a_n_t___b_u_f_f_e_r___p_t_r.html#aef4a3b235540426f94c2e49b430ff9c5", null ]
];