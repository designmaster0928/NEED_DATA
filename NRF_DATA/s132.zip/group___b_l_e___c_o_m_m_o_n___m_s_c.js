var group___b_l_e___c_o_m_m_o_n___m_s_c =
[
    [ "BLE Stack Enable", "group___b_l_e___c_o_m_m_o_n___e_n_a_b_l_e.html", null ],
    [ "Connection Configuration", "group___b_l_e___c_o_n_n___c_f_g.html", null ],
    [ "Interrupt-driven Event Retrieval", "group___b_l_e___c_o_m_m_o_n___i_r_q___e_v_t___m_s_c.html", null ],
    [ "Thread Mode Event Retrieval", "group___b_l_e___c_o_m_m_o_n___t_h_r_e_a_d___e_v_t___m_s_c.html", null ]
];