var group___b_l_e___g_a_p =
[
    [ "Characteristic inclusion default values", "group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g___d_e_f_a_u_l_t_s.html", "group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g___d_e_f_a_u_l_t_s" ],
    [ "Defines", "group___b_l_e___g_a_p___d_e_f_i_n_e_s.html", "group___b_l_e___g_a_p___d_e_f_i_n_e_s" ],
    [ "Enumerations", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s" ],
    [ "Functions", "group___b_l_e___g_a_p___f_u_n_c_t_i_o_n_s.html", "group___b_l_e___g_a_p___f_u_n_c_t_i_o_n_s" ],
    [ "GAP Characteristic inclusion configurations", "group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g.html", "group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g" ],
    [ "Message Sequence Charts", "group___b_l_e___g_a_p___m_s_c.html", "group___b_l_e___g_a_p___m_s_c" ],
    [ "Structures", "group___b_l_e___g_a_p___s_t_r_u_c_t_u_r_e_s.html", "group___b_l_e___g_a_p___s_t_r_u_c_t_u_r_e_s" ]
];