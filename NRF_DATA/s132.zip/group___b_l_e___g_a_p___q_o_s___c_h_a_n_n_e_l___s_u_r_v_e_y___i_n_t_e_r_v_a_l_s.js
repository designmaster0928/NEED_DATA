var group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s =
[
    [ "BLE_GAP_QOS_CHANNEL_SURVEY_INTERVAL_CONTINUOUS", "group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s.html#gaf493ceba805638c014d6f44b7a2eeefb", null ],
    [ "BLE_GAP_QOS_CHANNEL_SURVEY_INTERVAL_MAX_US", "group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s.html#gafbdb9de8fdcbf8263c4cc93c5b7b9f34", null ],
    [ "BLE_GAP_QOS_CHANNEL_SURVEY_INTERVAL_MIN_US", "group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s.html#ga7cbe9260d873baba3492fd6d5e74cb30", null ]
];