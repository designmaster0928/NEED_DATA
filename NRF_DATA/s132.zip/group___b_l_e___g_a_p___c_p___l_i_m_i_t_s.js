var group___b_l_e___g_a_p___c_p___l_i_m_i_t_s =
[
    [ "BLE_GAP_CP_CONN_SUP_TIMEOUT_MAX", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga1db7005189c241b0eba9209103bddc8d", null ],
    [ "BLE_GAP_CP_CONN_SUP_TIMEOUT_MIN", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#gad6c79a8455ea1155d03321f3379dd415", null ],
    [ "BLE_GAP_CP_CONN_SUP_TIMEOUT_NONE", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga86dea9b13bb39d0f50ee2c6e12184864", null ],
    [ "BLE_GAP_CP_MAX_CONN_INTVL_MAX", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga6bf5d65e6d586000cd5f7ba43c0d2e76", null ],
    [ "BLE_GAP_CP_MAX_CONN_INTVL_MIN", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#gac6071964ea94ef548da1beaf23f032da", null ],
    [ "BLE_GAP_CP_MAX_CONN_INTVL_NONE", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#gadda6e71a42de04bd48870afcad38a81c", null ],
    [ "BLE_GAP_CP_MIN_CONN_INTVL_MAX", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga6ec422217d939654d1dd252abd169d82", null ],
    [ "BLE_GAP_CP_MIN_CONN_INTVL_MIN", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga7995b13da25ea7cd40a21da59306def9", null ],
    [ "BLE_GAP_CP_MIN_CONN_INTVL_NONE", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga9b7880da1b563d33b45f68cfdd9f6d1d", null ],
    [ "BLE_GAP_CP_SLAVE_LATENCY_MAX", "group___b_l_e___g_a_p___c_p___l_i_m_i_t_s.html#ga122ace1cb2bbc5e346ae167e48f7e07e", null ]
];