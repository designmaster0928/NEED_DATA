var group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s___s_o_u_r_c_e_s =
[
    [ "BLE_GAP_SEC_STATUS_SOURCE_LOCAL", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s___s_o_u_r_c_e_s.html#ga7c6035361c3893781b15f788954ea564", null ],
    [ "BLE_GAP_SEC_STATUS_SOURCE_REMOTE", "group___b_l_e___g_a_p___s_e_c___s_t_a_t_u_s___s_o_u_r_c_e_s.html#gacd7d314e3a27338396a80cf38c71f1e2", null ]
];