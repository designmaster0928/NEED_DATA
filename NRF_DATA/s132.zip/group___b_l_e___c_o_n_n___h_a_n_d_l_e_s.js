var group___b_l_e___c_o_n_n___h_a_n_d_l_e_s =
[
    [ "BLE_CONN_HANDLE_ALL", "group___b_l_e___c_o_n_n___h_a_n_d_l_e_s.html#ga75e3958065c393f536bd316877892997", null ],
    [ "BLE_CONN_HANDLE_INVALID", "group___b_l_e___c_o_n_n___h_a_n_d_l_e_s.html#gacf227b9b101dbcf08eccbbaba54e48f5", null ]
];