var group__nrf__nvic__api =
[
    [ "Defines", "group___n_r_f___n_v_i_c___d_e_f_i_n_e_s.html", "group___n_r_f___n_v_i_c___d_e_f_i_n_e_s" ],
    [ "SoftDevice NVIC internal functions", "group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s.html", "group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s" ],
    [ "SoftDevice NVIC public functions", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s.html", "group___n_r_f___n_v_i_c___f_u_n_c_t_i_o_n_s" ],
    [ "Variables", "group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html", "group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s" ]
];