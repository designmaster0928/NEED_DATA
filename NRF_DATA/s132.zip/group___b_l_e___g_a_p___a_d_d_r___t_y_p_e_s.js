var group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s =
[
    [ "BLE_GAP_ADDR_TYPE_ANONYMOUS", "group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s.html#ga5d7eff9255bbdd944d15681c246ea074", null ],
    [ "BLE_GAP_ADDR_TYPE_PUBLIC", "group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s.html#gaa5e499423d88b16817efd4d5ec10fd6e", null ],
    [ "BLE_GAP_ADDR_TYPE_RANDOM_PRIVATE_NON_RESOLVABLE", "group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s.html#ga86fe5e506ba152ec4d60ac6daaca2aef", null ],
    [ "BLE_GAP_ADDR_TYPE_RANDOM_PRIVATE_RESOLVABLE", "group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s.html#gae166d654401b0ed83ad7073f31467b70", null ],
    [ "BLE_GAP_ADDR_TYPE_RANDOM_STATIC", "group___b_l_e___g_a_p___a_d_d_r___t_y_p_e_s.html#gabe27b8f22c3a52413fa064c2ee1e4fba", null ]
];