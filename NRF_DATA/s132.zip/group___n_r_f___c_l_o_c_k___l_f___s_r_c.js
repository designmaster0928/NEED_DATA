var group___n_r_f___c_l_o_c_k___l_f___s_r_c =
[
    [ "NRF_CLOCK_LF_SRC_RC", "group___n_r_f___c_l_o_c_k___l_f___s_r_c.html#gac5af0958064c212f19db190b8ad1e7e6", null ],
    [ "NRF_CLOCK_LF_SRC_SYNTH", "group___n_r_f___c_l_o_c_k___l_f___s_r_c.html#ga814440bfe9a39511358d281a6211ccd2", null ],
    [ "NRF_CLOCK_LF_SRC_XTAL", "group___n_r_f___c_l_o_c_k___l_f___s_r_c.html#ga864bb1cea3623d59d8b84eee306b586c", null ]
];