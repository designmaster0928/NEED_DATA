var group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y =
[
    [ "NRF_CLOCK_LF_ACCURACY_100_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga025489cebb5b4fa699a3e70fd4df4da3", null ],
    [ "NRF_CLOCK_LF_ACCURACY_10_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga15e26e1b2a0c9e6a654a9d74230ae0ae", null ],
    [ "NRF_CLOCK_LF_ACCURACY_150_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#gafa2ac40b59bfdb0b8881f44a0e2b3e50", null ],
    [ "NRF_CLOCK_LF_ACCURACY_1_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga5a3e6872fcd9953de8b6629eb34d3938", null ],
    [ "NRF_CLOCK_LF_ACCURACY_20_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga78d6418d2185d214e04ea05c559786dd", null ],
    [ "NRF_CLOCK_LF_ACCURACY_250_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#gabfe17b605c8edb7ce45fae55ee405ee8", null ],
    [ "NRF_CLOCK_LF_ACCURACY_2_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga83843b8633c42d2fd1f612717dbb2056", null ],
    [ "NRF_CLOCK_LF_ACCURACY_30_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga3c464eb785d0e68ea15bf15c77a66293", null ],
    [ "NRF_CLOCK_LF_ACCURACY_500_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga4abbe889ab90f5a8da00fe8175227ff7", null ],
    [ "NRF_CLOCK_LF_ACCURACY_50_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga97f8942be6be11f94c5873c0bcd312bb", null ],
    [ "NRF_CLOCK_LF_ACCURACY_5_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#gafbeee3ee0f2876c4cd9b752e089d8110", null ],
    [ "NRF_CLOCK_LF_ACCURACY_75_PPM", "group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html#ga7895e9b1ea28b6fbc7117002ba204cec", null ]
];