var group__nrf__sdm__api =
[
    [ "Defines", "group___n_r_f___s_d_m___d_e_f_i_n_e_s.html", "group___n_r_f___s_d_m___d_e_f_i_n_e_s" ],
    [ "Enumerations", "group___n_r_f___s_d_m___e_n_u_m_s.html", "group___n_r_f___s_d_m___e_n_u_m_s" ],
    [ "Functions", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s.html", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s" ],
    [ "SoftDevice Manager Error Codes", "group__nrf__sdm__error.html", "group__nrf__sdm__error" ],
    [ "Types", "group___n_r_f___s_d_m___t_y_p_e_s.html", "group___n_r_f___s_d_m___t_y_p_e_s" ]
];