var group___b_l_e___g_a_p___a_d_v___i_n_t_e_r_v_a_l_s =
[
    [ "BLE_GAP_ADV_INTERVAL_MAX", "group___b_l_e___g_a_p___a_d_v___i_n_t_e_r_v_a_l_s.html#gada06c7f328e5bcc50ce55f9f567129ca", null ],
    [ "BLE_GAP_ADV_INTERVAL_MIN", "group___b_l_e___g_a_p___a_d_v___i_n_t_e_r_v_a_l_s.html#gaf61691584387648b33a032c934bcd094", null ]
];