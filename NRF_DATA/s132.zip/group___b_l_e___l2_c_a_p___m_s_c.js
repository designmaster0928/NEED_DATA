var group___b_l_e___l2_c_a_p___m_s_c =
[
    [ "L2CAP Channel Release", "group___b_l_e___l2_c_a_p___c_h___r_e_l_e_a_s_e___m_s_c.html", null ],
    [ "L2CAP Channel SDU Receive", "group___b_l_e___l2_c_a_p___c_h___r_x___m_s_c.html", null ],
    [ "L2CAP Channel SDU Transmit", "group___b_l_e___l2_c_a_p___c_h___t_x___m_s_c.html", null ],
    [ "L2CAP Channel Setup", "group___b_l_e___l2_c_a_p___c_h___s_e_t_u_p___m_s_c.html", null ],
    [ "L2CAP Channel advanced SDU reception flow control", "group___b_l_e___l2_c_a_p___c_h___f_l_o_w___c_o_n_t_r_o_l___m_s_c.html", null ]
];