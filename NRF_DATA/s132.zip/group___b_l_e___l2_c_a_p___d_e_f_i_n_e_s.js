var group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s =
[
    [ "L2CAP channel setup refused sources", "group___b_l_e___l2_c_a_p___c_h___s_e_t_u_p___r_e_f_u_s_e_d___s_r_c_s.html", "group___b_l_e___l2_c_a_p___c_h___s_e_t_u_p___r_e_f_u_s_e_d___s_r_c_s" ],
    [ "L2CAP channel status codes", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s" ],
    [ "BLE_L2CAP_CH_COUNT_MAX", "group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s.html#ga5a9add5fb372e9a38786f73c6a76aaf9", null ],
    [ "BLE_L2CAP_CID_INVALID", "group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s.html#gaf3346d406893055ab1cb3cf04ce094c6", null ],
    [ "BLE_L2CAP_CREDITS_DEFAULT", "group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s.html#ga6f1e1ede53d001dd5fac3670a0821fe8", null ],
    [ "BLE_L2CAP_MPS_MIN", "group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s.html#ga5db1c1ed0d1a1731b46ad351c78984e2", null ],
    [ "BLE_L2CAP_MTU_MIN", "group___b_l_e___l2_c_a_p___d_e_f_i_n_e_s.html#ga0dd8d62a4cc9ae136ecd57941e5f9bee", null ]
];