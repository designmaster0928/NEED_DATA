var group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s =
[
    [ "sd_softdevice_disable", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s.html#ga45900ecbe6d5ebf9ae78894fe6c75b23", null ],
    [ "sd_softdevice_enable", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s.html#ga3a235464e93f7bdd9297dd78723d4c93", null ],
    [ "sd_softdevice_is_enabled", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s.html#ga830210fec2b272bbd27af26e3b314d35", null ],
    [ "sd_softdevice_vector_table_base_set", "group___n_r_f___s_d_m___f_u_n_c_t_i_o_n_s.html#ga46d2ce943076d65947ea8919198be106", null ]
];