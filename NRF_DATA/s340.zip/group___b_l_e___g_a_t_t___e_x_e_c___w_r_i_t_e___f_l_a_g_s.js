var group___b_l_e___g_a_t_t___e_x_e_c___w_r_i_t_e___f_l_a_g_s =
[
    [ "BLE_GATT_EXEC_WRITE_FLAG_PREPARED_CANCEL", "group___b_l_e___g_a_t_t___e_x_e_c___w_r_i_t_e___f_l_a_g_s.html#gafad654e82156e3953a749394c4989a1b", null ],
    [ "BLE_GATT_EXEC_WRITE_FLAG_PREPARED_WRITE", "group___b_l_e___g_a_t_t___e_x_e_c___w_r_i_t_e___f_l_a_g_s.html#ga40747f153640ff0bdaab2d69eef8647e", null ]
];