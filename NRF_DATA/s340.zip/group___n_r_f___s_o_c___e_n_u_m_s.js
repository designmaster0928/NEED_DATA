var group___n_r_f___s_o_c___e_n_u_m_s =
[
    [ "NRF_MUTEX_VALUES", "group___n_r_f___s_o_c___e_n_u_m_s.html#gad6257be893447873c6b1c0b43cdcecf3", null ],
    [ "NRF_POWER_DCDC_MODES", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga0c5eb0d4a7014099e3410521358585a7", [
      [ "NRF_POWER_DCDC_DISABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga0c5eb0d4a7014099e3410521358585a7a9d362cdcf7ffc1606a44bc97171a7c76", null ],
      [ "NRF_POWER_DCDC_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga0c5eb0d4a7014099e3410521358585a7a324274d6d85cf66f7adefb40962de881", null ]
    ] ],
    [ "NRF_POWER_MODES", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga66c4a4f3902bf8dfd3751c32e6589790", [
      [ "NRF_POWER_MODE_CONSTLAT", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga66c4a4f3902bf8dfd3751c32e6589790ac6041efce8dd9ac076796ac3b9540887", null ],
      [ "NRF_POWER_MODE_LOWPWR", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga66c4a4f3902bf8dfd3751c32e6589790ab029397a420ae259a1aba7e4bb132617", null ]
    ] ],
    [ "NRF_POWER_THRESHOLDS", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga3632f2fdc715316bd5c227fab6e17b90", [
      [ "NRF_POWER_THRESHOLD_V17", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90a7ae3151b2e9b357ada7c23ddbdf7dd5f", null ],
      [ "NRF_POWER_THRESHOLD_V18", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90ab89272385b2e3c80dd235ac3a295dc70", null ],
      [ "NRF_POWER_THRESHOLD_V19", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90ad6b2d575f9feeff23ecc148e48f66669", null ],
      [ "NRF_POWER_THRESHOLD_V20", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90a54c4452d04e26d49c8da17a6bbf4482b", null ],
      [ "NRF_POWER_THRESHOLD_V21", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90a41af1d0b4975d70c15f80600362a33aa", null ],
      [ "NRF_POWER_THRESHOLD_V22", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90a0f4453bdd577744f5c5da4f093813ea5", null ],
      [ "NRF_POWER_THRESHOLD_V23", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90adb687e57343f6a2fef22b5112c6db586", null ],
      [ "NRF_POWER_THRESHOLD_V24", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90aba272327313384b3d0c8541917804a8a", null ],
      [ "NRF_POWER_THRESHOLD_V25", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90ac709573ee044617b2eb9e3485d07a960", null ],
      [ "NRF_POWER_THRESHOLD_V26", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90a523fbf62eccfca2c13feb272c9ee8c68", null ],
      [ "NRF_POWER_THRESHOLD_V27", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90ae41806a99c3aeb93cf356ec49cfd67f6", null ],
      [ "NRF_POWER_THRESHOLD_V28", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga3632f2fdc715316bd5c227fab6e17b90af6a82b5582388bd0e93adc96b3f6e42e", null ]
    ] ],
    [ "NRF_POWER_THRESHOLDVDDHS", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga4efc066175646658d7487ce52067126e", [
      [ "NRF_POWER_THRESHOLDVDDH_V27", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126eabb691297f21074aaadd93a292a24b81d", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V28", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea96ed0337baa100a8129223355fea1c7b", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V29", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea36743dbc8bca1192348b3327038e37f5", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V30", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ead9ade4da08d8f56bdb68674e05e2e74d", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V31", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea23ff1448793e131a1c0a97ac806f3539", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V32", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea15c79a12d2cf565014d62ba649c6079e", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V33", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126eac0ee1bf1b28183c284dc30a1a29abfd3", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V34", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea0891326f34c4ac82e38f1f86b85f76d0", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V35", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea41a4c53b783f5d75be71feb30db0e984", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V36", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea2f44fe13a19a14aee19d288346a77a0b", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V37", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea3cddb6359dd9eab5824608cc30baec0e", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V38", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea6e3c2e759cc3406de38c7d421936950f", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V39", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea004b8b205fe51793790167e81762c29b", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V40", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126eae29880e262b042b53ece32130a3383bb", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V41", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126ea8097a42b924b38e0e3bca6beeca4987b", null ],
      [ "NRF_POWER_THRESHOLDVDDH_V42", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga4efc066175646658d7487ce52067126eacc57c6a670637fa3c662b5c984384040", null ]
    ] ],
    [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga2ecc6b5725b5075c2fc282d8f5b801b3", [
      [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE_START", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2ecc6b5725b5075c2fc282d8f5b801b3ac1d8eef43f89255a395eca327086b5f8", null ],
      [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE_TIMER0", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2ecc6b5725b5075c2fc282d8f5b801b3a2ce5ff596372a7c8df4bbdd4654be02c", null ],
      [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE_RADIO", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2ecc6b5725b5075c2fc282d8f5b801b3a7eedb8b9ee816cd21d1dc3ede51e07ae", null ],
      [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE_EXTEND_FAILED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2ecc6b5725b5075c2fc282d8f5b801b3a5903462126a67cecd2199fa18f983687", null ],
      [ "NRF_RADIO_CALLBACK_SIGNAL_TYPE_EXTEND_SUCCEEDED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2ecc6b5725b5075c2fc282d8f5b801b3ac3336fb50e650b9f0cc1a65a2b67a088", null ]
    ] ],
    [ "NRF_RADIO_HFCLK_CFG", "group___n_r_f___s_o_c___e_n_u_m_s.html#gac7d87a0d58b5d7b5a619d7587cd139a4", [
      [ "NRF_RADIO_HFCLK_CFG_XTAL_GUARANTEED", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggac7d87a0d58b5d7b5a619d7587cd139a4a9b147d9c4e5e70f3bccab896c51cdfd1", null ],
      [ "NRF_RADIO_HFCLK_CFG_NO_GUARANTEE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggac7d87a0d58b5d7b5a619d7587cd139a4a30a6241fcf8851b5a02e8499f4c384c5", null ]
    ] ],
    [ "NRF_RADIO_NOTIFICATION_DISTANCES", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga59b1a77ef6dcb1d75833e5c5f5251d58", [
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_NONE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58a8c14977e62861ab59d8d757c084cbac8", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_800US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58a905c39f757dcbf660a3f10fb65142a02", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_1740US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58abb2c01731c9afb329467cf8fd178670a", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_2680US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58a3b76f7a96735403a7441ace59339e4c3", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_3620US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58a7bf6dc55c693b3a8b16bdda473cb9c62", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_4560US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58aa045f282f1b641e538ee6338e6a84140", null ],
      [ "NRF_RADIO_NOTIFICATION_DISTANCE_5500US", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga59b1a77ef6dcb1d75833e5c5f5251d58aeab763769d9bc8ea3feeba991f8ac144", null ]
    ] ],
    [ "NRF_RADIO_NOTIFICATION_TYPES", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga20a90837e52ffbde1fb2ad81ef2db8c8", [
      [ "NRF_RADIO_NOTIFICATION_TYPE_NONE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga20a90837e52ffbde1fb2ad81ef2db8c8ac01e4b09fe151987651c1825c1259276", null ],
      [ "NRF_RADIO_NOTIFICATION_TYPE_INT_ON_ACTIVE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga20a90837e52ffbde1fb2ad81ef2db8c8a349afd1b7362b463677b2c523c4c509c", null ],
      [ "NRF_RADIO_NOTIFICATION_TYPE_INT_ON_INACTIVE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga20a90837e52ffbde1fb2ad81ef2db8c8a37db2f7d40ca9532eebff7f8c46b5a86", null ],
      [ "NRF_RADIO_NOTIFICATION_TYPE_INT_ON_BOTH", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga20a90837e52ffbde1fb2ad81ef2db8c8ac25c8a48a4f3e100693a4cfcc23d3c21", null ]
    ] ],
    [ "NRF_RADIO_PRIORITY", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga5026e138e16d9a9664b804608062e9a1", [
      [ "NRF_RADIO_PRIORITY_HIGH", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga5026e138e16d9a9664b804608062e9a1a8de2cbfc7f00a55bf6eadccebba12645", null ],
      [ "NRF_RADIO_PRIORITY_NORMAL", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga5026e138e16d9a9664b804608062e9a1ad4726f26655a89a5e1dfbbf08693868b", null ]
    ] ],
    [ "NRF_RADIO_REQUEST_TYPE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga1d048df14a3eeef46aabec45e9643858", [
      [ "NRF_RADIO_REQ_TYPE_EARLIEST", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga1d048df14a3eeef46aabec45e9643858a7951b0d09e47ff7d013fa506890ba42f", null ],
      [ "NRF_RADIO_REQ_TYPE_NORMAL", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga1d048df14a3eeef46aabec45e9643858a23233e911f0964d33440620f8965497a", null ]
    ] ],
    [ "NRF_RADIO_SIGNAL_CALLBACK_ACTION", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga21172c0e9efda8656ee3954b822a61f9", [
      [ "NRF_RADIO_SIGNAL_CALLBACK_ACTION_NONE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga21172c0e9efda8656ee3954b822a61f9a8c473df621861c55d1a02a6a2f4cf375", null ],
      [ "NRF_RADIO_SIGNAL_CALLBACK_ACTION_EXTEND", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga21172c0e9efda8656ee3954b822a61f9af8b1e7127849acd108c79c0a7ea8fefd", null ],
      [ "NRF_RADIO_SIGNAL_CALLBACK_ACTION_END", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga21172c0e9efda8656ee3954b822a61f9ac7779eb2ce1623d2b4e34c4332d571af", null ],
      [ "NRF_RADIO_SIGNAL_CALLBACK_ACTION_REQUEST_AND_END", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga21172c0e9efda8656ee3954b822a61f9a4f2f3f6df9a22f2f8d56e33326f1682e", null ]
    ] ],
    [ "NRF_SOC_EVTS", "group___n_r_f___s_o_c___e_n_u_m_s.html#ga2a3d2f55035ee3173aff0c05465fb648", [
      [ "NRF_EVT_HFCLKSTARTED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648ac2d9306c39625c31cc665a04132eadc2", null ],
      [ "NRF_EVT_POWER_FAILURE_WARNING", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a9308133662d215aa7984e174af8dd3f6", null ],
      [ "NRF_EVT_FLASH_OPERATION_SUCCESS", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a566ef9d8a97914dd30cd152bdfcd50e6", null ],
      [ "NRF_EVT_FLASH_OPERATION_ERROR", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a7c0083f76ab9ee6e75369776526d584d", null ],
      [ "NRF_EVT_RADIO_BLOCKED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a831ae39db7fcc9e63d66d87029a424d0", null ],
      [ "NRF_EVT_RADIO_CANCELED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a7d81d84476e04bef13e0046f0214ee59", null ],
      [ "NRF_EVT_RADIO_SIGNAL_CALLBACK_INVALID_RETURN", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648af3e61b7547e284ad3a895a92ac9364db", null ],
      [ "NRF_EVT_RADIO_SESSION_IDLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648af979d9bb2a05a4f0c45f40a5cac4b164", null ],
      [ "NRF_EVT_RADIO_SESSION_CLOSED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a9ac39a4402cf55b86a44fc3bedd829b1", null ],
      [ "NRF_EVT_POWER_USB_POWER_READY", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a39553d63a8165ea924aeb0104d6b898d", null ],
      [ "NRF_EVT_POWER_USB_DETECTED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648ad54e11c3068f9cfdefdec7650010b027", null ],
      [ "NRF_EVT_POWER_USB_REMOVED", "group___n_r_f___s_o_c___e_n_u_m_s.html#gga2a3d2f55035ee3173aff0c05465fb648a0cf4232992eeecdb10e7d0fe8ae91beb", null ]
    ] ],
    [ "NRF_SOC_SVCS", "group___n_r_f___s_o_c___e_n_u_m_s.html#gaf4f827d617d5692a5ef3c6e3febb85c5", [
      [ "SD_PPI_CHANNEL_ENABLE_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a3bd645e308ab3691f9be93f97a42bf08", null ],
      [ "SD_PPI_CHANNEL_ENABLE_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5afd2481fb1fff9895167645039352ef42", null ],
      [ "SD_PPI_CHANNEL_ENABLE_CLR", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a87d20efb0e4cee494f803f6f2b1fccb1", null ],
      [ "SD_PPI_CHANNEL_ASSIGN", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ad9caa10a41b2cc83404829c16e3c9f07", null ],
      [ "SD_PPI_GROUP_TASK_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a77546b9619500c8707fe290682e85177", null ],
      [ "SD_PPI_GROUP_TASK_DISABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a7971b3534eeab4ce93b2746eaded3728", null ],
      [ "SD_PPI_GROUP_ASSIGN", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a2069ae31d10d6ec41eaa1861219e7270", null ],
      [ "SD_PPI_GROUP_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5aac8a99bea84ad3fc5b26cdc6481d16f0", null ],
      [ "SD_FLASH_PAGE_ERASE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ad84de317e7657fba44852ae4d5de3215", null ],
      [ "SD_FLASH_WRITE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a75b925c5f48879e071e8345315c57266", null ],
      [ "SD_PROTECTED_REGISTER_WRITE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a229b201268ad4007d0e367b50fb6cc17", null ],
      [ "SD_MUTEX_NEW", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a5797b809112f42ff26c5206f493058a2", null ],
      [ "SD_MUTEX_ACQUIRE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ae82a35a6477e1b043f12defd955e76d3", null ],
      [ "SD_MUTEX_RELEASE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a1e3e2259c4f4f0036c8ab08b304d59b8", null ],
      [ "SD_RAND_APPLICATION_POOL_CAPACITY_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a4d2d946364e76f393c921b4b53f30429", null ],
      [ "SD_RAND_APPLICATION_BYTES_AVAILABLE_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ab9400988a42bda60fc3abaa367737090", null ],
      [ "SD_RAND_APPLICATION_VECTOR_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a6000ee9aeb2070b73349839d9e9d8322", null ],
      [ "SD_POWER_MODE_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a335267ac97764f15c1699b61a9161205", null ],
      [ "SD_POWER_SYSTEM_OFF", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a05547705fea54c38b8f7ff6837d03ccd", null ],
      [ "SD_POWER_RESET_REASON_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a0d4c96fcc7ea1a091e8ea5087367c0fe", null ],
      [ "SD_POWER_RESET_REASON_CLR", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ac3147086cb11f215da95cf750ae854ae", null ],
      [ "SD_POWER_POF_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ae73d45559a6466725ec93d7debee4ca9", null ],
      [ "SD_POWER_POF_THRESHOLD_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5acfb5a97c245b25723c01596b5ec649d0", null ],
      [ "SD_POWER_POF_THRESHOLDVDDH_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5af69d04088492df36550366869b90c17c", null ],
      [ "SD_POWER_RAM_POWER_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ade3281089ad5fa5a6db3afdff443e286", null ],
      [ "SD_POWER_RAM_POWER_CLR", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ade00e81df0f20c3812e4999b560a8adb", null ],
      [ "SD_POWER_RAM_POWER_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a33737766afa061e78b376fcb0bb99e54", null ],
      [ "SD_POWER_GPREGRET_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a38b34a7973dc8fd5bf4398245b323112", null ],
      [ "SD_POWER_GPREGRET_CLR", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a52ef1e13920f20d6595e2266581a93a3", null ],
      [ "SD_POWER_GPREGRET_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a6d6a77364a378dd71450af4ac6f9770d", null ],
      [ "SD_POWER_DCDC_MODE_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a29f2746a6fcfd1741833580ddaaa11ee", null ],
      [ "SD_POWER_DCDC0_MODE_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5afab1c104e5c8f310a0b5f3974bf6bfa7", null ],
      [ "SD_APP_EVT_WAIT", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a8718052990d62bb81ae4255107509dfa", null ],
      [ "SD_CLOCK_HFCLK_REQUEST", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5adb2f0b7ec848b1a1325c2c77fccf1683", null ],
      [ "SD_CLOCK_HFCLK_RELEASE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ad3376a21a77b22882db6cbee814c2c93", null ],
      [ "SD_CLOCK_HFCLK_IS_RUNNING", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a44f30956d60eb2b515f2da55587c6037", null ],
      [ "SD_RADIO_NOTIFICATION_CFG_SET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a41a3aa355dae41b0ff6bbbda225f8693", null ],
      [ "SD_ECB_BLOCK_ENCRYPT", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a9d1c36e61a5132faaf013f099c342429", null ],
      [ "SD_ECB_BLOCKS_ENCRYPT", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a2e14a5371bda98dc06804298ebd48b37", null ],
      [ "SD_RADIO_SESSION_OPEN", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a92b413b952029d40fed8267600f1dce0", null ],
      [ "SD_RADIO_SESSION_CLOSE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ae57d80ff19ffaa228b303156aa87a662", null ],
      [ "SD_RADIO_REQUEST", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5aa2277609978625e0933349ecf5ba74ca", null ],
      [ "SD_EVT_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5afaf4bf0e09d0bba2b0d038ae5a531be9", null ],
      [ "SD_TEMP_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a3c2e5d252f7162feff9da2b58e3bae3c", null ],
      [ "SD_POWER_USBPWRRDY_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a91f4c57a7b92d7e2cb1fe3abea16ad23", null ],
      [ "SD_POWER_USBDETECTED_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a28c0466e45ec1cd87408643a21def7fe", null ],
      [ "SD_POWER_USBREMOVED_ENABLE", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5a334c8daf17f40dece88c2b3af44b7a99", null ],
      [ "SD_POWER_USBREGSTATUS_GET", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ac8d248bd778ff2b60c6ef6aa368e0c83", null ],
      [ "SVC_SOC_LAST", "group___n_r_f___s_o_c___e_n_u_m_s.html#ggaf4f827d617d5692a5ef3c6e3febb85c5ae1d073a1092f208d6d3cf38819a5e327", null ]
    ] ]
];