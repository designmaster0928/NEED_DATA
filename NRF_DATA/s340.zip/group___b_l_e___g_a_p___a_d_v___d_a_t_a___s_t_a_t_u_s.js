var group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s =
[
    [ "BLE_GAP_ADV_DATA_STATUS_COMPLETE", "group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s.html#gad099a8d2746dbc7070dc4bdf947d50d5", null ],
    [ "BLE_GAP_ADV_DATA_STATUS_INCOMPLETE_MISSED", "group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s.html#gab846e1c23cd0d79fd65102e49d48e2f2", null ],
    [ "BLE_GAP_ADV_DATA_STATUS_INCOMPLETE_MORE_DATA", "group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s.html#ga181c51cd6fedafe2430e400744be8a0c", null ],
    [ "BLE_GAP_ADV_DATA_STATUS_INCOMPLETE_TRUNCATED", "group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s.html#gacf06b3028ab83f6009ed9257087fbed3", null ]
];