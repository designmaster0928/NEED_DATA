var group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s =
[
    [ "BLE_GATTC_EVTS", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gafd9b8b42eeb832d688e33f4561f97efc", [
      [ "BLE_GATTC_EVT_PRIM_SRVC_DISC_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efcaa4ebe118aada0a7d38163ea11492f020", null ],
      [ "BLE_GATTC_EVT_REL_DISC_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efcac52e2f11dc65da2efe53f7041d0ead6b", null ],
      [ "BLE_GATTC_EVT_CHAR_DISC_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efcac385b5d8f35de9cfd0df5b5aea9cb310", null ],
      [ "BLE_GATTC_EVT_DESC_DISC_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca990d593e0c54f813ee6d6bb7fad619a2", null ],
      [ "BLE_GATTC_EVT_ATTR_INFO_DISC_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca2ad65b05c79182d62f953294cde143dc", null ],
      [ "BLE_GATTC_EVT_CHAR_VAL_BY_UUID_READ_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca9741363d5e934220a35f1c01f62a194c", null ],
      [ "BLE_GATTC_EVT_READ_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca2355be2e3b5c9bd1c235f7abbc56ef6d", null ],
      [ "BLE_GATTC_EVT_CHAR_VALS_READ_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efcaab8322d0d775f2726cfc0215ef63f298", null ],
      [ "BLE_GATTC_EVT_WRITE_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca6a70fe83b91997c8d3cd47b6cd98a91a", null ],
      [ "BLE_GATTC_EVT_HVX", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca0f71b4e016b2049dfbd74fa2e46b9cd3", null ],
      [ "BLE_GATTC_EVT_EXCHANGE_MTU_RSP", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca8b507c6155917928a7253faa0ecbf963", null ],
      [ "BLE_GATTC_EVT_TIMEOUT", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efcacdb80367c0f97c95db04e19665ebf2fc", null ],
      [ "BLE_GATTC_EVT_WRITE_CMD_TX_COMPLETE", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ggafd9b8b42eeb832d688e33f4561f97efca69bce270587ac00d7a1c3bd976cfd902", null ]
    ] ],
    [ "BLE_GATTC_SVCS", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#ga1861d83550e6998efd13d44b09ec1ba9", [
      [ "SD_BLE_GATTC_PRIMARY_SERVICES_DISCOVER", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9a6362074e02b0a5e960257ceaa0886f51", null ],
      [ "SD_BLE_GATTC_RELATIONSHIPS_DISCOVER", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9a84e92548312cd9db93e3b6943ce83e65", null ],
      [ "SD_BLE_GATTC_CHARACTERISTICS_DISCOVER", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9aa07c8e5ddc5a267dd9561787695d48ee", null ],
      [ "SD_BLE_GATTC_DESCRIPTORS_DISCOVER", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9acbf16ad32f9408da33a6fdb9c969f455", null ],
      [ "SD_BLE_GATTC_ATTR_INFO_DISCOVER", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9aabafa4b240900b6d74550ca9fb98cd0a", null ],
      [ "SD_BLE_GATTC_CHAR_VALUE_BY_UUID_READ", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9aba39e3ced819d191f10a368eb4d28595", null ],
      [ "SD_BLE_GATTC_READ", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9a8cd119e7dac7c5a94a6b9b209cd072f9", null ],
      [ "SD_BLE_GATTC_CHAR_VALUES_READ", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9aefadfe6aebd0e0f3111d9514e3387c90", null ],
      [ "SD_BLE_GATTC_WRITE", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9ae34d35052cd94de5fd4e6c5263d898ab", null ],
      [ "SD_BLE_GATTC_HV_CONFIRM", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9a3bb17168d2477e2fce1b66481ebcfb02", null ],
      [ "SD_BLE_GATTC_EXCHANGE_MTU_REQUEST", "group___b_l_e___g_a_t_t_c___e_n_u_m_e_r_a_t_i_o_n_s.html#gga1861d83550e6998efd13d44b09ec1ba9a569589de40bfd546b03cb6210dcd8c3a", null ]
    ] ]
];