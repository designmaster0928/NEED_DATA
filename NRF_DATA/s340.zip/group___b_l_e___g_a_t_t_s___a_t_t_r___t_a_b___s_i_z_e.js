var group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e =
[
    [ "BLE_GATTS_ATTR_TAB_SIZE_DEFAULT", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e.html#ga3b329810a73308879c5c755ead002655", null ],
    [ "BLE_GATTS_ATTR_TAB_SIZE_MIN", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e.html#gab371a7dbc87e08383d3a85daa41f3bfc", null ]
];