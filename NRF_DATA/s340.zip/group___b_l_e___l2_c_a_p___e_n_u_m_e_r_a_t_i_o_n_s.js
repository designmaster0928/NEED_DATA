var group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s =
[
    [ "BLE_L2CAP_EVTS", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ga200c8684032d8e5fe10d295b2f3a1555", [
      [ "BLE_L2CAP_EVT_CH_SETUP_REQUEST", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555ae13b48b3212c3e05df684f51257df2f0", null ],
      [ "BLE_L2CAP_EVT_CH_SETUP_REFUSED", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555a8f364b20fdca5239e35fc666a681aacf", null ],
      [ "BLE_L2CAP_EVT_CH_SETUP", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555a56f73fdbd26acabcd77f6dea45585b78", null ],
      [ "BLE_L2CAP_EVT_CH_RELEASED", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555a73b33f506c7aec79a45ca07c1447d135", null ],
      [ "BLE_L2CAP_EVT_CH_SDU_BUF_RELEASED", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555aa883f335f22df2b322374b7364089f18", null ],
      [ "BLE_L2CAP_EVT_CH_CREDIT", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555a6791beb4bdd853e07abcd7df04d83320", null ],
      [ "BLE_L2CAP_EVT_CH_RX", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555a0330b9c28f1abb1451fa8753d6c44596", null ],
      [ "BLE_L2CAP_EVT_CH_TX", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga200c8684032d8e5fe10d295b2f3a1555afa2b40e6fe7691496fded82199a5e7a1", null ]
    ] ],
    [ "BLE_L2CAP_SVCS", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ga08e7b23691ec76610bbd89735c642322", [
      [ "SD_BLE_L2CAP_CH_SETUP", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga08e7b23691ec76610bbd89735c642322a100e1ed0409b3ab9569eee9e07752d04", null ],
      [ "SD_BLE_L2CAP_CH_RELEASE", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga08e7b23691ec76610bbd89735c642322a91c851b06289554062d71add1b1edbee", null ],
      [ "SD_BLE_L2CAP_CH_RX", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga08e7b23691ec76610bbd89735c642322aa78b2d227ffa65b8c3a6058083acfbd4", null ],
      [ "SD_BLE_L2CAP_CH_TX", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga08e7b23691ec76610bbd89735c642322a56cc35179fb851b9abac147c20ffb488", null ],
      [ "SD_BLE_L2CAP_CH_FLOW_CONTROL", "group___b_l_e___l2_c_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga08e7b23691ec76610bbd89735c642322a3c0dbe2f60c493793268a1fc29e3f466", null ]
    ] ]
];