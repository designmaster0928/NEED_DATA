var group___b_l_e___g_a_t_t_c___d_e_f_i_n_e_s =
[
    [ "Attribute Information Formats", "group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t.html", "group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t" ],
    [ "GATT Client defaults", "group___b_l_e___g_a_t_t_c___d_e_f_a_u_l_t_s.html", "group___b_l_e___g_a_t_t_c___d_e_f_a_u_l_t_s" ],
    [ "SVC return values specific to GATTC", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_c.html", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_c" ]
];