var group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w =
[
    [ "BLE_GAP_SCAN_WINDOW_MAX", "group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w.html#gaecdcf0491fde1b2c2c4082f7a2e81093", null ],
    [ "BLE_GAP_SCAN_WINDOW_MIN", "group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w.html#ga4015a62a4ffba084dfdf58c32989c7a8", null ]
];