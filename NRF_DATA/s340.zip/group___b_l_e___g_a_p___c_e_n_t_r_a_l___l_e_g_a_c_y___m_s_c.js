var group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_g_a_c_y___m_s_c =
[
    [ "Bonding: Just Works", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___b_o_n_d_i_n_g___j_w___m_s_c.html", null ],
    [ "Bonding: Passkey Entry, Central displays", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___b_o_n_d_i_n_g___p_k___p_e_r_i_p_h___m_s_c.html", null ],
    [ "Bonding: Passkey Entry, User Inputs on Central or OOB", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___b_o_n_d_i_n_g___p_k___p_e_r_i_p_h___o_o_b___m_s_c.html", null ],
    [ "Pairing: Just Works", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___p_a_i_r_i_n_g___j_w___m_s_c.html", null ]
];