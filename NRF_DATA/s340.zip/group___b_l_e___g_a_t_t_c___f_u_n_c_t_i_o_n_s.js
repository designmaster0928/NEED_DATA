var group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s =
[
    [ "sd_ble_gattc_attr_info_discover", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga8b7ff74ff996da8340f69c208bfd0ec4", null ],
    [ "sd_ble_gattc_char_value_by_uuid_read", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga1e5d6f7c678b7db3205fa6b5c419f665", null ],
    [ "sd_ble_gattc_char_values_read", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#gac13467be9f6901defc8fc04258c88d36", null ],
    [ "sd_ble_gattc_characteristics_discover", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#gaf2bbf5162938f59bae419282d54f76fa", null ],
    [ "sd_ble_gattc_descriptors_discover", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#gaf896032d8502d0e535c2889955e3ad64", null ],
    [ "sd_ble_gattc_evt_char_val_by_uuid_read_rsp_iter", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga48fdf1714ac5f8787d2de62f1d9933eb", null ],
    [ "sd_ble_gattc_exchange_mtu_request", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga269894b0415de8c4ae76343b74f6e655", null ],
    [ "sd_ble_gattc_hv_confirm", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga173e2d16c9bbd24dcf2c724ded6708a5", null ],
    [ "sd_ble_gattc_primary_services_discover", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#gaa778ccc1990e05fffa4aaf304c95e614", null ],
    [ "sd_ble_gattc_read", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga813daa5810a1d2ed31d2d6fe49d3ef11", null ],
    [ "sd_ble_gattc_relationships_discover", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga2c03757248d02fc59591354688e402bc", null ],
    [ "sd_ble_gattc_write", "group___b_l_e___g_a_t_t_c___f_u_n_c_t_i_o_n_s.html#ga90298b8dcd8bbe7bbe69d362d1133378", null ]
];