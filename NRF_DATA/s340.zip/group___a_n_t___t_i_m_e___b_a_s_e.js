var group___a_n_t___t_i_m_e___b_a_s_e =
[
    [ "ANT_TIME_BASE_ALT1", "group___a_n_t___t_i_m_e___b_a_s_e.html#gacee278bab6b6e174c8857abb174d40fd", null ],
    [ "ANT_TIME_BASE_ALT2", "group___a_n_t___t_i_m_e___b_a_s_e.html#ga37820856526552ebd04d25cb75be2d8f", null ],
    [ "ANT_TIME_BASE_ANT", "group___a_n_t___t_i_m_e___b_a_s_e.html#ga82405f52fec009d89f86459674ce6276", null ]
];