var group___a_d_v___s_c_h_e_d___c_f_g =
[
    [ "ADV_SCHED_CFG_DEFAULT", "group___a_d_v___s_c_h_e_d___c_f_g.html#ga0c20e996334d137efdca497b2e9fc8e0", null ],
    [ "ADV_SCHED_CFG_IMPROVED", "group___a_d_v___s_c_h_e_d___c_f_g.html#ga5a4d7bacb6645b6328f3706554d79fed", null ]
];