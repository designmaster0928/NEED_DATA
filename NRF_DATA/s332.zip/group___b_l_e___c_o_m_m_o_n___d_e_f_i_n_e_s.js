var group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s =
[
    [ "Advertiser Role Scheduling Configuration", "group___a_d_v___s_c_h_e_d___c_f_g.html", "group___a_d_v___s_c_h_e_d___c_f_g" ],
    [ "Configuration defaults.", "group___b_l_e___c_o_m_m_o_n___c_f_g___d_e_f_a_u_l_t_s.html", "group___b_l_e___c_o_m_m_o_n___c_f_g___d_e_f_a_u_l_t_s" ],
    [ "User Memory Types", "group___b_l_e___u_s_e_r___m_e_m___t_y_p_e_s.html", "group___b_l_e___u_s_e_r___m_e_m___t_y_p_e_s" ],
    [ "Vendor Specific base UUID counts", "group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s.html", "group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s" ],
    [ "BLE_EVT_LEN_MAX", "group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s.html#ga7c80f6dd3ab61e283e08365028a41bfc", null ],
    [ "BLE_EVT_PTR_ALIGNMENT", "group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s.html#ga73b176876397d4e8a8e7cc53cbb9de45", null ],
    [ "BLE_MAX", "group___b_l_e___c_o_m_m_o_n___d_e_f_i_n_e_s.html#ga7359ba01d2eab8394dd9f6f9ba02cd80", null ]
];