var group___b_l_e___g_a_p___a_d_v___m_s_c =
[
    [ "Advertising using extended advertising PDUs", "group___b_l_e___g_a_p___a_d_v___m_s_c___a_e.html", null ],
    [ "Advertising using legacy advertising PDUs", "group___b_l_e___g_a_p___a_d_v___m_s_c___l_e_g_a_c_y.html", null ]
];