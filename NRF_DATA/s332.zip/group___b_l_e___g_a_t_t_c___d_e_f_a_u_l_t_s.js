var group___b_l_e___g_a_t_t_c___d_e_f_a_u_l_t_s =
[
    [ "BLE_GATTC_WRITE_CMD_TX_QUEUE_SIZE_DEFAULT", "group___b_l_e___g_a_t_t_c___d_e_f_a_u_l_t_s.html#ga69f687406bf0920a6dea307b705640db", null ]
];