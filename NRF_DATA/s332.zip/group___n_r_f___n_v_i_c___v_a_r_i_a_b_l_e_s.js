var group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s =
[
    [ "nrf_nvic_state_t", "structnrf__nvic__state__t.html", [
      [ "__cr_flag", "structnrf__nvic__state__t.html#ab98e73a38a7559b6b1b6ed52604603d4", null ],
      [ "__irq_masks", "structnrf__nvic__state__t.html#a83f0c50a94c6687bea375ffb98d76f89", null ]
    ] ],
    [ "nrf_nvic_state", "group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html#gae5ad2c570afdfbdd77336aec4e6097a7", null ]
];