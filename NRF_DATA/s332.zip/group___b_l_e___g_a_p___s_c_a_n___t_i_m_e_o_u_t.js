var group___b_l_e___g_a_p___s_c_a_n___t_i_m_e_o_u_t =
[
    [ "BLE_GAP_SCAN_TIMEOUT_MIN", "group___b_l_e___g_a_p___s_c_a_n___t_i_m_e_o_u_t.html#ga4baffc2a25f63a57ddf48babb53f2b5a", null ],
    [ "BLE_GAP_SCAN_TIMEOUT_UNLIMITED", "group___b_l_e___g_a_p___s_c_a_n___t_i_m_e_o_u_t.html#ga307b160a7dfc0dfa4b5522c77cea1592", null ]
];