var group___b_l_e___g_a_t_t_s___v_l_o_c_s =
[
    [ "BLE_GATTS_VLOC_INVALID", "group___b_l_e___g_a_t_t_s___v_l_o_c_s.html#ga0b0c153e71bddb01a4ba803a9110a6e4", null ],
    [ "BLE_GATTS_VLOC_STACK", "group___b_l_e___g_a_t_t_s___v_l_o_c_s.html#gaf51ee5f68c7eea401ee79cd250c1fb16", null ],
    [ "BLE_GATTS_VLOC_USER", "group___b_l_e___g_a_t_t_s___v_l_o_c_s.html#gaddb51f959e18123c5e215e22af0c31a9", null ]
];