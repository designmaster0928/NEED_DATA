var group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s =
[
    [ "BLE_GATTS_CFGS", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ga0507384d0882b274558664b3b7c95292", [
      [ "BLE_GATTS_CFG_SERVICE_CHANGED", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#gga0507384d0882b274558664b3b7c95292aea98f51bd63f7c5c9eb3fb9b065efb64", null ],
      [ "BLE_GATTS_CFG_ATTR_TAB_SIZE", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#gga0507384d0882b274558664b3b7c95292a39d5d456fbc60ff5f9904d8eb0e24a6f", null ]
    ] ],
    [ "BLE_GATTS_EVTS", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#gae537647902af1b05c1e32f12d6b401c7", [
      [ "BLE_GATTS_EVT_WRITE", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7aa68b7764f5264ff092d2ad17851355ed", null ],
      [ "BLE_GATTS_EVT_RW_AUTHORIZE_REQUEST", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7a333a0e896f77ea1c7f9a0e1e11f8240d", null ],
      [ "BLE_GATTS_EVT_SYS_ATTR_MISSING", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7ae3776204f11a583e105aed0e477601da", null ],
      [ "BLE_GATTS_EVT_HVC", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7af6a065c5c7e0682989ddd6cc557e0ffa", null ],
      [ "BLE_GATTS_EVT_SC_CONFIRM", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7a052eae0b3eb431b7e984107b2308ad50", null ],
      [ "BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7a78fe71c6fa6549a540d1105bf9023d8f", null ],
      [ "BLE_GATTS_EVT_TIMEOUT", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7a6a06b6ca6c9e46ed778b79522867301c", null ],
      [ "BLE_GATTS_EVT_HVN_TX_COMPLETE", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae537647902af1b05c1e32f12d6b401c7afab96bfa9918017082235f7664919f9d", null ]
    ] ],
    [ "BLE_GATTS_SVCS", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#gac817a87689e9c2c82f813a5221d0bd27", [
      [ "SD_BLE_GATTS_SERVICE_ADD", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a8e890298dc03f9799a287dce916db7d5", null ],
      [ "SD_BLE_GATTS_INCLUDE_ADD", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a577ae7b415f484f5e3ce44c20f9603ae", null ],
      [ "SD_BLE_GATTS_CHARACTERISTIC_ADD", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a433be374af78720d42a377e4cad2f05a", null ],
      [ "SD_BLE_GATTS_DESCRIPTOR_ADD", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27afb8c998b39146476bffa546519d7d710", null ],
      [ "SD_BLE_GATTS_VALUE_SET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a7c07fba90eb73b66af555a0dd52a23e4", null ],
      [ "SD_BLE_GATTS_VALUE_GET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a42f0e408b0d60e992ded1508734a61b2", null ],
      [ "SD_BLE_GATTS_HVX", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a6501f213d3f433b0588413fa536d347c", null ],
      [ "SD_BLE_GATTS_SERVICE_CHANGED", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a4a3dce1ea0ef369d33f44fd380396f47", null ],
      [ "SD_BLE_GATTS_RW_AUTHORIZE_REPLY", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a52831e0a13dbfe549c7c2cfd57886ed8", null ],
      [ "SD_BLE_GATTS_SYS_ATTR_SET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a9a2a1240d6bb8dfd1c77e28ae88e3e3b", null ],
      [ "SD_BLE_GATTS_SYS_ATTR_GET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27aa3147b54b63b44fb040177ee5b175b61", null ],
      [ "SD_BLE_GATTS_INITIAL_USER_HANDLE_GET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a0a139e839b4fc4b21bbc0a8fd5c1bc52", null ],
      [ "SD_BLE_GATTS_ATTR_GET", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27a12d3b271fec366c8276d0ae72df42c66", null ],
      [ "SD_BLE_GATTS_EXCHANGE_MTU_REPLY", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html#ggac817a87689e9c2c82f813a5221d0bd27ac1d76a62a3b749f74537f95ecc8b9491", null ]
    ] ]
];