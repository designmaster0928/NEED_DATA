var group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e =
[
    [ "BLE_GAP_SCAN_BUFFER_EXTENDED_MAX", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#ga4cc01941b8acc35d2fd01e841c01f33d", null ],
    [ "BLE_GAP_SCAN_BUFFER_EXTENDED_MAX_SUPPORTED", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#gad3012dfb9e989222b1a1a21e6b2150aa", null ],
    [ "BLE_GAP_SCAN_BUFFER_EXTENDED_MIN", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#ga7239e0b4ab76b720e7431b3de0e2b3e1", null ],
    [ "BLE_GAP_SCAN_BUFFER_MAX", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#gab273184f504c5637cb193067e75faf67", null ],
    [ "BLE_GAP_SCAN_BUFFER_MIN", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#gacc6fd0bc6de5ff8924a5d50526253676", null ]
];