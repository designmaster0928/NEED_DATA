var group___b_l_e___g_a_t_t___s_t_r_u_c_t_u_r_e_s =
[
    [ "ble_gatt_conn_cfg_t", "structble__gatt__conn__cfg__t.html", [
      [ "att_mtu", "structble__gatt__conn__cfg__t.html#a3fac0ed97a3a75cf21e9ed8432b95193", null ]
    ] ],
    [ "ble_gatt_char_props_t", "structble__gatt__char__props__t.html", [
      [ "auth_signed_wr", "structble__gatt__char__props__t.html#ad021e4c1c66a2595cb430d1e0598bc0d", null ],
      [ "broadcast", "structble__gatt__char__props__t.html#a66788f87aed20bf98b81af57051e9795", null ],
      [ "indicate", "structble__gatt__char__props__t.html#a256d8d59b59f7f1a079e962196e026dd", null ],
      [ "notify", "structble__gatt__char__props__t.html#a9dd91c1e55995665ef09ec4c5bd5eaf7", null ],
      [ "read", "structble__gatt__char__props__t.html#a1da688e4cfacf724ee7636dbf534716f", null ],
      [ "write", "structble__gatt__char__props__t.html#ae0ef9c3f220f06e735b534d232cb9108", null ],
      [ "write_wo_resp", "structble__gatt__char__props__t.html#a61fdb334c11f2a62accb48f297fb46ef", null ]
    ] ],
    [ "ble_gatt_char_ext_props_t", "structble__gatt__char__ext__props__t.html", [
      [ "reliable_wr", "structble__gatt__char__ext__props__t.html#a8b4bb4c79bed8c8a6d75ca0dd08b7591", null ],
      [ "wr_aux", "structble__gatt__char__ext__props__t.html#a0f36b2c312c08c22853231a3bc8b950c", null ]
    ] ]
];