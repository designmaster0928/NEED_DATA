var group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s =
[
    [ "BLE_GATTS_ATTR_TYPE_CHAR_DECL", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#ga102e704417b457854a05daa5fa06d7d6", null ],
    [ "BLE_GATTS_ATTR_TYPE_CHAR_VAL", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#gac7e5c6d395c2a57918233dd8c7a9a699", null ],
    [ "BLE_GATTS_ATTR_TYPE_DESC", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#gac5f3e3213a49c7fe404a1c3f934de50c", null ],
    [ "BLE_GATTS_ATTR_TYPE_INC_DECL", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#gadf7b95716018edd34e87df7e4163bc74", null ],
    [ "BLE_GATTS_ATTR_TYPE_INVALID", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#ga24097ed5a56be45fc4d051584546e458", null ],
    [ "BLE_GATTS_ATTR_TYPE_OTHER", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#gadbf23b44b2e2731d944ba3682427c316", null ],
    [ "BLE_GATTS_ATTR_TYPE_PRIM_SRVC_DECL", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#ga0bb8323562a8a6be5ad1b2287b20373c", null ],
    [ "BLE_GATTS_ATTR_TYPE_SEC_SRVC_DECL", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html#gafa5f417382bd4c490203767739062c74", null ]
];