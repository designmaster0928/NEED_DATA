var group___b_l_e___g_a_t_t_s___d_e_f_i_n_e_s =
[
    [ "Attribute Table size", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e.html", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e" ],
    [ "GATT Server Attribute Types", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s.html", "group___b_l_e___g_a_t_t_s___a_t_t_r___t_y_p_e_s" ],
    [ "GATT Server Authorization Types", "group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s.html", "group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s" ],
    [ "GATT Server Operations", "group___b_l_e___g_a_t_t_s___o_p_s.html", "group___b_l_e___g_a_t_t_s___o_p_s" ],
    [ "GATT Server Service Types", "group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s.html", "group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s" ],
    [ "GATT Server defaults", "group___b_l_e___g_a_t_t_s___d_e_f_a_u_l_t_s.html", "group___b_l_e___g_a_t_t_s___d_e_f_a_u_l_t_s" ],
    [ "GATT Value Locations", "group___b_l_e___g_a_t_t_s___v_l_o_c_s.html", "group___b_l_e___g_a_t_t_s___v_l_o_c_s" ],
    [ "Maximum attribute lengths", "group___b_l_e___g_a_t_t_s___a_t_t_r___l_e_n_s___m_a_x.html", "group___b_l_e___g_a_t_t_s___a_t_t_r___l_e_n_s___m_a_x" ],
    [ "SVC return values specific to GATTS", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_s.html", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_s" ],
    [ "Service Changed Inclusion Values", "group___b_l_e___g_a_t_t_s___s_e_r_v_i_c_e___c_h_a_n_g_e_d.html", "group___b_l_e___g_a_t_t_s___s_e_r_v_i_c_e___c_h_a_n_g_e_d" ],
    [ "System Attribute Flags", "group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r___f_l_a_g_s.html", "group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r___f_l_a_g_s" ]
];