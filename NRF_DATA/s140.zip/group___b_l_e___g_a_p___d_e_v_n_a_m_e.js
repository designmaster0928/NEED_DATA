var group___b_l_e___g_a_p___d_e_v_n_a_m_e =
[
    [ "BLE_GAP_DEVNAME_DEFAULT", "group___b_l_e___g_a_p___d_e_v_n_a_m_e.html#gad628e0c2245a27349fd218cb5f4ad6a7", null ],
    [ "BLE_GAP_DEVNAME_DEFAULT_LEN", "group___b_l_e___g_a_p___d_e_v_n_a_m_e.html#ga44d90ef5a469087fd881f4e838cb4f5a", null ],
    [ "BLE_GAP_DEVNAME_MAX_LEN", "group___b_l_e___g_a_p___d_e_v_n_a_m_e.html#gac2eb594dd57920a845941ba29990022d", null ]
];