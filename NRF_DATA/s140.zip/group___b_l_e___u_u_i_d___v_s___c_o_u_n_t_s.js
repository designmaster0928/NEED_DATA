var group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s =
[
    [ "BLE_UUID_VS_COUNT_DEFAULT", "group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s.html#ga7681a25f4adabd8e368ba8671a270928", null ],
    [ "BLE_UUID_VS_COUNT_MAX", "group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s.html#ga0931f430ff6f39cd4bac86935569b933", null ]
];