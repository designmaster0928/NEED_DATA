var group___b_l_e___g_a_t_t_s___a_t_t_r___l_e_n_s___m_a_x =
[
    [ "BLE_GATTS_FIX_ATTR_LEN_MAX", "group___b_l_e___g_a_t_t_s___a_t_t_r___l_e_n_s___m_a_x.html#ga4cf6efe8134f1f771c088ff7d4c1d79a", null ],
    [ "BLE_GATTS_VAR_ATTR_LEN_MAX", "group___b_l_e___g_a_t_t_s___a_t_t_r___l_e_n_s___m_a_x.html#gac2a12a8c74733f8a666083550b77dc09", null ]
];