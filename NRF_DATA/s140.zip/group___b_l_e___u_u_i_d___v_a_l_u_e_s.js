var group___b_l_e___u_u_i_d___v_a_l_u_e_s =
[
    [ "BLE_UUID_CHARACTERISTIC", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gac1247c863c8c293a1ab2d8d53fc86b77", null ],
    [ "BLE_UUID_DESCRIPTOR_CHAR_AGGREGATE_FORMAT", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga082c169a7d21fa9c21b9bc7897a47dc5", null ],
    [ "BLE_UUID_DESCRIPTOR_CHAR_EXT_PROP", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gad912e4f32457de19e8bcfbd95b80df44", null ],
    [ "BLE_UUID_DESCRIPTOR_CHAR_PRESENTATION_FORMAT", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gaaab8d24f4f044cdbc956fbbf16aa2b2d", null ],
    [ "BLE_UUID_DESCRIPTOR_CHAR_USER_DESC", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gae4485d6b145f9b635842a1d27ee3603c", null ],
    [ "BLE_UUID_DESCRIPTOR_CLIENT_CHAR_CONFIG", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gae3c54dd809c9dec53a3c4995b0f408f1", null ],
    [ "BLE_UUID_DESCRIPTOR_SERVER_CHAR_CONFIG", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga03ceb71bc3996111c5ded9ba1f5b5ea5", null ],
    [ "BLE_UUID_GAP", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga03f02e3183f99757dc2fac8192bcbf86", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_APPEARANCE", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gafc8e59c9ba74e25c058a37dfa33b8aa4", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_CAR", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gadedfd3c253c1ae33bacb852be0cf62da", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_DEVICE_NAME", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gaefc74572ced8c611602f5bb25804281e", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_PPCP", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga7d00000113781b827c4c645b99e06ed2", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_RECONN_ADDR", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga9017ed725d44887f8d69e004187bf92f", null ],
    [ "BLE_UUID_GAP_CHARACTERISTIC_RPA_ONLY", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gad5a547895890f301ca76897df799c91a", null ],
    [ "BLE_UUID_GATT", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga418b2799bf0d0d7e15496c9ece20c800", null ],
    [ "BLE_UUID_GATT_CHARACTERISTIC_SERVICE_CHANGED", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gab2c3d0d5d8e4d88e14e544c4518a4e5b", null ],
    [ "BLE_UUID_SERVICE_INCLUDE", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gab90b6506450b9102b00f3cd675680f44", null ],
    [ "BLE_UUID_SERVICE_PRIMARY", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga1c79cdc83128a672be4d07921d2e45c2", null ],
    [ "BLE_UUID_SERVICE_SECONDARY", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#ga2c15c436aa715834bb47cb695e952cae", null ],
    [ "BLE_UUID_UNKNOWN", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html#gae98868aa7a26c8f1f813e329d3be7925", null ]
];