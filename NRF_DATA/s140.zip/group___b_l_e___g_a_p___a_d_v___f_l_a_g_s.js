var group___b_l_e___g_a_p___a_d_v___f_l_a_g_s =
[
    [ "BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#gacb3630594402e27c96515eb80080f2a3", null ],
    [ "BLE_GAP_ADV_FLAG_LE_BR_EDR_CONTROLLER", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#ga589a2a83eb353ad35fc9660c442514ce", null ],
    [ "BLE_GAP_ADV_FLAG_LE_BR_EDR_HOST", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#gaeb2468cf5bea6160d3b7fff9a1059116", null ],
    [ "BLE_GAP_ADV_FLAG_LE_GENERAL_DISC_MODE", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#ga3b7d4251306cd6644d9125da1994a931", null ],
    [ "BLE_GAP_ADV_FLAG_LE_LIMITED_DISC_MODE", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#ga7ed61557e00488daa5daf0b3d9f3d0fd", null ],
    [ "BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#gaa57375a29c3f6acc5a22565528118cc6", null ],
    [ "BLE_GAP_ADV_FLAGS_LE_ONLY_LIMITED_DISC_MODE", "group___b_l_e___g_a_p___a_d_v___f_l_a_g_s.html#gad19a5111127656b299dbdbe5d5e8d4e0", null ]
];