var group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s =
[
    [ "BLE_GATTS_AUTHORIZE_TYPE_INVALID", "group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s.html#ga156b817b68ec907affac6d5aa16f29aa", null ],
    [ "BLE_GATTS_AUTHORIZE_TYPE_READ", "group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s.html#gacd69638f1f1f3eddbedc59c530b946d8", null ],
    [ "BLE_GATTS_AUTHORIZE_TYPE_WRITE", "group___b_l_e___g_a_t_t_s___a_u_t_h_o_r_i_z_e___t_y_p_e_s.html#ga1b8036fd4c246ad2bb5696632761ab47", null ]
];