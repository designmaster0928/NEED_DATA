var group___b_l_e___g_a_p___a_d_v___t_y_p_e_s =
[
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_NONSCANNABLE_DIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga8042312ca8468c0763ede30c1cf921c4", null ],
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_NONSCANNABLE_DIRECTED_HIGH_DUTY_CYCLE", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gafae9f67ea85137f6a630a650a6af7476", null ],
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_SCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gae453a22d3a46ef932ff2808afb84c958", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_CONNECTABLE_NONSCANNABLE_DIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gab9419d2b52cebdaf69b0fbbcffd6dee9", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_CONNECTABLE_NONSCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga2c9ea9b4d19f028db32f044d74463b2d", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_NONCONNECTABLE_NONSCANNABLE_DIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga8e8683ef49cb1fd34be77d1a70bcc601", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_NONCONNECTABLE_NONSCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga1d336cbb6248fdb62d2154a0a991658c", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_NONCONNECTABLE_SCANNABLE_DIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gac9c65e20e9572a133e60b0995a504606", null ],
    [ "BLE_GAP_ADV_TYPE_EXTENDED_NONCONNECTABLE_SCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gad755afc9bd6139f84173525d6cd92ad6", null ],
    [ "BLE_GAP_ADV_TYPE_NONCONNECTABLE_NONSCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gae5a70eec1facf6ff0baae3be3401204d", null ],
    [ "BLE_GAP_ADV_TYPE_NONCONNECTABLE_SCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga0cf4be8eca3c4bcaf60a244a3b921d54", null ]
];