var group___b_l_e___t_y_p_e_s___s_t_r_u_c_t_u_r_e_s =
[
    [ "ble_uuid128_t", "structble__uuid128__t.html", [
      [ "uuid128", "structble__uuid128__t.html#a6996185349442be9de548fd646efa972", null ]
    ] ],
    [ "ble_uuid_t", "structble__uuid__t.html", [
      [ "type", "structble__uuid__t.html#ae233c47cdd5f63de456f413a158bb16f", null ],
      [ "uuid", "structble__uuid__t.html#ac9ccd46e82b1b51d561f17d49282348c", null ]
    ] ],
    [ "ble_data_t", "structble__data__t.html", [
      [ "len", "structble__data__t.html#a629da51916cf493abf5e2200dd438961", null ],
      [ "p_data", "structble__data__t.html#a74811667e4fa8116847fbf4fd085a257", null ]
    ] ]
];