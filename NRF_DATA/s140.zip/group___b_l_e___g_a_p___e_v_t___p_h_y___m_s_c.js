var group___b_l_e___g_a_p___e_v_t___p_h_y___m_s_c =
[
    [ "Central PHY Update", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___p_h_y___u_p_d_a_t_e.html", null ],
    [ "Peripheral PHY Update", "group___b_l_e___g_a_p___p_e_r_i_p_h_e_r_a_l___p_h_y___u_p_d_a_t_e.html", null ]
];