var group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s =
[
    [ "BLE_GAP_SCAN_INTERVAL_MAX", "group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s.html#ga074c4f810a17d67cf16c9c330f95ea52", null ],
    [ "BLE_GAP_SCAN_INTERVAL_MIN", "group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s.html#ga365a0563f4e49d868fb412509ce549ce", null ]
];