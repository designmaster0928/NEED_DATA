var group___b_l_e___u_s_e_r___m_e_m___t_y_p_e_s =
[
    [ "BLE_USER_MEM_TYPE_GATTS_QUEUED_WRITES", "group___b_l_e___u_s_e_r___m_e_m___t_y_p_e_s.html#ga77c2aca2438a868f228f877cafb5b910", null ],
    [ "BLE_USER_MEM_TYPE_INVALID", "group___b_l_e___u_s_e_r___m_e_m___t_y_p_e_s.html#ga690838a139a17cdd21661c8045073277", null ]
];