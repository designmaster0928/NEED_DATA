var group___b_l_e___g_a_p___d_i_s_c___m_o_d_e_s =
[
    [ "BLE_GAP_DISC_MODE_GENERAL", "group___b_l_e___g_a_p___d_i_s_c___m_o_d_e_s.html#ga124514248a211b305eeac9cc370c7d77", null ],
    [ "BLE_GAP_DISC_MODE_LIMITED", "group___b_l_e___g_a_p___d_i_s_c___m_o_d_e_s.html#ga5c5243da93bae524088eefd608656012", null ],
    [ "BLE_GAP_DISC_MODE_NOT_DISCOVERABLE", "group___b_l_e___g_a_p___d_i_s_c___m_o_d_e_s.html#gafdd0b7bc7d226295035ba29cee3280f6", null ]
];