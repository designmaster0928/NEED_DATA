var group__nrf__sdm__error =
[
    [ "NRF_ERROR_SDM_INCORRECT_CLENR0", "group__nrf__sdm__error.html#gaa612f324901ce4390c4010751c935d94", null ],
    [ "NRF_ERROR_SDM_INCORRECT_INTERRUPT_CONFIGURATION", "group__nrf__sdm__error.html#ga5e01566a9b1b0f6fdec349198401e5bd", null ],
    [ "NRF_ERROR_SDM_LFCLK_SOURCE_UNKNOWN", "group__nrf__sdm__error.html#ga987f38ed25beabe507da1d5dd31bbeae", null ]
];