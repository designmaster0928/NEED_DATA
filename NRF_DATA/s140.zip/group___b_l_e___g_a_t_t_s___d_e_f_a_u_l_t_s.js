var group___b_l_e___g_a_t_t_s___d_e_f_a_u_l_t_s =
[
    [ "BLE_GATTS_HVN_TX_QUEUE_SIZE_DEFAULT", "group___b_l_e___g_a_t_t_s___d_e_f_a_u_l_t_s.html#gadeb57ec178918eea438c8b4a4944ebd2", null ]
];