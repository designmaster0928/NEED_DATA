var group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c =
[
    [ "Connecting to advertisers performing extended advertising", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c___a_e.html", null ],
    [ "Connecting to legacy advertisers", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c___l_e_g_a_c_y.html", null ]
];