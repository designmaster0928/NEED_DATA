var group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___m_s_c =
[
    [ "Bonding: Numeric Comparison", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___b_o_n_d_i_n_g___n_c___m_s_c.html", null ],
    [ "Bonding: Out of Band", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___b_o_n_d_i_n_g___o_o_b___m_s_c.html", null ],
    [ "Bonding: Passkey Entry: Central Displays", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___b_o_n_d_i_n_g___p_k_e___p_d___m_s_c.html", null ],
    [ "Bonding: Passkey Entry: User Inputs on Central", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___b_o_n_d_i_n_g___p_k_e___c_d___m_s_c.html", null ],
    [ "Pairing: Just Works", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___p_a_i_r_i_n_g___j_w___m_s_c.html", null ]
];