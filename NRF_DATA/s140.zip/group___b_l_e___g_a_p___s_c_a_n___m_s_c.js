var group___b_l_e___g_a_p___s_c_a_n___m_s_c =
[
    [ "Scanning for advertisers performing legacy advertising", "group___b_l_e___g_a_p___s_c_a_n___m_s_c___l_e_g_a_c_y.html", null ],
    [ "Scanning for advertisers performing legacy and extended advertising", "group___b_l_e___g_a_p___s_c_a_n___m_s_c___a_e.html", null ]
];