var group___b_l_e___g_a_t_t_s =
[
    [ "Defines", "group___b_l_e___g_a_t_t_s___d_e_f_i_n_e_s.html", "group___b_l_e___g_a_t_t_s___d_e_f_i_n_e_s" ],
    [ "Enumerations", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s.html", "group___b_l_e___g_a_t_t_s___e_n_u_m_e_r_a_t_i_o_n_s" ],
    [ "Functions", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s" ],
    [ "Message Sequence Charts", "group___b_l_e___g_a_t_t_s___m_s_c.html", "group___b_l_e___g_a_t_t_s___m_s_c" ],
    [ "Structures", "group___b_l_e___g_a_t_t_s___s_t_r_u_c_t_u_r_e_s.html", "group___b_l_e___g_a_t_t_s___s_t_r_u_c_t_u_r_e_s" ],
    [ "User memory layout for Queued Writes", "group___b_l_e___g_a_t_t_s___q_u_e_u_e_d___w_r_i_t_e_s___u_s_e_r___m_e_m.html", null ],
    [ "User memory layout for System Attributes", "group___b_l_e___g_a_t_t_s___s_y_s___a_t_t_r_s___f_o_r_m_a_t.html", null ]
];