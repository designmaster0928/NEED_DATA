var group___b_l_e___g_a_p___a_d_v___t_i_m_e_o_u_t___v_a_l_u_e_s =
[
    [ "BLE_GAP_ADV_TIMEOUT_GENERAL_UNLIMITED", "group___b_l_e___g_a_p___a_d_v___t_i_m_e_o_u_t___v_a_l_u_e_s.html#ga09100a0666512ed8cd2e600627197254", null ],
    [ "BLE_GAP_ADV_TIMEOUT_HIGH_DUTY_MAX", "group___b_l_e___g_a_p___a_d_v___t_i_m_e_o_u_t___v_a_l_u_e_s.html#gab5430ab4f50020f9e2d50dc61d29419b", null ],
    [ "BLE_GAP_ADV_TIMEOUT_LIMITED_MAX", "group___b_l_e___g_a_p___a_d_v___t_i_m_e_o_u_t___v_a_l_u_e_s.html#ga015a498d3d56d7642dc7456fb12e08b6", null ]
];