var group___b_l_e___g_a_p___p_h_y_s =
[
    [ "BLE_GAP_PHY_1MBPS", "group___b_l_e___g_a_p___p_h_y_s.html#ga69dd87e677e5b1fc57b0874fe414e6d0", null ],
    [ "BLE_GAP_PHY_2MBPS", "group___b_l_e___g_a_p___p_h_y_s.html#ga8b773730dee79966b97bc62b5908ab7e", null ],
    [ "BLE_GAP_PHY_AUTO", "group___b_l_e___g_a_p___p_h_y_s.html#ga54b254b0493d050319d70a7a2f812aa4", null ],
    [ "BLE_GAP_PHY_CODED", "group___b_l_e___g_a_p___p_h_y_s.html#gaca98a1c4c8c2e2bc385cd81e9109068a", null ],
    [ "BLE_GAP_PHY_NOT_SET", "group___b_l_e___g_a_p___p_h_y_s.html#ga5295b344cfcb108988509bf727b9a413", null ],
    [ "BLE_GAP_PHYS_SUPPORTED", "group___b_l_e___g_a_p___p_h_y_s.html#ga39c2ccd494b4fcf4ef762f8700e16f1e", null ]
];