var group___b_l_e___u_u_i_d___t_y_p_e_s =
[
    [ "BLE_UUID_TYPE_BLE", "group___b_l_e___u_u_i_d___t_y_p_e_s.html#gae549d14b15783ba52dae5fdd5f9ac959", null ],
    [ "BLE_UUID_TYPE_UNKNOWN", "group___b_l_e___u_u_i_d___t_y_p_e_s.html#ga0dfc5e26324c8cd7226f3941acbf5b7e", null ],
    [ "BLE_UUID_TYPE_VENDOR_BEGIN", "group___b_l_e___u_u_i_d___t_y_p_e_s.html#ga7bdcaea9ea91ab20be755d78833da46d", null ]
];