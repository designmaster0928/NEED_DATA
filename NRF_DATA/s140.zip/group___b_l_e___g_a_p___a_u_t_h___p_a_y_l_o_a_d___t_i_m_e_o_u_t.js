var group___b_l_e___g_a_p___a_u_t_h___p_a_y_l_o_a_d___t_i_m_e_o_u_t =
[
    [ "BLE_GAP_AUTH_PAYLOAD_TIMEOUT_MAX", "group___b_l_e___g_a_p___a_u_t_h___p_a_y_l_o_a_d___t_i_m_e_o_u_t.html#gae7a1668171c8d627b5fbb330fd4a8280", null ],
    [ "BLE_GAP_AUTH_PAYLOAD_TIMEOUT_MIN", "group___b_l_e___g_a_p___a_u_t_h___p_a_y_l_o_a_d___t_i_m_e_o_u_t.html#ga4f65f3b545257b4d2b4d1b7bec91cb20", null ]
];