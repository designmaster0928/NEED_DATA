var group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s =
[
    [ "BLE_GATTS_SRVC_TYPE_INVALID", "group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s.html#ga07c49b0b262d0b5bd709d282b659436d", null ],
    [ "BLE_GATTS_SRVC_TYPE_PRIMARY", "group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s.html#ga881b91f3ac789bf6fcefee7f815dcf7e", null ],
    [ "BLE_GATTS_SRVC_TYPE_SECONDARY", "group___b_l_e___g_a_t_t_s___s_r_v_c___t_y_p_e_s.html#ga1aa1898278ef4d0034858d752eac29b0", null ]
];