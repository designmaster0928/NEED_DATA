var group___n_r_f___f_a_u_l_t___i_d_s =
[
    [ "NRF_FAULT_ID_APP_MEMACC", "group___n_r_f___f_a_u_l_t___i_d_s.html#ga234338bb9d7e0f116a6e7112819cce6d", null ],
    [ "NRF_FAULT_ID_SD_ASSERT", "group___n_r_f___f_a_u_l_t___i_d_s.html#ga3884a419c2f90d294672e79711d009bf", null ]
];