var group___b_l_e___g_a_p___m_s_c =
[
    [ "Advertising", "group___b_l_e___g_a_p___a_d_v___m_s_c.html", "group___b_l_e___g_a_p___a_d_v___m_s_c" ],
    [ "Central Connection Establishment and Termination", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c.html", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c" ],
    [ "Central Connection Parameter Update", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_p_u___m_s_c.html", null ],
    [ "Central Connection Parameter Update on multiple links", "group___b_l_e___g_a_p___m_u_l_t_i_l_i_n_k___c_p_u___m_s_c.html", null ],
    [ "Central Control Procedure Serialization on multiple links", "group___b_l_e___g_a_p___m_u_l_t_i_l_i_n_k___c_t_r_l___p_r_o_c___m_s_c.html", null ],
    [ "Central Security Procedures", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___s_e_c___m_s_c.html", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___s_e_c___m_s_c" ],
    [ "Data Length Update Procedure", "group___b_l_e___g_a_p___d_a_t_a___l_e_n_g_t_h___u_p_d_a_t_e___p_r_o_c_e_d_u_r_e___m_s_c.html", null ],
    [ "PHY Update Procedure", "group___b_l_e___g_a_p___e_v_t___p_h_y___m_s_c.html", "group___b_l_e___g_a_p___e_v_t___p_h_y___m_s_c" ],
    [ "Peripheral Connection Establishment and Termination", "group___b_l_e___g_a_p___c_o_n_n___m_s_c.html", null ],
    [ "Peripheral Connection Parameter Update", "group___b_l_e___g_a_p___c_p_u___m_s_c.html", null ],
    [ "Peripheral Security Procedures", "group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___m_s_c.html", "group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___m_s_c" ],
    [ "Privacy", "group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_s_c.html", "group___b_l_e___g_a_p___p_r_i_v_a_c_y___m_s_c" ],
    [ "RSSI for connections with event filter", "group___b_l_e___g_a_p___r_s_s_i___f_i_l_t___m_s_c.html", null ],
    [ "RSSI get sample", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___r_s_s_i___r_e_a_d___m_s_c.html", null ],
    [ "Scanning", "group___b_l_e___g_a_p___s_c_a_n___m_s_c.html", "group___b_l_e___g_a_p___s_c_a_n___m_s_c" ],
    [ "Whitelist Sharing", "group___b_l_e___g_a_p___w_l___s_h_a_r_e___m_s_c.html", null ]
];