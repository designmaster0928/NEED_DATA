var group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s =
[
    [ "__NRF_NVIC_APP_IRQ_PRIOS", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#ga8e2c991d822872cc3c65aae56fe4529f", null ],
    [ "__NRF_NVIC_APP_IRQS_0", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#gaba5de891cdd369c5fc540172dec31e89", null ],
    [ "__NRF_NVIC_APP_IRQS_1", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#gabdd12cd924ec1ea227b2a9d4d06b1438", null ],
    [ "__NRF_NVIC_ISER_COUNT", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#ga487877945b5d9de06c09f4502898dd90", null ],
    [ "__NRF_NVIC_NVMC_IRQn", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#gaf5d0e819980db5a60b98b5b3d7d1949f", null ],
    [ "__NRF_NVIC_SD_IRQ_PRIOS", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#gaedd584de59039aae804b1f7a4b9050b7", null ],
    [ "__NRF_NVIC_SD_IRQS_0", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#ga468d3a7a1fc64c089654d67254d036c2", null ],
    [ "__NRF_NVIC_SD_IRQS_1", "group___n_r_f___n_v_i_c___i_s_e_r___d_e_f_i_n_e_s.html#gab689c126d2d4efe4bde1fdceebb68d4d", null ]
];