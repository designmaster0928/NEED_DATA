var group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s =
[
    [ "sd_ble_cfg_set", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga4edae2bac8c68b672c0fa101ed2c687f", null ],
    [ "sd_ble_enable", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga8a92420df90945526d4c89d09486508d", null ],
    [ "sd_ble_evt_get", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga412b12b43c253dd744bcf574d6e86f43", null ],
    [ "sd_ble_opt_get", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#gad64712eef7dba0287275d185768c5291", null ],
    [ "sd_ble_opt_set", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga511d431bc3d9ccf9bef09ad20cbf855a", null ],
    [ "sd_ble_user_mem_reply", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga6d49592ed6722290fee71419be7dac1f", null ],
    [ "sd_ble_uuid_decode", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga53a62e0d6e8604b73c937f89424b89ba", null ],
    [ "sd_ble_uuid_encode", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga2e55f7d7e631d072c24f2d6bc0860cc8", null ],
    [ "sd_ble_uuid_vs_add", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#ga265b4251110a15120d0aa97e5152163b", null ],
    [ "sd_ble_uuid_vs_remove", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#gaf9814a42465b2d51fba4aae3a05bdb95", null ],
    [ "sd_ble_version_get", "group___b_l_e___c_o_m_m_o_n___f_u_n_c_t_i_o_n_s.html#gab3ba7bb07fa809e8dccfd27cbba0210a", null ]
];