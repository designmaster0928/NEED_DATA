var group___b_l_e___g_a_t_t___d_e_f_i_n_e_s =
[
    [ "Characteristic Presentation Formats", "group___b_l_e___g_a_t_t___c_p_f___f_o_r_m_a_t_s.html", "group___b_l_e___g_a_t_t___c_p_f___f_o_r_m_a_t_s" ],
    [ "GATT Bluetooth Namespaces", "group___b_l_e___g_a_t_t___c_p_f___n_a_m_e_s_p_a_c_e_s.html", "group___b_l_e___g_a_t_t___c_p_f___n_a_m_e_s_p_a_c_e_s" ],
    [ "GATT Execute Write flags", "group___b_l_e___g_a_t_t___e_x_e_c___w_r_i_t_e___f_l_a_g_s.html", "group___b_l_e___g_a_t_t___e_x_e_c___w_r_i_t_e___f_l_a_g_s" ],
    [ "GATT Handle Value operations", "group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s.html", "group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s" ],
    [ "GATT Status Codes", "group___b_l_e___g_a_t_t___s_t_a_t_u_s___c_o_d_e_s.html", "group___b_l_e___g_a_t_t___s_t_a_t_u_s___c_o_d_e_s" ],
    [ "GATT Timeout sources", "group___b_l_e___g_a_t_t___t_i_m_e_o_u_t___s_o_u_r_c_e_s.html", "group___b_l_e___g_a_t_t___t_i_m_e_o_u_t___s_o_u_r_c_e_s" ],
    [ "GATT Write operations", "group___b_l_e___g_a_t_t___w_r_i_t_e___o_p_s.html", "group___b_l_e___g_a_t_t___w_r_i_t_e___o_p_s" ],
    [ "SVC return values specific to GATT", "group___b_l_e___e_r_r_o_r_s___g_a_t_t.html", null ],
    [ "BLE_GATT_ATT_MTU_DEFAULT", "group___b_l_e___g_a_t_t___d_e_f_i_n_e_s.html#ga56f8a5e50e3e703e466a122c4cab4efb", null ],
    [ "BLE_GATT_HANDLE_END", "group___b_l_e___g_a_t_t___d_e_f_i_n_e_s.html#gac0f6655e71d87cf611fa9583e9e00dfe", null ],
    [ "BLE_GATT_HANDLE_INVALID", "group___b_l_e___g_a_t_t___d_e_f_i_n_e_s.html#ga755613d0f9d0979be50a3814c1436ab9", null ],
    [ "BLE_GATT_HANDLE_START", "group___b_l_e___g_a_t_t___d_e_f_i_n_e_s.html#ga3f91ff3ec95d3b6d2e0cc1b800bc0995", null ]
];