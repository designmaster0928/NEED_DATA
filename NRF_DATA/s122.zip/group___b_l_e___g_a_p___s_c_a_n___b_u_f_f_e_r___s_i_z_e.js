var group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e =
[
    [ "BLE_GAP_SCAN_BUFFER_MAX", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#gab273184f504c5637cb193067e75faf67", null ],
    [ "BLE_GAP_SCAN_BUFFER_MIN", "group___b_l_e___g_a_p___s_c_a_n___b_u_f_f_e_r___s_i_z_e.html#gacc6fd0bc6de5ff8924a5d50526253676", null ]
];