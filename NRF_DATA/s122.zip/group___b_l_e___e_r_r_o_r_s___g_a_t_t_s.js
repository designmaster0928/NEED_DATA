var group___b_l_e___e_r_r_o_r_s___g_a_t_t_s =
[
    [ "BLE_ERROR_GATTS_INVALID_ATTR_TYPE", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_s.html#ga050988950fb5cfb9e64b1f91f8872b45", null ],
    [ "BLE_ERROR_GATTS_SYS_ATTR_MISSING", "group___b_l_e___e_r_r_o_r_s___g_a_t_t_s.html#ga1d0833ac31d0c319e5286623b6301d0a", null ]
];