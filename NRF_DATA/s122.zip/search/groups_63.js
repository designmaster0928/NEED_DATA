var searchData=
[
  ['configuration_20defaults_2e',['Configuration defaults.',['../group___b_l_e___c_o_m_m_o_n___c_f_g___d_e_f_a_u_l_t_s.html',1,'']]],
  ['connection_20configuration',['Connection Configuration',['../group___b_l_e___c_o_n_n___c_f_g.html',1,'']]],
  ['central_20connection_20establishment_20and_20termination',['Central Connection Establishment and Termination',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___m_s_c.html',1,'']]],
  ['central_20connection_20establishment_20with_20private_20peer',['Central Connection Establishment with Private Peer',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_o_n_n___p_r_i_v___m_s_c.html',1,'']]],
  ['central_20connection_20parameter_20update',['Central Connection Parameter Update',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___c_p_u___m_s_c.html',1,'']]],
  ['central_20encryption_20and_20authentication_20mutual_20exclusion',['Central Encryption and Authentication mutual exclusion',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___e_n_c___a_u_t_h___m_u_t_e_x___m_s_c.html',1,'']]],
  ['central_20legacy_20pairing',['Central Legacy Pairing',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_g_a_c_y___m_s_c.html',1,'']]],
  ['central_20lesc_20pairing',['Central LESC Pairing',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___m_s_c.html',1,'']]],
  ['central_20phy_20update',['Central PHY Update',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___p_h_y___u_p_d_a_t_e.html',1,'']]],
  ['central_20security_20procedures',['Central Security Procedures',['../group___b_l_e___g_a_p___c_e_n_t_r_a_l___s_e_c___m_s_c.html',1,'']]],
  ['characteristic_20inclusion_20default_20values',['Characteristic inclusion default values',['../group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g___d_e_f_a_u_l_t_s.html',1,'']]],
  ['central_20connection_20parameter_20update_20on_20multiple_20links',['Central Connection Parameter Update on multiple links',['../group___b_l_e___g_a_p___m_u_l_t_i_l_i_n_k___c_p_u___m_s_c.html',1,'']]],
  ['central_20control_20procedure_20serialization_20on_20multiple_20links',['Central Control Procedure Serialization on multiple links',['../group___b_l_e___g_a_p___m_u_l_t_i_l_i_n_k___c_t_r_l___p_r_o_c___m_s_c.html',1,'']]],
  ['characteristic_20presentation_20formats',['Characteristic Presentation Formats',['../group___b_l_e___g_a_t_t___c_p_f___f_o_r_m_a_t_s.html',1,'']]],
  ['common_20types_20and_20macro_20definitions',['Common types and macro definitions',['../group__ble__types.html',1,'']]],
  ['clock_20accuracy',['Clock accuracy',['../group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html',1,'']]]
];
