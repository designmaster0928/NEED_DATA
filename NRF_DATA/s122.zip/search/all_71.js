var searchData=
[
  ['quality_20of_20service_20_28qos_29_20channel_20survey_20interval_20defines',['Quality of Service (QoS) Channel survey interval defines',['../group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s.html',1,'']]],
  ['qos_5fchannel_5fsurvey_5freport',['qos_channel_survey_report',['../structble__gap__evt__t.html#a8bf4aca6093c2e0720f63fcb7d3077c0',1,'ble_gap_evt_t']]],
  ['qos_5fchannel_5fsurvey_5frole_5favailable',['qos_channel_survey_role_available',['../structble__gap__cfg__role__count__t.html#a8449bc3d874d5c5ec2d0863cc41e5ab1',1,'ble_gap_cfg_role_count_t']]],
  ['qos_5fconn_5fevent_5freport',['qos_conn_event_report',['../structble__gap__evt__t.html#a26f5e96c7bd2c906bc8a5cecf03b508c',1,'ble_gap_evt_t']]]
];
