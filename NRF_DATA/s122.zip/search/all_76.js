var searchData=
[
  ['vendor_20specific_20base_20uuid_20counts',['Vendor Specific base UUID counts',['../group___b_l_e___u_u_i_d___v_s___c_o_u_n_t_s.html',1,'']]],
  ['variables',['Variables',['../group___n_r_f___n_v_i_c___v_a_r_i_a_b_l_e_s.html',1,'']]],
  ['value_5fhandle',['value_handle',['../structble__gatts__char__handles__t.html#a685865a59e73158fd661e9d64407e9d9',1,'ble_gatts_char_handles_t']]],
  ['value_5flen',['value_len',['../structble__gattc__evt__char__val__by__uuid__read__rsp__t.html#a91e554093e8f445960abff9c0015193c',1,'ble_gattc_evt_char_val_by_uuid_read_rsp_t']]],
  ['values',['values',['../structble__gattc__evt__char__vals__read__rsp__t.html#ac586dcb02b8f378127157ee8c45abea9',1,'ble_gattc_evt_char_vals_read_rsp_t']]],
  ['version_5fnumber',['version_number',['../structble__version__t.html#af18ca1a9b3d80b05042d9121e9d3c9ed',1,'ble_version_t']]],
  ['vlen',['vlen',['../structble__gatts__attr__md__t.html#a921e414734cd784e0c3b7309d3a14f39',1,'ble_gatts_attr_md_t']]],
  ['vloc',['vloc',['../structble__gap__cfg__device__name__t.html#a44d99a12d36514d68b71e15c8cc58fc8',1,'ble_gap_cfg_device_name_t::vloc()'],['../structble__gatts__attr__md__t.html#abbd6b9b2d75565fc6fd66074a47308c7',1,'ble_gatts_attr_md_t::vloc()']]],
  ['vs_5fuuid_5fcfg',['vs_uuid_cfg',['../unionble__common__cfg__t.html#ae418f68b05d97f0c245c4a8d8af75644',1,'ble_common_cfg_t']]],
  ['vs_5fuuid_5fcount',['vs_uuid_count',['../structble__common__cfg__vs__uuid__t.html#a751b383c3255e4996ac0e01f611d53fb',1,'ble_common_cfg_vs_uuid_t']]]
];
