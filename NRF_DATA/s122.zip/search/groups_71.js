var searchData=
[
  ['quality_20of_20service_20_28qos_29_20channel_20survey_20interval_20defines',['Quality of Service (QoS) Channel survey interval defines',['../group___b_l_e___g_a_p___q_o_s___c_h_a_n_n_e_l___s_u_r_v_e_y___i_n_t_e_r_v_a_l_s.html',1,'']]]
];
