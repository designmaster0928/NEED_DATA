var searchData=
[
  ['advertising_20data_20sizes_2e',['Advertising data sizes.',['../group___b_l_e___g_a_p___a_d_v___s_e_t___d_a_t_a___s_i_z_e_s.html',1,'']]],
  ['authenticated_20payload_20timeout_20defines_2e',['Authenticated payload timeout defines.',['../group___b_l_e___g_a_p___a_u_t_h___p_a_y_l_o_a_d___t_i_m_e_o_u_t.html',1,'']]],
  ['attribute_20information_20formats',['Attribute Information Formats',['../group___b_l_e___g_a_t_t_c___a_t_t_r___i_n_f_o___f_o_r_m_a_t.html',1,'']]],
  ['attribute_20table_20size',['Attribute Table size',['../group___b_l_e___g_a_t_t_s___a_t_t_r___t_a_b___s_i_z_e.html',1,'']]],
  ['assigned_20values_20for_20ble_20uuids',['Assigned Values for BLE UUIDs',['../group___b_l_e___u_u_i_d___v_a_l_u_e_s.html',1,'']]]
];
