var group___b_l_e___g_a_p___r_o_l_e_s =
[
    [ "BLE_GAP_ROLE_CENTRAL", "group___b_l_e___g_a_p___r_o_l_e_s.html#ga6b9440660a70146392d27c849431fadb", null ],
    [ "BLE_GAP_ROLE_INVALID", "group___b_l_e___g_a_p___r_o_l_e_s.html#ga8164b32f4fd65997d0523cd7c5735166", null ]
];