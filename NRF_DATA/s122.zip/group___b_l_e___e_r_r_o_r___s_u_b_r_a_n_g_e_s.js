var group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s =
[
    [ "NRF_GAP_ERR_BASE", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html#ga29249baa158d723505c601121d003034", null ],
    [ "NRF_GATT_ERR_BASE", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html#gad1d9e58bc620693ba253308c5754e7fe", null ],
    [ "NRF_GATTC_ERR_BASE", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html#ga200400dc8ad79918acee9cd038336165", null ],
    [ "NRF_GATTS_ERR_BASE", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html#ga7bc503f781e56a86cdd044d6043629b8", null ],
    [ "NRF_L2CAP_ERR_BASE", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html#ga82756b5d44b6b5757c3968513b4928ac", null ]
];