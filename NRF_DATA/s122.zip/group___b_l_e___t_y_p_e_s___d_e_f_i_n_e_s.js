var group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s =
[
    [ "Assigned Values for BLE UUIDs", "group___b_l_e___u_u_i_d___v_a_l_u_e_s.html", "group___b_l_e___u_u_i_d___v_a_l_u_e_s" ],
    [ "BLE Connection Handles", "group___b_l_e___c_o_n_n___h_a_n_d_l_e_s.html", "group___b_l_e___c_o_n_n___h_a_n_d_l_e_s" ],
    [ "Bluetooth Appearance values", "group___b_l_e___a_p_p_e_a_r_a_n_c_e_s.html", "group___b_l_e___a_p_p_e_a_r_a_n_c_e_s" ],
    [ "Types of UUID", "group___b_l_e___u_u_i_d___t_y_p_e_s.html", "group___b_l_e___u_u_i_d___t_y_p_e_s" ],
    [ "BLE_UUID_BLE_ASSIGN", "group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html#gac4478362651889d2ade8030f53713588", null ],
    [ "BLE_UUID_COPY_INST", "group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html#ga7b7bc0d395b3436d101cbf183a16fd8f", null ],
    [ "BLE_UUID_COPY_PTR", "group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html#gae760be8e12d22dc39e9dca99bdf33536", null ],
    [ "BLE_UUID_EQ", "group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html#gaa8d7439022acdbd47118aab389084298", null ],
    [ "BLE_UUID_NEQ", "group___b_l_e___t_y_p_e_s___d_e_f_i_n_e_s.html#ga06eb7ac9c1db7d9a1ef2fb7d6fb4e5ec", null ]
];