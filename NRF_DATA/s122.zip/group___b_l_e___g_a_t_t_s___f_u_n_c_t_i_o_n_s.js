var group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s =
[
    [ "sd_ble_gatts_attr_get", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga3bbfe51024584805a425287109b596c2", null ],
    [ "sd_ble_gatts_characteristic_add", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga9ee07ea4b96dcca1537b01ff9a7692ba", null ],
    [ "sd_ble_gatts_descriptor_add", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga0e1478bd565ad99f998671e3baf9847d", null ],
    [ "sd_ble_gatts_exchange_mtu_reply", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#gacb80e44fb1309fe388c6baf747f6f994", null ],
    [ "sd_ble_gatts_hvx", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga313fe43c2e93267da668572e885945db", null ],
    [ "sd_ble_gatts_include_add", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga591ba1e7e2b8ecb63541a1f2d5282b76", null ],
    [ "sd_ble_gatts_initial_user_handle_get", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#gab25c28e9abd5fc0db01bfc8f09dfeaa6", null ],
    [ "sd_ble_gatts_rw_authorize_reply", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga6de7aea3a870669e1d869b047de95545", null ],
    [ "sd_ble_gatts_service_add", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga39fea660228e4b2e788af7018a83927a", null ],
    [ "sd_ble_gatts_service_changed", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga2c8c90d73fa27ba6691ad82b4a960adc", null ],
    [ "sd_ble_gatts_sys_attr_get", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga4a44241bdcc7262603841f77d9eeb29f", null ],
    [ "sd_ble_gatts_sys_attr_set", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga577c788e199b1a2c0d19602b07ef2515", null ],
    [ "sd_ble_gatts_value_get", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#gad95321e157e632e7ac3a77f3388cbdf7", null ],
    [ "sd_ble_gatts_value_set", "group___b_l_e___g_a_t_t_s___f_u_n_c_t_i_o_n_s.html#ga2760c51ea71853bd74e2e7e7117ef52a", null ]
];