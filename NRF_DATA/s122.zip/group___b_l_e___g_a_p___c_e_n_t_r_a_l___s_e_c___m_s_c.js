var group___b_l_e___g_a_p___c_e_n_t_r_a_l___s_e_c___m_s_c =
[
    [ "Central Encryption and Authentication mutual exclusion", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___e_n_c___a_u_t_h___m_u_t_e_x___m_s_c.html", null ],
    [ "Central LESC Pairing", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___m_s_c.html", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_s_c___m_s_c" ],
    [ "Central Legacy Pairing", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_g_a_c_y___m_s_c.html", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___l_e_g_a_c_y___m_s_c" ],
    [ "Encryption Establishment using stored keys", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___e_n_c___m_s_c.html", null ],
    [ "Security Request Reception", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___s_e_c___r_e_q___m_s_c.html", null ],
    [ "Unexpected Security Packet Reception", "group___b_l_e___g_a_p___c_e_n_t_r_a_l___i_n_v_a_l_i_d___s_m_p___p_d_u___m_s_c.html", null ]
];