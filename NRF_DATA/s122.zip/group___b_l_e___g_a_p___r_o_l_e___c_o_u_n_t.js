var group___b_l_e___g_a_p___r_o_l_e___c_o_u_n_t =
[
    [ "BLE_GAP_ROLE_COUNT_CENTRAL_DEFAULT", "group___b_l_e___g_a_p___r_o_l_e___c_o_u_n_t.html#ga12d418241f609278ccd5e33907f980d0", null ],
    [ "BLE_GAP_ROLE_COUNT_CENTRAL_SEC_DEFAULT", "group___b_l_e___g_a_p___r_o_l_e___c_o_u_n_t.html#ga367a538407485212ea425552577292d1", null ],
    [ "BLE_GAP_ROLE_COUNT_COMBINED_MAX", "group___b_l_e___g_a_p___r_o_l_e___c_o_u_n_t.html#ga6d3abe9726e03785cf37550c4af1ecb8", null ]
];