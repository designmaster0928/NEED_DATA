var group___b_l_e___e_r_r_o_r_s___g_a_p =
[
    [ "BLE_ERROR_GAP_DEVICE_IDENTITIES_DUPLICATE", "group___b_l_e___e_r_r_o_r_s___g_a_p.html#ga2b24978221049496f2a39947fbb29105", null ],
    [ "BLE_ERROR_GAP_DEVICE_IDENTITIES_IN_USE", "group___b_l_e___e_r_r_o_r_s___g_a_p.html#ga257371c3cf06045f7d4be9eb7b6c03f7", null ],
    [ "BLE_ERROR_GAP_INVALID_BLE_ADDR", "group___b_l_e___e_r_r_o_r_s___g_a_p.html#ga3eda228736d6c1dcbcf9aba2bd059068", null ],
    [ "BLE_ERROR_GAP_UUID_LIST_MISMATCH", "group___b_l_e___e_r_r_o_r_s___g_a_p.html#ga996146eb2c3b244f044b5cd121f8b826", null ],
    [ "BLE_ERROR_GAP_WHITELIST_IN_USE", "group___b_l_e___e_r_r_o_r_s___g_a_p.html#ga962fe94f2d658ce27d625e731ee2a844", null ]
];