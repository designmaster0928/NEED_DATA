var group___b_l_e___g_a_p___a_d_v___s_e_t___d_a_t_a___s_i_z_e_s =
[
    [ "BLE_GAP_ADV_SET_DATA_SIZE_MAX", "group___b_l_e___g_a_p___a_d_v___s_e_t___d_a_t_a___s_i_z_e_s.html#ga8a4d6c6db6ae1712684d75f362e660bb", null ]
];