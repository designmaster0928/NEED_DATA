var group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s =
[
    [ "BLE_GAP_SCAN_INTERVAL_US_MAX", "group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s.html#ga5ac538d8302c0ea95d202f9811ee4539", null ],
    [ "BLE_GAP_SCAN_INTERVAL_US_MIN", "group___b_l_e___g_a_p___s_c_a_n___i_n_t_e_r_v_a_l_s.html#ga4594c490af456f8949e57568de5f0963", null ]
];