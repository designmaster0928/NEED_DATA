var group__ble__err =
[
    [ "BLE_ERROR_BLOCKED_BY_OTHER_LINKS", "group__ble__err.html#ga84a1d9665c74403a0f3fc81da5f43034", null ],
    [ "BLE_ERROR_INVALID_ADV_HANDLE", "group__ble__err.html#ga3f3e21cbd6cf24e72e5bf641098379aa", null ],
    [ "BLE_ERROR_INVALID_ATTR_HANDLE", "group__ble__err.html#ga6346bb5ec3bcd4a25332dc782c1b7e01", null ],
    [ "BLE_ERROR_INVALID_CONN_HANDLE", "group__ble__err.html#gabdc27cbc2ffac4a50640a0ce992c03af", null ],
    [ "BLE_ERROR_INVALID_ROLE", "group__ble__err.html#ga1d92ffe1952beeff89e5bf768657460f", null ],
    [ "BLE_ERROR_NOT_ENABLED", "group__ble__err.html#ga521db6a097589b80939d76cb453fad3c", null ],
    [ "BLE_ERROR_UNSUPPORTED_REMOTE_FEATURE", "group__ble__err.html#gafbfae84dd5f2ac7ba77f0ec13a837861", null ]
];