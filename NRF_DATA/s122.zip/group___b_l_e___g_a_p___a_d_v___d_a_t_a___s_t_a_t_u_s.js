var group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s =
[
    [ "BLE_GAP_ADV_DATA_STATUS_COMPLETE", "group___b_l_e___g_a_p___a_d_v___d_a_t_a___s_t_a_t_u_s.html#gad099a8d2746dbc7070dc4bdf947d50d5", null ]
];