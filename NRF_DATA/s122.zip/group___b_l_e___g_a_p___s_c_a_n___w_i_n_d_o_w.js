var group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w =
[
    [ "BLE_GAP_SCAN_WINDOW_1MBPS_US_MIN", "group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w.html#ga38c7705299bf866eae9fdcff3f478361", null ],
    [ "BLE_GAP_SCAN_WINDOW_US_MAX", "group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w.html#ga23b8c09ed10de5fbd760664a5e7b11d9", null ],
    [ "BLE_GAP_SCAN_WINDOW_US_MIN", "group___b_l_e___g_a_p___s_c_a_n___w_i_n_d_o_w.html#ga62b75505bf7d6a69c69df76fbcf26b37", null ]
];