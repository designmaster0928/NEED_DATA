var group___n_r_f___f_a_u_l_t___i_d___r_a_n_g_e_s =
[
    [ "NRF_FAULT_ID_APP_RANGE_START", "group___n_r_f___f_a_u_l_t___i_d___r_a_n_g_e_s.html#ga06641290a0e19c42546212874739c38d", null ],
    [ "NRF_FAULT_ID_SD_RANGE_START", "group___n_r_f___f_a_u_l_t___i_d___r_a_n_g_e_s.html#gac8d2afc952ef4acf65779e5724af7c0c", null ]
];