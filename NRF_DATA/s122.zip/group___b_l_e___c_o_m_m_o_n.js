var group___b_l_e___c_o_m_m_o_n =
[
    [ "Bluetooth status codes", "group___b_l_e___h_c_i___s_t_a_t_u_s___c_o_d_e_s.html", "group___b_l_e___h_c_i___s_t_a_t_u_s___c_o_d_e_s" ],
    [ "Common types and macro definitions", "group__ble__types.html", "group__ble__types" ],
    [ "Events, type definitions and API calls", "group__ble__api.html", "group__ble__api" ],
    [ "General error codes", "group__ble__err.html", "group__ble__err" ],
    [ "Message Sequence Charts", "group___b_l_e___c_o_m_m_o_n___m_s_c.html", "group___b_l_e___c_o_m_m_o_n___m_s_c" ],
    [ "Module specific SVC, event and option number subranges", "group__ble__ranges.html", "group__ble__ranges" ],
    [ "Module specific error code subranges", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s.html", "group___b_l_e___e_r_r_o_r___s_u_b_r_a_n_g_e_s" ],
    [ "SoftDevice Global Error Codes", "group__nrf__error.html", "group__nrf__error" ]
];