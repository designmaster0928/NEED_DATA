var group___b_l_e___g_a_p___c_o_n_n___i_n_t_v_l___u_n_i_t_s =
[
    [ "BLE_GAP_CONN_INTVL_MS_TO_UNITS", "group___b_l_e___g_a_p___c_o_n_n___i_n_t_v_l___u_n_i_t_s.html#ga834539f2845c95a07f50143a05bc9489", null ]
];