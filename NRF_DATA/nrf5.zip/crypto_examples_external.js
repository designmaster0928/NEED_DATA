var crypto_examples_external =
[
    [ "CryptoCell Integration Tests", "cryptocell_example.html", [
      [ "Testing", "cryptocell_example.html#cryptocell_example_test", null ]
    ] ],
    [ "CryptoCell nrf_cc310_bl Library Integration Tests", "nrf_cc310_bl_example.html", [
      [ "Testing", "nrf_cc310_bl_example.html#nrf_cc310_bl_example_test", null ]
    ] ],
    [ "Infineon OPTIGA™ Trust X Custom Example", "ifx_optiga_custom_example.html", [
      [ "Testing", "ifx_optiga_custom_example.html#app_ifx_optiga_custom_example_testing", null ]
    ] ]
];