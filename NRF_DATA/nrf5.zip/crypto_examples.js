var crypto_examples =
[
    [ "nrf_crypto examples", "crypto_examples_nrf_crypto.html", "crypto_examples_nrf_crypto" ],
    [ "External crypto examples", "crypto_examples_external.html", "crypto_examples_external" ]
];