var group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s =
[
    [ "BLE_L2CAP_CH_STATUS_CODE_INSUFF_AUTHENTICATION", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gaff159b76b09ede603732da3b523173fc", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_INSUFF_AUTHORIZATION", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga4f9d69d2a15c50349e9354fa0c34a0f4", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_INSUFF_ENC", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gaab61fb9ce2843cd6a682b19e47e66733", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_INSUFF_ENC_KEY_SIZE", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gac40e685b62bda39684a7e8433c20e929", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_INVALID_SCID", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gafe81f85d65875f1ac64e2afb87f587fc", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_LE_PSM_NOT_SUPPORTED", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gabe174b797cca55791a9c34216c6eb4be", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_NO_RESOURCES", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga30cd87aff972b35a3ef7f8db36c806ff", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_NOT_UNDERSTOOD", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#gaa2af2bdf623db4d041dc8f016470af42", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_SCID_ALLOCATED", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga983116d0b7567f7b6cd466808f96cc08", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_SUCCESS", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga1582b67f1b4d27e176741f722a8ec61a", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_TIMEOUT", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga87be83c306641604cb8537c94e6cb6ac", null ],
    [ "BLE_L2CAP_CH_STATUS_CODE_UNACCEPTABLE_PARAMS", "group___b_l_e___l2_c_a_p___c_h___s_t_a_t_u_s___c_o_d_e_s.html#ga85462664b2249ef7cc029d0ad6ef8f70", null ]
];