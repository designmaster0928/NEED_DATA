var group___b_l_e___g_a_t_t___c_p_f___n_a_m_e_s_p_a_c_e_s =
[
    [ "BLE_GATT_CPF_NAMESPACE_BTSIG", "group___b_l_e___g_a_t_t___c_p_f___n_a_m_e_s_p_a_c_e_s.html#ga2b4621b5720da826d9b41331af2c6232", null ],
    [ "BLE_GATT_CPF_NAMESPACE_DESCRIPTION_UNKNOWN", "group___b_l_e___g_a_t_t___c_p_f___n_a_m_e_s_p_a_c_e_s.html#ga2639ceb9f7ea5333b153a5751558f6af", null ]
];