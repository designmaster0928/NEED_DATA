var group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___m_s_c =
[
    [ "GAP Failed Pairing: Keysize too small", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___k_s___t_o_o___s_m_a_l_l___m_s_c.html", null ],
    [ "Pairing failure: Keysize out of supported range", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___k_s___o_u_t___o_f___r_a_n_g_e___m_s_c.html", null ],
    [ "Pairing failure: Pairing aborted by the application", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___a_p_p___e_r_r_o_r___m_s_c.html", null ],
    [ "Pairing failure: Pairing failed from central", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___r_e_m_o_t_e___p_a_i_r_i_n_g___f_a_i_l___m_s_c.html", null ],
    [ "Pairing failure: Timeout", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___t_i_m_e_o_u_t___m_s_c.html", null ],
    [ "Peripheral Encryption Establishment using stored keys", "group___b_l_e___g_a_p___p_e_r_i_p_h___e_n_c___m_s_c.html", null ],
    [ "Peripheral LESC Pairing", "group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_s_c___m_s_c.html", "group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_s_c___m_s_c" ],
    [ "Peripheral Legacy Pairing", "group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_g_a_c_y___m_s_c.html", "group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_g_a_c_y___m_s_c" ],
    [ "Peripheral Security Request", "group___b_l_e___g_a_p___p_e_r_i_p_h___s_e_c___r_e_q___m_s_c.html", null ],
    [ "Unexpected Security Packet Reception", "group___b_l_e___g_a_p___p_e_r_i_p_h___i_n_v_a_l_i_d___s_m_p___p_d_u___m_s_c.html", null ]
];