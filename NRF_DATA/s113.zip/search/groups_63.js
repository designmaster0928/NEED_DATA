var searchData=
[
  ['configuration_20defaults_2e',['Configuration defaults.',['../group___b_l_e___c_o_m_m_o_n___c_f_g___d_e_f_a_u_l_t_s.html',1,'']]],
  ['connection_20configuration',['Connection Configuration',['../group___b_l_e___c_o_n_n___c_f_g.html',1,'']]],
  ['characteristic_20inclusion_20default_20values',['Characteristic inclusion default values',['../group___b_l_e___g_a_p___c_h_a_r___i_n_c_l___c_o_n_f_i_g___d_e_f_a_u_l_t_s.html',1,'']]],
  ['characteristic_20presentation_20formats',['Characteristic Presentation Formats',['../group___b_l_e___g_a_t_t___c_p_f___f_o_r_m_a_t_s.html',1,'']]],
  ['common_20types_20and_20macro_20definitions',['Common types and macro definitions',['../group__ble__types.html',1,'']]],
  ['clock_20accuracy',['Clock accuracy',['../group___n_r_f___c_l_o_c_k___l_f___a_c_c_u_r_a_c_y.html',1,'']]]
];
