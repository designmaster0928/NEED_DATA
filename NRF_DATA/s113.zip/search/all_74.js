var searchData=
[
  ['thread_20mode_20event_20retrieval',['Thread Mode Event Retrieval',['../group___b_l_e___c_o_m_m_o_n___t_h_r_e_a_d___e_v_t___m_s_c.html',1,'']]],
  ['terminology',['Terminology',['../group___b_l_e___l2_c_a_p___t_e_r_m_i_n_o_l_o_g_y.html',1,'']]],
  ['types_20of_20uuid',['Types of UUID',['../group___b_l_e___u_u_i_d___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___m_b_r___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___s_d_m___t_y_p_e_s.html',1,'']]],
  ['task_5fendpoint',['task_endpoint',['../structble__gap__conn__event__trigger__t.html#af093ef19769cbafea4a257da90176926',1,'ble_gap_conn_event_trigger_t']]],
  ['timeout',['timeout',['../structble__gap__evt__t.html#ae8165f09cf3e00673a15faa2051eaabe',1,'ble_gap_evt_t::timeout()'],['../structble__gattc__evt__t.html#aca37c05800643ee41df04d1007c3e7e9',1,'ble_gattc_evt_t::timeout()'],['../structble__gatts__evt__t.html#a5a5ade5ed126bc40ac43a302b4c7ae44',1,'ble_gatts_evt_t::timeout()']]],
  ['timeout_5fus',['timeout_us',['../structnrf__radio__request__earliest__t.html#af56601d1b7ef92d49dbd1567bd1d39e0',1,'nrf_radio_request_earliest_t']]],
  ['tx',['tx',['../structble__l2cap__evt__t.html#a75c60941ac3f397d4a4bc6d21c01e351',1,'ble_l2cap_evt_t']]],
  ['tx_5fmps',['tx_mps',['../structble__l2cap__conn__cfg__t.html#a91b1265748833883666f7a202ed8c7ef',1,'ble_l2cap_conn_cfg_t::tx_mps()'],['../structble__l2cap__ch__tx__params__t.html#ad7a90c50a10a3f92f3ff7ce4e0e0f677',1,'ble_l2cap_ch_tx_params_t::tx_mps()']]],
  ['tx_5fmtu',['tx_mtu',['../structble__l2cap__ch__tx__params__t.html#a5a4b7a0a4a9a74ca0d72e263ddb856a2',1,'ble_l2cap_ch_tx_params_t']]],
  ['tx_5fparams',['tx_params',['../structble__l2cap__evt__ch__setup__request__t.html#ae33e1465ed45cd7134689b5606a37ffa',1,'ble_l2cap_evt_ch_setup_request_t::tx_params()'],['../structble__l2cap__evt__ch__setup__t.html#a4f5ee1768f933b96eaa78ec8c8da5640',1,'ble_l2cap_evt_ch_setup_t::tx_params()']]],
  ['tx_5fpayload_5flimited_5foctets',['tx_payload_limited_octets',['../structble__gap__data__length__limitation__t.html#a3467609bb7f3fb4c64f4bbb96990ed36',1,'ble_gap_data_length_limitation_t']]],
  ['tx_5fphy',['tx_phy',['../structble__gap__evt__phy__update__t.html#a9dd201a30a75fdd064e490614987dd00',1,'ble_gap_evt_phy_update_t']]],
  ['tx_5fphys',['tx_phys',['../structble__gap__phys__t.html#a965f80848d3b999ad1ebf06dad30c81c',1,'ble_gap_phys_t']]],
  ['tx_5fqueue_5fsize',['tx_queue_size',['../structble__l2cap__conn__cfg__t.html#a99be5e7196666c10883e4464b6756b85',1,'ble_l2cap_conn_cfg_t']]],
  ['tx_5frx_5ftime_5flimited_5fus',['tx_rx_time_limited_us',['../structble__gap__data__length__limitation__t.html#a7ffb03478453862a44ac65cf5fb92996',1,'ble_gap_data_length_limitation_t']]],
  ['type',['type',['../structble__evt__user__mem__request__t.html#ac0a51b3ce3131df1dcc57a440f5a816c',1,'ble_evt_user_mem_request_t::type()'],['../structble__evt__user__mem__release__t.html#a597b8f59bf2ab45d0d5ccf9329b50d13',1,'ble_evt_user_mem_release_t::type()'],['../structble__gap__adv__properties__t.html#a6a25cddf2c91bd01250b40a5dc6d144f',1,'ble_gap_adv_properties_t::type()'],['../structble__gattc__evt__hvx__t.html#ac1de2368e40b7e4c7eab1fcb770605f2',1,'ble_gattc_evt_hvx_t::type()'],['../structble__gatts__hvx__params__t.html#a2971c791821bea067f3bc2bbc35b9193',1,'ble_gatts_hvx_params_t::type()'],['../structble__gatts__rw__authorize__reply__params__t.html#a70efda4990b7c7e43bc7c0b1ae75c05e',1,'ble_gatts_rw_authorize_reply_params_t::type()'],['../structble__gatts__evt__rw__authorize__request__t.html#a8de6fad49332e37d86887303f2bc28a8',1,'ble_gatts_evt_rw_authorize_request_t::type()'],['../structble__uuid__t.html#ae233c47cdd5f63de456f413a158bb16f',1,'ble_uuid_t::type()']]]
];
