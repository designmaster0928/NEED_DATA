var searchData=
[
  ['_5f_5fsd_5fnvic_5fapp_5faccessible_5firq',['__sd_nvic_app_accessible_irq',['../group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s.html#gaeb38dcaa0c4ae6a5e588590bc27819d1',1,'nrf_nvic.h']]],
  ['_5f_5fsd_5fnvic_5firq_5fdisable',['__sd_nvic_irq_disable',['../group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s.html#ga6befa49138823f0ec6572400cad08bbe',1,'nrf_nvic.h']]],
  ['_5f_5fsd_5fnvic_5firq_5fenable',['__sd_nvic_irq_enable',['../group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s.html#gaad131d94ce361023b07ae1d3e3e56571',1,'nrf_nvic.h']]],
  ['_5f_5fsd_5fnvic_5fis_5fapp_5faccessible_5fpriority',['__sd_nvic_is_app_accessible_priority',['../group___n_r_f___n_v_i_c___i_n_t_e_r_n_a_l___f_u_n_c_t_i_o_n_s.html#ga6ca528e83cd0bce219f2f2cc1c1893a7',1,'nrf_nvic.h']]]
];
