var group___b_l_e___g_a_p___a_u_t_h___k_e_y___t_y_p_e_s =
[
    [ "BLE_GAP_AUTH_KEY_TYPE_NONE", "group___b_l_e___g_a_p___a_u_t_h___k_e_y___t_y_p_e_s.html#ga869af3b1376d25aec9ae236e5772d7f1", null ],
    [ "BLE_GAP_AUTH_KEY_TYPE_OOB", "group___b_l_e___g_a_p___a_u_t_h___k_e_y___t_y_p_e_s.html#gaf9f173da3e04e3c8054cbbeaa488c3d1", null ],
    [ "BLE_GAP_AUTH_KEY_TYPE_PASSKEY", "group___b_l_e___g_a_p___a_u_t_h___k_e_y___t_y_p_e_s.html#ga914a323fb165826d2995ef9d79b341e6", null ]
];