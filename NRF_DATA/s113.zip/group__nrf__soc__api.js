var group__nrf__soc__api =
[
    [ "Defines", "group___n_r_f___s_o_c___d_e_f_i_n_e_s.html", "group___n_r_f___s_o_c___d_e_f_i_n_e_s" ],
    [ "Enumerations", "group___n_r_f___s_o_c___e_n_u_m_s.html", "group___n_r_f___s_o_c___e_n_u_m_s" ],
    [ "Functions", "group___n_r_f___s_o_c___f_u_n_c_t_i_o_n_s.html", "group___n_r_f___s_o_c___f_u_n_c_t_i_o_n_s" ],
    [ "SoC Library Error Codes", "group__nrf__soc__error.html", "group__nrf__soc__error" ],
    [ "Structures", "group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s.html", "group___n_r_f___s_o_c___s_t_r_u_c_t_u_r_e_s" ]
];