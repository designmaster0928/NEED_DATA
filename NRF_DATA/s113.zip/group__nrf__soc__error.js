var group__nrf__soc__error =
[
    [ "NRF_ERROR_SOC_MUTEX_ALREADY_TAKEN", "group__nrf__soc__error.html#ga08505c75d1cc68c75b2b529f0acfd9e7", null ],
    [ "NRF_ERROR_SOC_NVIC_INTERRUPT_NOT_AVAILABLE", "group__nrf__soc__error.html#ga4660c0925c76d795707fe77c41aac89b", null ],
    [ "NRF_ERROR_SOC_NVIC_INTERRUPT_PRIORITY_NOT_ALLOWED", "group__nrf__soc__error.html#gae2b0d8c5f538bbcab43d82f04412463d", null ],
    [ "NRF_ERROR_SOC_NVIC_SHOULD_NOT_RETURN", "group__nrf__soc__error.html#gadb16c01a8206067f0831b6a7d9cd41c1", null ],
    [ "NRF_ERROR_SOC_POWER_MODE_UNKNOWN", "group__nrf__soc__error.html#gaba78285df6e85daaa153bce5890364df", null ],
    [ "NRF_ERROR_SOC_POWER_OFF_SHOULD_NOT_RETURN", "group__nrf__soc__error.html#ga57d53aa15592b0bfacc98d99c4dda07b", null ],
    [ "NRF_ERROR_SOC_POWER_POF_THRESHOLD_UNKNOWN", "group__nrf__soc__error.html#ga4c66885f407427c323d19539f6e59e0d", null ],
    [ "NRF_ERROR_SOC_PPI_INVALID_CHANNEL", "group__nrf__soc__error.html#ga563fa0ece398152e3256b09da51fda7f", null ],
    [ "NRF_ERROR_SOC_PPI_INVALID_GROUP", "group__nrf__soc__error.html#ga78bb614cb480357c7cb191ec8efba5fb", null ],
    [ "NRF_ERROR_SOC_RAND_NOT_ENOUGH_VALUES", "group__nrf__soc__error.html#gabb7186c1f08507eecc60e99b569ee2f7", null ]
];