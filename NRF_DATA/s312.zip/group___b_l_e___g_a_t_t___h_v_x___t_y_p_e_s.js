var group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s =
[
    [ "BLE_GATT_HVX_INDICATION", "group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s.html#ga47f3222bcefb5eb4aed9a1dc7c796b1f", null ],
    [ "BLE_GATT_HVX_INVALID", "group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s.html#gae454efaf8b3f8c6871dca5d2db5ac724", null ],
    [ "BLE_GATT_HVX_NOTIFICATION", "group___b_l_e___g_a_t_t___h_v_x___t_y_p_e_s.html#gad5784996b45947f6d7f0cb81c9a4c9ed", null ]
];