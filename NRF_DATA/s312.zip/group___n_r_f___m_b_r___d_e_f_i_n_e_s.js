var group___n_r_f___m_b_r___d_e_f_i_n_e_s =
[
    [ "MBR_BOOTLOADER_ADDR", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga21a55e684b30e9dabbf86859cd788b1a", null ],
    [ "MBR_PAGE_SIZE_IN_WORDS", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga68577573530e7ffa14441fd585913121", null ],
    [ "MBR_PARAM_PAGE_ADDR", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga484c4af853d1bc7af068b159746ef1ad", null ],
    [ "MBR_SIZE", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga2f71568a2395dc0783c1e6142ef71d5b", null ],
    [ "MBR_SVC_BASE", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga66eb811a4b26c25940778c3f0ca1dc77", null ],
    [ "MBR_UICR_BOOTLOADER_ADDR", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga3a26bf76b9300a81216bb32a81b2a10d", null ],
    [ "MBR_UICR_PARAM_PAGE_ADDR", "group___n_r_f___m_b_r___d_e_f_i_n_e_s.html#ga6151aedbeeb875e6b82af72c0acd2ddf", null ]
];