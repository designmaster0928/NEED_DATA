var group___b_l_e___g_a_p___p_e_r_i_p_h___l_e_g_a_c_y___m_s_c =
[
    [ "Bonding: Just Works", "group___b_l_e___g_a_p___p_e_r_i_p_h___b_o_n_d_i_n_g___j_w___m_s_c.html", null ],
    [ "Bonding: Passkey Entry with static passkey", "group___b_l_e___g_a_p___p_e_r_i_p_h___b_o_n_d_i_n_g___s_t_a_t_i_c___p_k___m_s_c.html", null ],
    [ "Bonding: Passkey Entry, Peripheral displays", "group___b_l_e___g_a_p___p_e_r_i_p_h___b_o_n_d_i_n_g___p_k___p_e_r_i_p_h___m_s_c.html", null ],
    [ "Bonding: Passkey Entry, User Inputs on Peripheral or OOB", "group___b_l_e___g_a_p___p_e_r_i_p_h___b_o_n_d_i_n_g___p_k___c_e_n_t_r_a_l___o_o_b___m_s_c.html", null ],
    [ "Pairing failure: Confirm failed", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___c_o_n_f_i_r_m___f_a_i_l___m_s_c.html", null ],
    [ "Pairing: Just Works", "group___b_l_e___g_a_p___p_e_r_i_p_h___p_a_i_r_i_n_g___j_w___m_s_c.html", null ]
];