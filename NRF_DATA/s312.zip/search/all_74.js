var searchData=
[
  ['time_20base_20defines',['Time Base Defines',['../group___a_n_t___t_i_m_e___b_a_s_e.html',1,'']]],
  ['thread_20mode_20event_20retrieval',['Thread Mode Event Retrieval',['../group___b_l_e___c_o_m_m_o_n___t_h_r_e_a_d___e_v_t___m_s_c.html',1,'']]],
  ['types_20of_20uuid',['Types of UUID',['../group___b_l_e___u_u_i_d___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___m_b_r___t_y_p_e_s.html',1,'']]],
  ['types',['Types',['../group___n_r_f___s_d_m___t_y_p_e_s.html',1,'']]],
  ['timeout',['timeout',['../structble__gap__evt__t.html#ae8165f09cf3e00673a15faa2051eaabe',1,'ble_gap_evt_t::timeout()'],['../structble__gattc__evt__t.html#aca37c05800643ee41df04d1007c3e7e9',1,'ble_gattc_evt_t::timeout()'],['../structble__gatts__evt__t.html#a5a5ade5ed126bc40ac43a302b4c7ae44',1,'ble_gatts_evt_t::timeout()']]],
  ['timeout_5fus',['timeout_us',['../structnrf__radio__request__earliest__t.html#af56601d1b7ef92d49dbd1567bd1d39e0',1,'nrf_radio_request_earliest_t']]],
  ['transfer_5fbusy',['TRANSFER_BUSY',['../group__ant__parameters.html#gaf7422213118cdccf3e2391dc834e6ee6',1,'ant_parameters.h']]],
  ['transfer_5fin_5ferror',['TRANSFER_IN_ERROR',['../group__ant__parameters.html#gabb130dbf5380067214dfb9652c229b66',1,'ant_parameters.h']]],
  ['transfer_5fin_5fprogress',['TRANSFER_IN_PROGRESS',['../group__ant__parameters.html#gae295711c3c6f5a87788c7dad6ef83da1',1,'ant_parameters.h']]],
  ['transfer_5fsequence_5fnumber_5ferror',['TRANSFER_SEQUENCE_NUMBER_ERROR',['../group__ant__parameters.html#gae578b7c324f2d9addad818e1b6df7d7e',1,'ant_parameters.h']]],
  ['tx_5fphy',['tx_phy',['../structble__gap__evt__phy__update__t.html#a9dd201a30a75fdd064e490614987dd00',1,'ble_gap_evt_phy_update_t']]],
  ['tx_5fphys',['tx_phys',['../structble__gap__phys__t.html#a965f80848d3b999ad1ebf06dad30c81c',1,'ble_gap_phys_t']]],
  ['type',['type',['../structble__evt__user__mem__request__t.html#ac0a51b3ce3131df1dcc57a440f5a816c',1,'ble_evt_user_mem_request_t::type()'],['../structble__evt__user__mem__release__t.html#a597b8f59bf2ab45d0d5ccf9329b50d13',1,'ble_evt_user_mem_release_t::type()'],['../structble__gap__adv__properties__t.html#a6a25cddf2c91bd01250b40a5dc6d144f',1,'ble_gap_adv_properties_t::type()'],['../structble__gattc__evt__hvx__t.html#ac1de2368e40b7e4c7eab1fcb770605f2',1,'ble_gattc_evt_hvx_t::type()'],['../structble__gatts__hvx__params__t.html#a2971c791821bea067f3bc2bbc35b9193',1,'ble_gatts_hvx_params_t::type()'],['../structble__gatts__rw__authorize__reply__params__t.html#a70efda4990b7c7e43bc7c0b1ae75c05e',1,'ble_gatts_rw_authorize_reply_params_t::type()'],['../structble__gatts__evt__rw__authorize__request__t.html#a8de6fad49332e37d86887303f2bc28a8',1,'ble_gatts_evt_rw_authorize_request_t::type()'],['../structble__uuid__t.html#ae233c47cdd5f63de456f413a158bb16f',1,'ble_uuid_t::type()']]]
];
