var group___n_r_f___m_b_r___e_n_u_m_s =
[
    [ "NRF_MBR_COMMANDS", "group___n_r_f___m_b_r___e_n_u_m_s.html#gad416fbc71855eb8e1533a812164b85a7", [
      [ "SD_MBR_COMMAND_COPY_BL", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a56ab45130d67e73165ac12b66e8db127", null ],
      [ "SD_MBR_COMMAND_COPY_SD", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a425aceb6eaa893f49011dada2c1dd812", null ],
      [ "SD_MBR_COMMAND_INIT_SD", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a1fcb02bcda46da19c7baff2b92c71fe5", null ],
      [ "SD_MBR_COMMAND_COMPARE", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a5199987af2f952e4af19b1a30f02dbac", null ],
      [ "SD_MBR_COMMAND_VECTOR_TABLE_BASE_SET", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a5317127853f0ad74b2705ae5675b2b9a", null ],
      [ "SD_MBR_COMMAND_IRQ_FORWARD_ADDRESS_SET", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggad416fbc71855eb8e1533a812164b85a7a8cc3c3258c8851d7a2eead33f2451a32", null ]
    ] ],
    [ "NRF_MBR_SVCS", "group___n_r_f___m_b_r___e_n_u_m_s.html#gaebb8642cfb30caf7eea66524b13c58be", [
      [ "SD_MBR_COMMAND", "group___n_r_f___m_b_r___e_n_u_m_s.html#ggaebb8642cfb30caf7eea66524b13c58bea4306e887e1d767e0d8161213b7fe1357", null ]
    ] ]
];