var group___b_l_e___g_a_p___a_d_v___t_y_p_e_s =
[
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_NONSCANNABLE_DIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga8042312ca8468c0763ede30c1cf921c4", null ],
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_NONSCANNABLE_DIRECTED_HIGH_DUTY_CYCLE", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gafae9f67ea85137f6a630a650a6af7476", null ],
    [ "BLE_GAP_ADV_TYPE_CONNECTABLE_SCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gae453a22d3a46ef932ff2808afb84c958", null ],
    [ "BLE_GAP_ADV_TYPE_NONCONNECTABLE_NONSCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#gae5a70eec1facf6ff0baae3be3401204d", null ],
    [ "BLE_GAP_ADV_TYPE_NONCONNECTABLE_SCANNABLE_UNDIRECTED", "group___b_l_e___g_a_p___a_d_v___t_y_p_e_s.html#ga0cf4be8eca3c4bcaf60a244a3b921d54", null ]
];