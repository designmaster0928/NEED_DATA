var group__ant__error =
[
    [ "NRF_ANT_ERROR_CHANNEL_ID_NOT_SET", "group__ant__error.html#gab6a1f394512daf7b90e0e92ff6a8f2e1", null ],
    [ "NRF_ANT_ERROR_CHANNEL_IN_WRONG_STATE", "group__ant__error.html#ga5b0ab7ccef5e3ceba284982ec2ed09e7", null ],
    [ "NRF_ANT_ERROR_CHANNEL_NOT_OPENED", "group__ant__error.html#ga709a9d777285a2bbdade6b4d570ceb7f", null ],
    [ "NRF_ANT_ERROR_CLOSE_ALL_CHANNELS", "group__ant__error.html#ga9a743d59e33a719f366bc0c277e44b17", null ],
    [ "NRF_ANT_ERROR_INVALID_LIST_ID", "group__ant__error.html#gaf3759c68825f7b06613f82bccb411e60", null ],
    [ "NRF_ANT_ERROR_INVALID_MESSAGE", "group__ant__error.html#ga388c39a908acf6dd0474bea3a0f1b53b", null ],
    [ "NRF_ANT_ERROR_INVALID_NETWORK_NUMBER", "group__ant__error.html#ga780c667bc071f477db392dc07a2e444d", null ],
    [ "NRF_ANT_ERROR_INVALID_PARAMETER_PROVIDED", "group__ant__error.html#gad81d92c712fff6617de08803133e3ee8", null ],
    [ "NRF_ANT_ERROR_INVALID_SCAN_TX_CHANNEL", "group__ant__error.html#gae1813878b3515eda4c731cf8c5bf2f07", null ],
    [ "NRF_ANT_ERROR_MESSAGE_SIZE_EXCEEDS_LIMIT", "group__ant__error.html#gab029e803fd76c402e68652b8a13ea3b9", null ],
    [ "NRF_ANT_ERROR_OFFSET", "group__ant__error.html#ga50be0dcedcb7cfb4cefb7c8d62f36e68", null ],
    [ "NRF_ANT_ERROR_TRANSFER_BUSY", "group__ant__error.html#ga808b01467335e6e845fae4e483fff632", null ],
    [ "NRF_ANT_ERROR_TRANSFER_IN_ERROR", "group__ant__error.html#gae324d3154b99f1d6247501e247882841", null ],
    [ "NRF_ANT_ERROR_TRANSFER_IN_PROGRESS", "group__ant__error.html#ga460c07f11f1a95c756479dda71736195", null ],
    [ "NRF_ANT_ERROR_TRANSFER_SEQUENCE_NUMBER_ERROR", "group__ant__error.html#ga95a1031bc77561ab4199f6f634e51d2e", null ]
];