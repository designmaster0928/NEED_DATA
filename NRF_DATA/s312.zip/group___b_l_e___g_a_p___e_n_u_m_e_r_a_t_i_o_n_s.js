var group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s =
[
    [ "BLE_GAP_CFGS", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gaafd9753972f9a51c36cea924b0dab209", [
      [ "BLE_GAP_CFG_ROLE_COUNT", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggaafd9753972f9a51c36cea924b0dab209a9927856820804bf6554804450a719b13", null ],
      [ "BLE_GAP_CFG_DEVICE_NAME", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggaafd9753972f9a51c36cea924b0dab209a52046d7c0e5daef6b4af4859392a4b4c", null ]
    ] ],
    [ "BLE_GAP_EVTS", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gada486dd3c0cce897b23a887bed284fef", [
      [ "BLE_GAP_EVT_CONNECTED", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefaa0b4789724d202a13a5e7eab85c52957", null ],
      [ "BLE_GAP_EVT_DISCONNECTED", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa057001bbd6ea9e615f19ef93cc0831ee", null ],
      [ "BLE_GAP_EVT_CONN_PARAM_UPDATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa9117fcf7efad580886dfad72e5d7cce7", null ],
      [ "BLE_GAP_EVT_SEC_PARAMS_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa6c5eefbcfabbc1ce4a8bcbf550c285ae", null ],
      [ "BLE_GAP_EVT_SEC_INFO_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefaf1c60079f92820cb933ebdb66d2d8d7d", null ],
      [ "BLE_GAP_EVT_PASSKEY_DISPLAY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefaedc549f5a6853a542bf93ff5d155292a", null ],
      [ "BLE_GAP_EVT_KEY_PRESSED", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefafefce9141f6f33ea0ad3c1d159ab29c3", null ],
      [ "BLE_GAP_EVT_AUTH_KEY_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa64d5d52e3ca8d8957bce011ad43d0f67", null ],
      [ "BLE_GAP_EVT_LESC_DHKEY_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa353a9317dd2d546b68cd872bc610db7f", null ],
      [ "BLE_GAP_EVT_AUTH_STATUS", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa8958220152f7547da3b250b4f724877c", null ],
      [ "BLE_GAP_EVT_CONN_SEC_UPDATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa361bcc6098a88825333464335f6d22cc", null ],
      [ "BLE_GAP_EVT_TIMEOUT", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa57e5d1061d9b3d1500fb3556a3fb8847", null ],
      [ "BLE_GAP_EVT_RSSI_CHANGED", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa4d1c7d552ad87b09c53a4d4352fc91e6", null ],
      [ "BLE_GAP_EVT_SEC_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa902037e30402a6dcacc8ed07830948b3", null ],
      [ "BLE_GAP_EVT_SCAN_REQ_REPORT", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefad439a364d0294dd6d1937534bdf15e88", null ],
      [ "BLE_GAP_EVT_PHY_UPDATE_REQUEST", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa7c935916683ca67585f2239d8d13e8b4", null ],
      [ "BLE_GAP_EVT_PHY_UPDATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefaba64e43fa8bdb44f81173c704a35472f", null ],
      [ "BLE_GAP_EVT_ADV_SET_TERMINATED", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggada486dd3c0cce897b23a887bed284fefa35cbfe86ff4922dafaa335c83aee0b40", null ]
    ] ],
    [ "BLE_GAP_OPTS", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ga2da79b1e293414621d79814490a8598e", [
      [ "BLE_GAP_OPT_CH_MAP", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga2da79b1e293414621d79814490a8598ea81b10bb7db3428519b0d18281bafafd4", null ],
      [ "BLE_GAP_OPT_LOCAL_CONN_LATENCY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga2da79b1e293414621d79814490a8598eaf2ca06bf556f7283c9ed43c1310d492b", null ],
      [ "BLE_GAP_OPT_PASSKEY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga2da79b1e293414621d79814490a8598ea9b99a25c5a7668e610256c8c5bdffbf7", null ],
      [ "BLE_GAP_OPT_AUTH_PAYLOAD_TIMEOUT", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga2da79b1e293414621d79814490a8598ea603ad90cb33bf1ba8a599b7315e5fede", null ],
      [ "BLE_GAP_OPT_SLAVE_LATENCY_DISABLE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gga2da79b1e293414621d79814490a8598ea02ee8b81bb52c16936a7bc69f2a16db4", null ]
    ] ],
    [ "BLE_GAP_SVCS", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gae39030093ebca17966d1896533d1b556", [
      [ "SD_BLE_GAP_ADDR_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556afadec0e0e78bef904bf8e50077974b94", null ],
      [ "SD_BLE_GAP_ADDR_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a4ca4082b264c0813358fa63cb3b71032", null ],
      [ "SD_BLE_GAP_WHITELIST_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a8fcc343181e81402d24f94113278e934", null ],
      [ "SD_BLE_GAP_DEVICE_IDENTITIES_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556abd1ac91bddc412f4b5de7b0ab2bfc58f", null ],
      [ "SD_BLE_GAP_PRIVACY_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a008fa60f8a8c5678403b16de74a77bf7", null ],
      [ "SD_BLE_GAP_PRIVACY_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a46ae1392907e761f06949004365bd539", null ],
      [ "SD_BLE_GAP_ADV_SET_CONFIGURE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a00c09f89438df8a64b3a262410d66a6d", null ],
      [ "SD_BLE_GAP_ADV_START", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a31d02ec5d7f14428792730f606886168", null ],
      [ "SD_BLE_GAP_ADV_STOP", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a5792b074a65ed1305cadd63fe9e5b7e4", null ],
      [ "SD_BLE_GAP_CONN_PARAM_UPDATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a715b80d35521667b95cdefaedfad2250", null ],
      [ "SD_BLE_GAP_DISCONNECT", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a58d418671daee4179d9a2cce944de1f9", null ],
      [ "SD_BLE_GAP_TX_POWER_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556aea3abe6cc7f23434168a1a8342759ba1", null ],
      [ "SD_BLE_GAP_APPEARANCE_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a67da694c3c079bb63f1291f43b00d034", null ],
      [ "SD_BLE_GAP_APPEARANCE_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a65d36173050ff0637c3f363fa4db1cf5", null ],
      [ "SD_BLE_GAP_PPCP_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a39fbca8e470c0492b0763d8712da4135", null ],
      [ "SD_BLE_GAP_PPCP_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556abafe4d2635bedea1c13dbe457cbbe83c", null ],
      [ "SD_BLE_GAP_DEVICE_NAME_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556ab27a6c176fc8dcac3878e50c2057c076", null ],
      [ "SD_BLE_GAP_DEVICE_NAME_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a6b1fca2f42bbcd96dcabda1073506210", null ],
      [ "SD_BLE_GAP_AUTHENTICATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a7591f1c7995425f44728932eb65c926a", null ],
      [ "SD_BLE_GAP_SEC_PARAMS_REPLY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556aae420a19a548dc8ac7de3805c8814cc7", null ],
      [ "SD_BLE_GAP_AUTH_KEY_REPLY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556abbc609532fdc8f42ebdfe22e7b3a89d2", null ],
      [ "SD_BLE_GAP_LESC_DHKEY_REPLY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a40a5126303d9c406fc5b6975e829a070", null ],
      [ "SD_BLE_GAP_KEYPRESS_NOTIFY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a2f22e4be4b10bf010f0e5328f7bd0c6e", null ],
      [ "SD_BLE_GAP_LESC_OOB_DATA_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a35bc97631b3f22b93b8f16b5ff63b2fc", null ],
      [ "SD_BLE_GAP_LESC_OOB_DATA_SET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556ab64502c9b2e27c9ca66bb330326ec8ea", null ],
      [ "SD_BLE_GAP_SEC_INFO_REPLY", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556aac4b9e9bf9c32143af4b5d1d8c2691bb", null ],
      [ "SD_BLE_GAP_CONN_SEC_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556ab4aaa9073082593a31ad72df4abe7350", null ],
      [ "SD_BLE_GAP_RSSI_START", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a0f1dd68aa7e6b2ccfea62141f41c462b", null ],
      [ "SD_BLE_GAP_RSSI_STOP", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a30d87d0955da5cbd2937a8d7ef784d93", null ],
      [ "SD_BLE_GAP_RSSI_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a7d508062d760f0f7a0b5661b7c6d3650", null ],
      [ "SD_BLE_GAP_PHY_UPDATE", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a74ddbe8d60728fc31f8f79d55a533f3e", null ],
      [ "SD_BLE_GAP_ADV_ADDR_GET", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggae39030093ebca17966d1896533d1b556a7e0001e2ede9426e8df8f54467f08efa", null ]
    ] ],
    [ "BLE_GAP_TX_POWER_ROLES", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#gad37de0f7735bbcfb50401ebc3fd15b16", [
      [ "BLE_GAP_TX_POWER_ROLE_ADV", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggad37de0f7735bbcfb50401ebc3fd15b16a316b26bf3dd9996431bc75b025084a92", null ],
      [ "BLE_GAP_TX_POWER_ROLE_CONN", "group___b_l_e___g_a_p___e_n_u_m_e_r_a_t_i_o_n_s.html#ggad37de0f7735bbcfb50401ebc3fd15b16a3a9c5d4d8d25be577ee6fd929eb6537b", null ]
    ] ]
];