var group___n_r_f___s_d_m___e_n_u_m_s =
[
    [ "NRF_SD_SVCS", "group___n_r_f___s_d_m___e_n_u_m_s.html#ga4528cbf3f1a34d4712822ac456b1b305", [
      [ "SD_SOFTDEVICE_ENABLE", "group___n_r_f___s_d_m___e_n_u_m_s.html#gga4528cbf3f1a34d4712822ac456b1b305ab692ec521a2f791184f7a4644897f781", null ],
      [ "SD_SOFTDEVICE_DISABLE", "group___n_r_f___s_d_m___e_n_u_m_s.html#gga4528cbf3f1a34d4712822ac456b1b305ab48ef4bb34f9d37c0a7005f7b7d13692", null ],
      [ "SD_SOFTDEVICE_IS_ENABLED", "group___n_r_f___s_d_m___e_n_u_m_s.html#gga4528cbf3f1a34d4712822ac456b1b305a6f89d282c869fd898e2c75141ac2bc5f", null ],
      [ "SD_SOFTDEVICE_VECTOR_TABLE_BASE_SET", "group___n_r_f___s_d_m___e_n_u_m_s.html#gga4528cbf3f1a34d4712822ac456b1b305a5e19adec24f31566eb74ff8222c7ab06", null ],
      [ "SVC_SDM_LAST", "group___n_r_f___s_d_m___e_n_u_m_s.html#gga4528cbf3f1a34d4712822ac456b1b305a11216cbdd9009464a16286385173bb5a", null ]
    ] ]
];