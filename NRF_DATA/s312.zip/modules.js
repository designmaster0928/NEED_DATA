var modules =
[
    [ "ANT STACK", "group__stack__ant__module.html", "group__stack__ant__module" ],
    [ "BLE SoftDevice Common", "group___b_l_e___c_o_m_m_o_n.html", "group___b_l_e___c_o_m_m_o_n" ],
    [ "Generic Access Profile (GAP)", "group___b_l_e___g_a_p.html", "group___b_l_e___g_a_p" ],
    [ "Generic Attribute Profile (GATT) Client", "group___b_l_e___g_a_t_t_c.html", "group___b_l_e___g_a_t_t_c" ],
    [ "Generic Attribute Profile (GATT) Common", "group___b_l_e___g_a_t_t.html", "group___b_l_e___g_a_t_t" ],
    [ "Generic Attribute Profile (GATT) Server", "group___b_l_e___g_a_t_t_s.html", "group___b_l_e___g_a_t_t_s" ],
    [ "Master Boot Record API", "group__nrf__mbr__api.html", "group__nrf__mbr__api" ],
    [ "SoC Library API", "group__nrf__soc__api.html", "group__nrf__soc__api" ],
    [ "SoftDevice Manager API", "group__nrf__sdm__api.html", "group__nrf__sdm__api" ],
    [ "SoftDevice NVIC API", "group__nrf__nvic__api.html", "group__nrf__nvic__api" ]
];