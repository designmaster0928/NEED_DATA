var group___n_r_f___m_b_r___t_y_p_e_s =
[
    [ "sd_mbr_command_copy_sd_t", "structsd__mbr__command__copy__sd__t.html", [
      [ "dst", "structsd__mbr__command__copy__sd__t.html#ae8afbb5ddb539bf7d5aa63102313210a", null ],
      [ "len", "structsd__mbr__command__copy__sd__t.html#a36ada23cb97fb5ec6873d262689cbfdb", null ],
      [ "src", "structsd__mbr__command__copy__sd__t.html#a7fab268f5a8db5b0ccc3a4b85d47c0b7", null ]
    ] ],
    [ "sd_mbr_command_compare_t", "structsd__mbr__command__compare__t.html", [
      [ "len", "structsd__mbr__command__compare__t.html#ae7fb48410ecb00dec1dca60d45cbc606", null ],
      [ "ptr1", "structsd__mbr__command__compare__t.html#a03e88994f8127e877c2fd08800e64768", null ],
      [ "ptr2", "structsd__mbr__command__compare__t.html#a3f670b76c31a7b6badf0bfadd1dc08b0", null ]
    ] ],
    [ "sd_mbr_command_copy_bl_t", "structsd__mbr__command__copy__bl__t.html", [
      [ "bl_len", "structsd__mbr__command__copy__bl__t.html#a197755f22bcc92adc7c8288f48bd9ef8", null ],
      [ "bl_src", "structsd__mbr__command__copy__bl__t.html#a504481143eb43e52488288d7de70a6f1", null ]
    ] ],
    [ "sd_mbr_command_vector_table_base_set_t", "structsd__mbr__command__vector__table__base__set__t.html", [
      [ "address", "structsd__mbr__command__vector__table__base__set__t.html#af6bd4c73c91f2c8999d6f7ebe5780325", null ]
    ] ],
    [ "sd_mbr_command_irq_forward_address_set_t", "structsd__mbr__command__irq__forward__address__set__t.html", [
      [ "address", "structsd__mbr__command__irq__forward__address__set__t.html#a5dd88d8bfeccdd4b819274ec3b8c4cea", null ]
    ] ],
    [ "sd_mbr_command_t", "structsd__mbr__command__t.html", [
      [ "base_set", "structsd__mbr__command__t.html#aa16e258dae73733a2f1acc82d2aff10f", null ],
      [ "command", "structsd__mbr__command__t.html#ace7fb69d83a5ef3dc0a35dbdb58cb78a", null ],
      [ "compare", "structsd__mbr__command__t.html#a45bdd29ee5d7bc0a20a3d5c06dca7de6", null ],
      [ "copy_bl", "structsd__mbr__command__t.html#a0ae5a869c2d4e2ac60daa53b66d2da38", null ],
      [ "copy_sd", "structsd__mbr__command__t.html#a7efb4f5913fbaef52ae323305cf6e98c", null ],
      [ "irq_forward_address_set", "structsd__mbr__command__t.html#a0cb636ad46f4676afb8d2c7f73df7d1b", null ],
      [ "params", "structsd__mbr__command__t.html#a6a1f1ea37b19296584ed599a63830214", null ]
    ] ]
];