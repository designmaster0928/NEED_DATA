
#include "Display.h"
#include "Config.h"
#include "M74HC595.h"
#include "TLC5917.h"

void OpenDisplay(){
    
    //Anode Common bits init
    SEG1_TRIS   = DIGITAL_OUTPUT;
    SEG2_TRIS   = DIGITAL_OUTPUT;
    SEG3_TRIS   = DIGITAL_OUTPUT;
    SEG4_TRIS   = DIGITAL_OUTPUT;
    SEG5_TRIS   = DIGITAL_OUTPUT;
    SEG6_TRIS   = DIGITAL_OUTPUT;
    COLLON_TRIS = DIGITAL_OUTPUT;
    LED_TRIS    = DIGITAL_OUTPUT;
    
    M74HC595Init();
    
    for( unsigned char i = 0; i < NUM_OF_7SEG_COMMON + NUM_OF_LEDS_COMMON; i++ ){
        blink_pos[ i ] = FALSE;
        display_datas[ i ] = 0xff;
    }
    //Display Counter init
    display_cnt = 0; blink_cnt = 0; blink_enable_flg = 0;
}

void ScanDisplay(){
    
    SEG1 = SEG2 = SEG3 = SEG4 = SEG5 = SEG6 = COLLON = LED = 0; //LED = 
    display_cnt ++;
    if( blink_pos[ display_cnt - 1 ] && blink_cnt < DISP_BLINK_TIME / 2 && blink_enable_flg ) return;
    switch( display_cnt ){
        case 1: M74HC595Write(display_datas[0]); SEG1 = 1; break;
        case 2: M74HC595Write(display_datas[1]); SEG2 = 1; break;
        case 3: M74HC595Write(display_datas[2]); SEG3 = 1; break;
        case 4: M74HC595Write(display_datas[3]); SEG4 = 1; break;
        case 5: M74HC595Write(display_datas[4]); SEG5 = 1; break;
        case 6: M74HC595Write(display_datas[5]); SEG6 = 1; break;
        case 7: if( blink_pos[ 6 ] ) M74HC595Write( 0x00 ); else M74HC595Write( 0xff ); COLLON = 1; break;
        case 8: M74HC595Write(display_datas[7]); LED  = 1; display_cnt = 0; blink_cnt ++; break;
    }
    if( blink_cnt == DISP_BLINK_TIME ) blink_cnt = 0;
}

void UpdateDisplay(  unsigned char* update_datas, unsigned char start_position, unsigned char end_position  ){
    
    for( unsigned char i = start_position - 1; i < end_position; i ++ ) {
        display_datas[ i ] = MarkDisplay( update_datas[ i ] ); 
    }
}

unsigned char MarkDisplay( unsigned char mark ){
    
    //In case common anode reverse
    switch( mark ){
        case 0:   return 0xc0; case 1:   return 0xf9; case 2:   return 0xa4; case 3:   return 0xb0; case 4:   return 0x99;
        case 5:   return 0x92; case 6:   return 0x82; case 7:   return 0xf8; case 8:   return 0x80; case 9:   return 0x90;
        case 'A': return 0x55; case 'a': return 0x05; case 'B': return 0x01; case 'b': return 0xc1;
        case 'C': return 0x63; case 'c': return 0xe5; case 'D': return 0x03; case 'd': return 0x85;
        case 'E': return 0x61; case 'e': return 0x21; case 'F': return 0x71; case 'G': return 0x43; case 'g': return 0x09;
        case 'H': return 0x91; case 'h': return 0xd1; case 'I': return 0x9f; case 'J': return 0x8f; case 'L': return 0xe3;
        case 'n': return 0xd5; case 'O': return 0x03; case 'o': return 0xc5; case 'P': return 0x31; case 'q': return 0x19;
        case 'r': return 0xf5; case 'S': return 0x49; case 't': return 0xe1; case 'U': return 0x83; case 'y': return 0x89;
    }
    
    //In case common catode reverse
//    switch( mark ){
//        case 0: return 0xfc; case 1: return 0x60; case 2: return 0xda; case 3: return 0xf2; case 4: return 0x66;
//        case 5: return 0xb6; case 6: return 0xbe; case 7: return 0xe0; case 8: return 0xfe; case 9: return 0xf6;
//    }
    
//    In case common catode 
//    switch( mark ){
//        case 0: return 0x3f; case 1: return 0x06; case 2: return 0x5b; case 3: return 0x4f; case 4: return 0x66;
//        case 5: return 0x6d; case 6: return 0x7d; case 7: return 0x07; case 8: return 0x7f; case 9: return 0x6f;
//    }
    
}

void BlinkDisplay( unsigned char start_pos, unsigned char end_pos ){
    
    for( unsigned char i = start_pos; i < end_pos + 1; i ++ ){
        blink_pos[ i ] = TRUE; 
    }
}

void BlinkDisable() {
    for( unsigned char i = 0; i < NUM_OF_7SEG_COMMON; i ++ ){
        blink_pos[ i ] = FALSE; 
    }
}