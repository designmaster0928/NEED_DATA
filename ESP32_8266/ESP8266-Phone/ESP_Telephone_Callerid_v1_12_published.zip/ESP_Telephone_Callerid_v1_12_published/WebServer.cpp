#include "WebServer.h"
#include "Config.h"
#include "Globals.h"


ESP8266WebServer server (80);
IPAddress apIp ;

bool apMode = false ;
String  httpUpdateResponse ;




// ==============
// handleRoot()
// ==============

void  ICACHE_FLASH_ATTR  handleRoot() {
  /*
       web server --> browser client
  */

  String s = MAIN_page;
  s.replace( "$@updateResponse@$" , httpUpdateResponse ) ;
  s.replace( "$@config_ssid@$" , config.ssid ) ;
  s.replace( "$@config_psk@$" , String("1234F6") ) ;  //special marker (hope no one uses this as a new password)
  s.replace( "$@config_remoteHost@$" , config.remoteHost ) ;
  s.replace( "$@config_ruleIntlFrom@$" , config.ruleIntlFrom ) ;
  s.replace( "$@config_ruleIntlTo@$" , config.ruleIntlTo ) ;
  s.replace( "$@config_ruleLocalFrom@$" , config.ruleLocalFrom ) ;
  s.replace( "$@config_ruleLocalTo@$" , config.ruleLocalTo ) ;
  s.replace( "$@config_phpRetrievePath@$" , config.phpRetrievePath ) ;
  s.replace( "$@config_phpStorePath@$" , config.phpStorePath ) ;
  s.replace( "$@config_spamLevel@$" , String( config.spamLevel ) ) ;

  swSerial.println(F("in handleRoot")) ;
  server.send(200, "text/html", s );
  httpUpdateResponse = "";
}



// ==============
// handleForm()
// ==============

void  ICACHE_FLASH_ATTR handleForm() {
  /*
       Browser Client --> Web Server
  */


  swSerial.println(F("in handleForm") ) ;

  // validate - main done in js
  // simply check here if psk is blank (it should never be) to see if we get an empty post

  if (   server.arg("config_psk" ).length() == 0  ) {
    httpUpdateResponse = "Error - please retry";
  }
  else {
    server.arg("config_ssid" ).toCharArray( config.ssid, sizeof( config.ssid ) ) ;
    if ( ! server.arg("config_psk" ).equals( String("1234F6") ) ) {  //special marker
      server.arg("config_psk" ).toCharArray( config.psk, sizeof( config.psk ) ) ;
    }
    server.arg("config_remoteHost" ).toCharArray( config.remoteHost, sizeof( config.remoteHost ) ) ;
    server.arg("config_ruleIntlFrom" ).toCharArray( config.ruleIntlFrom, sizeof( config.ruleIntlFrom ) ) ;
    server.arg("config_ruleIntlTo" ).toCharArray( config.ruleIntlTo, sizeof( config.ruleIntlTo ) ) ;
    server.arg("config_ruleLocalFrom" ).toCharArray( config.ruleLocalFrom, sizeof( config.ruleLocalFrom ) ) ;
    server.arg("config_ruleLocalTo" ).toCharArray( config.ruleLocalTo, sizeof( config.ruleLocalTo ) ) ;
    server.arg("config_phpRetrievePath" ).toCharArray( config.phpRetrievePath, sizeof( config.phpRetrievePath ) ) ;
    server.arg("config_phpStorePath" ).toCharArray( config.phpStorePath, sizeof( config.phpStorePath ) ) ;
    // server.arg("config_spamLevel" ).toCharArray( config.spamLevel, sizeof( config.spamLevel ) ) ;

    config.spamLevel = server.arg("config_spamLevel" ).charAt( 0 ) ;
    // swSerial.print("config_spamLevel=")  ; swSerial.print( server.arg("config_spamLevel" ) ) ; swSerial.print(";") ; swSerial.print( config.spamLevel ) ; swSerial.println(";") ;

    httpUpdateResponse = "The configuration was updated.";
    eepromSave() ; // resave to eeprom
    eepromFetch() ;
    PrintEepromVariables() ;
  }


  server.sendHeader("Location", "/");
  server.send(302, "text/plain", "Moved");

}

// ==============
// setupAP()
// ==============

void  ICACHE_FLASH_ATTR setupAP() {
  swSerial.println(F("in setupAP() ")) ;
  apMode = true ;

  // attempt to clear previous AP connection
  // found on https://github.com/esp8266/Arduino/issues/644  3.mar.2016
  WiFi.disconnect();
  WiFi.mode(WIFI_OFF);

  delay (1000) ; // attempt to stabilise after WIFI_OFF

  swSerial.println(F("Starting/Restarting WiFi in AP mode")) ;
  WiFi.mode(WIFI_AP);
  WiFi.softAP( apName );

  apIp = WiFi.softAPIP();
  swSerial.print(F("AP IP address: "));
  swSerial.println(apIp);
}



// ==============
// WebServerSetup()
// ==============

void  ICACHE_FLASH_ATTR WebServerSetup() {

  server.on("/", handleRoot);
  server.on("/form", handleForm);

  server.begin() ;
}








