#ifndef XDMF_H
#define XDMF_H

#include "Arduino.h"
#include "Globals.h"

namespace nsXDMF {


struct Call_t {
	byte msgType ;
	char date[ 9 ] ;        // allow 1 for end marker
	char number[ 21 ] ;
	char name[ 26 ] ;
	bool mwIndicator ;    							  // copied to messageWaitingIndicator because it has a longer lifetime.
	byte mwMsgQty ;
	byte checkSumStatus ;
	byte CntBadStartBits ;
	byte CntBadStopBits;
	byte CntParserErrors;
	uint8_t byteWork ;                                // current byte being assembled
	uint8_t dataByteCount ;                           // count of data bytes found so far
	uint8_t byteWorkBitIndex ;                        // index into current byte  0=start; 1-8 bits ; 9 = stop. Only 1-8 are stored.
	uint16_t dataPacketLength ;
	uint16_t checksumCalc ;                           // total of all values including checksum itself
} ;


extern Call_t call ;

extern bool messageWaitingIndicator ;                 // updated / cleared on message waiting (0x82) mdmf record


// prototypes
void clean() ;
bool parseMdmf( byte index , byte value ) ;
byte parseDemodBitQueue( bool inBit ) ;
byte changeParserState( byte b ) ;

} // namespace nsXDMF

#endif
