#ifndef _WebServer_H
#define _WebServer_H

#include <ESP8266WebServer.h>

extern ESP8266WebServer server;

extern bool apMode ;

const char apName[] = "CallerID" ;
extern IPAddress apIp ;


// =====================================================================================
// =====================================================================================
const char MAIN_page[] PROGMEM = R"=====(
<!DOCTYPE html>
<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
         body {font-family: helvetica,arial,sans-serif;}
         table {border-collapse: collapse; border: 1px solid black;}
         /*table {border: 1px solid black;}*/
         td {padding: 0.25em;}
         .title { font-size: 2em; font-weight: bold;}
         .name {padding: 0.5em;}
         .heading {font-weight: bold; background: #c0c0c0; padding: 0.5em;}
         .update {color: #dd3333; font-size: 0.75em;}
         output {font-size: 0.75em; color: #696969;}
      </style>
   </head>
   <script>
      function myInit() {
      }
      
      function isValidField( fieldName , fieldMaxLength ) {
      //
      // returns boolean
      //  
      var testField = document.getElementById(fieldName) ;
      var isValid = false  ;
      
      if (  testField ) 
      {
        if (  testField.value.search(/\S+/) == -1  ||  testField.value.length > fieldMaxLength ) {
           testField.style.backgroundColor="LightCoral";
        }
        else {
           testField.style.backgroundColor="transparent";
           isValid = true ;
        }
      }
      return ( isValid ) ;
      }
      
      
      function check() {
      //
      //
      //
      if ( 
         isValidField( "config_ssid" , 31  ) 
         &&  isValidField( "config_psk" , 63  ) 
         &&  isValidField( "config_remoteHost" , 31  ) 
         &&  isValidField( "config_ruleIntlFrom" , 5  ) 
         &&  isValidField( "config_ruleIntlTo" , 5  ) 
         &&  isValidField( "config_ruleLocalFrom" , 5  ) 
         &&  isValidField( "config_ruleLocalTo" , 5  ) 
         &&  isValidField( "config_phpRetrievePath" , 31  ) 
         &&  isValidField( "config_phpStorePath" , 31  ) 
         &&  isValidField( "config_spamLevel" , 1  )
       )
      { 
         document.getElementById("callerIdConfigForm").submit(); 
         document.getElementById("updateResponse").value = "configuration sent to server" ;
      } 
      else {
      document.getElementById("updateResponse").value = "error in marked field(s)" ;
      }
      }
      
   </script>
   <body onload="myInit()">
      <form method="post" action="/form"  id="callerIdConfigForm">
      <div class=title>CallerID</div>
      <button type="button" onclick="check()">update</button>
      <p>
         <input class=update size=40 type=text name="updateResponse" id="updateResponse" value="$@updateResponse@$" >  
      <p>
      <div id=divPage1>
         <table>
            <tr>
               <td colspan=2 class=heading>Configuration</td>
            </tr>
            <tr>
               <td>SSID:</td>
               <td><input type="text" id="config_ssid" name="config_ssid" value="$@config_ssid@$" size=30 ></td>
            </tr>
            <tr>
               <td>PSK:</td>
               <td><input type="password" id="config_psk"  name="config_psk"  value="$@config_psk@$" size=30 ></td>
            </tr>
            <tr>
               <td>Host:</td>
               <td><input type="text" id="config_remoteHost"  name="config_remoteHost"  value="$@config_remoteHost@$" size=30 ></td>
            </tr>
            <tr>
               <td>Get path:</td>
               <td><input type="text" id="config_phpRetrievePath"  name="config_phpRetrievePath"  value="$@config_phpRetrievePath@$" size=30 ></td>
            </tr>
            <tr>
               <td>Store path:</td>
               <td><input type="text" id="config_phpStorePath"  name="config_phpStorePath"  value="$@config_phpStorePath@$" size=30 ></td>
            </tr>
            <tr>
               <td>Intl Rule 1:</td>
               <td><input type="text" id="config_ruleIntlFrom"  name="config_ruleIntlFrom"  value="$@config_ruleIntlFrom@$" size=30 ></td>
            </tr>
            <tr>
               <td>Intl Rule 2:</td>
               <td><input type="text" id="config_ruleIntlTo"  name="config_ruleIntlTo"  value="$@config_ruleIntlTo@$" size=30 ></td>
            </tr>
            <tr>
               <td>Local Rule 1:</td>
               <td><input type="text" id="config_ruleLocalFrom"  name="config_ruleLocalFrom"  value="$@config_ruleLocalFrom@$" size=30 ></td>
            </tr>
            <tr>
               <td>Local Rule 2:</td>
               <td><input type="text" id="config_ruleLocalTo"  name="config_ruleLocalTo"  value="$@config_ruleLocalTo@$" size=30 ></td>
            </tr>

            <tr>
               <td>Spam level:</td>
               <td><input type="text" id="config_spamLevel"  name="config_spamLevel"  value="$@config_spamLevel@$" size=30 ></td>
            </tr>
         </table>
      </div>
   </body>
</html>

)=====";
// =====================================================================================
// =====================================================================================





// Prototypes

void WebServerSetup() ;
void setupAP() ;

#endif










