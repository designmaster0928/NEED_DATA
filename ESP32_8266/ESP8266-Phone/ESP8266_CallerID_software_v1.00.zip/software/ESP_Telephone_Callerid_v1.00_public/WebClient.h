#ifndef _WebClient_H
#define _WebClient_H

#include "Screen.h"


// prototypes

String cleanTelNr( String nr ) ;
String cleanUrl( String  url) ;
void setupSTA(boolean noWait ) ;
void postCall() ;


#endif
