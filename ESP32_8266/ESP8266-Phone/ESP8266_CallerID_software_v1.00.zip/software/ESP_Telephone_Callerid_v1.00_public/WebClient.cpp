#include "Globals.h"
#include "WebClient.h"
#include "Config.h"
#include <ESP8266WiFi.h>
#include "Screen.h"
//#include "AFSK.h"
#include "XMDF.h"
#include <ArduinoJson.h>



String cleanTelNr( String nr ) {
  // turns number into E164 number 00 -> +  0 -> +41
  String in = nr ;
  if ( nr.startsWith( config.ruleIntlFrom ) ) {
    in = String( config.ruleIntlTo ) + in.substring( strlen( config.ruleIntlFrom ) ) ;
  }
  else if ( nr.startsWith( config.ruleLocalFrom ) ) {
    in = String( config.ruleLocalTo ) + in.substring( strlen( config.ruleLocalFrom ) ) ;
  }
  return cleanUrl( in )  ;
}




String cleanUrl( String  url)  {
  // to optimise
  String in = url ;
  // see https://www.w3schools.com/tags/ref_urlencode.asp
  // bulk replace of known characters
  in.replace("+", "%2B" ) ;
  in.replace(",", "%2C" ) ;
  in.replace("-", "%2D" ) ;
  in.replace(" ", "%20" ) ;
  for ( int i = 1 ; i < url.length() ; i++ ) {
    char inCh = in.charAt(i) ;
    if ( inCh >= 'a' && inCh <= 'z' || inCh >= 'A' && inCh <= 'Z' || inCh >= '0' && inCh <= '9' || inCh == '%'  ) {
      // OK
    }
    // else if ( inCh == ' ' ) in.setCharAt(i , '+' ) ;
    else in.setCharAt(i , '_' ) ;
  }
  return in ;
}


void setupSTA(boolean noWait ) {
  /*
      noWait true : does not wait for timeout.
      noWait should be "silent" ?
  */

  swSerial.println("in setupSTA ") ;

  const unsigned long   WLAN_CONNECT_TIMEOUT_MS = 40000UL ; // 40 seconds (was 20)

  swSerial.println(F("Stopping any WiFi sessions ")) ;
  // attempt to clear previous AP connection
  // found on https://github.com/esp8266/Arduino/issues/644  3.mar.2016
  // client.stop();
  // server.stop();
  WiFi.disconnect();
  WiFi.mode(WIFI_OFF);

  delay (1000) ; // attempt to stabilise after WIFI_OFF
  swSerial.println(F("Starting/Restarting WiFi")) ;
  WiFi.mode(WIFI_STA);

  WiFi.begin(config.ssid, config.psk);
  swSerial.println(F("Attempting connecting to wlan SSID= ")) ;
  swSerial.println( config.ssid ) ;

  tft.println(" ") ;
  tft.println( F("trying SSID= " ) ) ;
  tft.println( config.ssid ) ;

  delay (1000) ; // attempt to stop repeated failure on restart.
  unsigned long wlanConnectStartAttemptAtMs = millis() ;
  if ( noWait == false  ) {
    while (WiFi.status() != WL_CONNECTED && millis() - wlanConnectStartAttemptAtMs <= WLAN_CONNECT_TIMEOUT_MS  ) {
      delay(1000);
      swSerial.print(".") ;
      tft.print( "." ) ;
    }
  }

  swSerial.println("");
  if ( WiFi.status() == WL_CONNECTED ) {
    delay (1000) ; // attempt to stop repeated failure on restart.
    IPAddress ip = WiFi.localIP();
    swSerial.print(F("Connected to wlan ")) ;
    swSerial.println(ip);
    tft.println(" ") ;
    tft.println( F("Connected to wlan: " ) ) ;
    tft.println(ip);
    tft.println(" ") ;
    wlanAvailable = true  ;
  }
  else {
    swSerial.println(F("Failed to connect to wlan  ")) ;
    tft.println() ;
    tft.print( F("Connect failed " ) ) ;
    dbOnline = false ;
    wlanAvailable = false  ;
  }
}


void postCall() {
  //
  //  maintains dbOnline
  //
  swSerial.println(F("\nin postCall()"));

  WiFiClient client;
  swSerial.print(F("connecting to "));
  swSerial.println( config.remoteHost );

  if (!client.connect( config.remoteHost , 80 )) {
    dbOnline = false ;
    swSerial.println(F("in postCall(). connection failed"));
  }
  else {

    // We now create a URI for the request

    String url = "" ;
    url = String( config.phpStorePath ) + "?telNo=" +  cleanTelNr(call.number)  + "&nameNet=" + cleanUrl(call.name) + "&dateStampNet=" + cleanUrl(call.date)
          + "&checkDigitOk=" + call.checkSumStatus + "&numberInRun=" + callsThisRun + "&runNumber=" + config.runNumber  ;
    swSerial.println (F("Requesting URL: "));
    swSerial.println(url);

    client.print(String("GET ") + url + " HTTP/1.1\r\n" + "Host: " + config.remoteHost + "\r\n" +  "Connection: close\r\n\r\n");
    delay(100) ;
    // currentDbCallId = 0 ;  // reset to force fetch of newest record in DB.
    dbOnline = true ;
  }
  swSerial.println(F("\nexiting postCall()"));
}








