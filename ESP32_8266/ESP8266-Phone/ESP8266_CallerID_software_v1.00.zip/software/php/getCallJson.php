<html>
<head>
<title>Tel</title>
</head >
<body>
<p>
<?php

//     usage:   ?id=0     returns latest record
//              ?id=x     x >=1 returns record x



// $mysqli = new mysqli("localhost", "username", "password", "databaseName");
include ('cred1.php') ;



if ( is_numeric( $_GET["id"] ) ) {
  $id = $_GET["id"] ;
}
else {
  $id = "0" ;
}


echo "***Json: "  ; // marker


if ( $id == "0" ) {
  $stmt = ( "SELECT * FROM  callExp   ORDER BY id DESC  LIMIT 1" ) ;  // get newest row
}
else {
  $stmt = ( "SELECT * FROM  callExp   WHERE id = $id" );  // get specific row
}

$result = $mysqli->query($stmt) ;


if ( $result->num_rows == 1 ) {
  // output data of each row
  $row = $result->fetch_assoc() ;

  $row = array("ErrorCode" => "0" ) + array("ErrorText" => "" ) + $row ;

  //  json_encode returns a NULL which is not handled by the Arduino lib.
  foreach ($row as $key => $value) {
    // echo "$key => $value\n";
    if ( $row[ $key ] == NULL ) {
      $row[ $key ] = "" ;
    }
  }


  echo json_encode( $row ) ;

/*
      var_dump( $row ) ;
      echo "id = " . $row["id"] . "<br>" ;
      echo "timeStampSystem = " . $row["timeStampSystem"] . "<br>" ;
      echo "telNo = " . $row["telNo"] . "<br>" ;
      echo "nameNet = " . $row["nameNet"] . "<br>" ;
      echo "name = " . $row["name"] . "<br>" ;
      echo "dateStampNet = " . $row["dateStampNet"] . "<br>" ;
      echo "checkDigitOk = " . $row["checkDigitOk"] . "<br>" ;
      echo "numberInRun = " . $row["numberInRun"] . "<br>" ;
      echo "runNumber = " . $row["runNumber"] . "<br>" ;
*/

}
else {
  $myObj->ErrorCode = "1" ;
  $myObj->ErrorText = "record {$id}. {$result->num_rows} row(s) found"  ;
  echo json_encode( $myObj ) ;
}



?>
</p>
</body>
</html >