<?php 
// =========================================================================
$servername = "localhost";  // usually localhost
$username = "xxxxxxx";
$password = "xxxxxxx";
$dbname = "xxxxxxx";
$mysqli = new mysqli( $servername, $username, $password, $dbname );
if($mysqli->connect_error) {
  exit('Error connecting to database'); 
}
$mysqli->set_charset("utf8");
// =========================================================================
?>