<?php

//
//  storeCallData
//  based on https://websitebeaver.com/prepared-statements-in-php-mysqli-to-prevent-sql-injection
//

// $mysqli = new mysqli("localhost", "username", "password", "databaseName");
include ('cred1.php') ; 


$telNo = $_GET['telNo'];
$nameNet = $_GET['nameNet'];
$dateStampNet = $_GET['dateStampNet'];
$checkDigitOk = $_GET['checkDigitOk'];
$numberInRun = $_GET['numberInRun'];
$runNumber = $_GET['runNumber'];


// $ip = $_SERVER["REMOTE_ADDR"];

echo ( "telNo: " . $telNo ) ;
echo ( "nameNet: " . $nameNet ) ;
echo ( "dateStampNet: " . $dateStampNet ) ;  
echo ( "checkDigitOk: " . $checkDigitOk ) ;  
echo ( "numberInRun: " . $numberInRun ) ; 
echo ( "runNumber: " . $runNumber ) ; 




$stmt = $mysqli->prepare("INSERT INTO calls (telNo,nameNet,dateStampNet,checkDigitOk,numberInRun,runNumber) VALUES (?, ?, ?, ?, ?, ?)" );
$stmt->bind_param("sssiii", $telNo, $nameNet, $dateStampNet , $checkDigitOk, $numberInRun, $runNumber );
$stmt->execute();
$stmt->close();
exit();
?>